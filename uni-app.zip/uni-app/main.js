import Vue from 'vue'
import App from './App'

import {
	apiUrl
} from './config.js'
import {
    global
} from "./global/global.js"
Vue.prototype.$global = global; //注册全局事件
Vue.prototype.$apiUrl = apiUrl;

import { myRequest } from './common/api.js'
Vue.prototype.$myRequest = myRequest

Vue.config.productionTip = false

import uView from "uview-ui";
Vue.use(uView);

App.mpType = 'app'

const app = new Vue({
    ...App
})


app.$mount()
