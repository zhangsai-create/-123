<template>
	<view class="detail">
		<view class="img_box">
			<u-image class="img" :src="imgUrl+dataInfo.thumb" width="600" height="300" mode="widthFix"  :lazy-load="true"></u-image>
		</view>
		<view class="titles">
			{{dataInfo.title}}
		</view>
		<view class="bt_box">
			<view>报题状态：{{dataInfo.status}}</view>
			<view>创建于：{{dataInfo.foundtime}}</view>
		</view>
		<view class="bt_box">
			<view>链接：{{dataInfo.url}}</view>
			<view>简介：{{dataInfo.synopsis}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dataInfo:{},
				imgUrl:this.$apiUrl,
			};
		},
		onLoad(val) {
			console.log(val)
			let data = JSON.parse(val.info)
			this.dataInfo = data
			if(this.dataInfo.aid ==140){
				let arr = JSON.parse(this.dataInfo.content)
				console.log(arr)
				this.dataInfo.zutu = arr.zutu
			}
			console.log(this.dataInfo)
		},
		methods: {
			async login(){
				let data = {
					name:this.form.username,
					password:this.form.password
				}
				const res = await this.$myRequest({
							url:'front/base/contenttype/frontcontent/login',data
						})
						console.log(res)
				if(res.data.status == true){
					uni.setStorageSync('info', res.data.user_id)
					uni.showToast({
						title:res.data.msg
					})
					uni.navigateTo({
						url: '../index/index'
					})
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			}
		}
	}
</script>

<style scoped lang="scss">
	.detail{
		padding: 25rpx;
		.img_box{
			text-align: center;
			.img{
			display: inline-block;
			}
		}
		.titles{
			font-size: 40rpx;
			height: 45rpx;
			line-height: 45rpx;
			text-align: center;
		}
	}
</style>
