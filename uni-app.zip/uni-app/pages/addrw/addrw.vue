<template>
	<view class="ksfg">
		<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left" @click="backPageRefresh">返回</view>
		 	<view class="top_z">新增</view>
		 	<view class="top_right" @click="rwAdd">发表</view>
		 </view>
		 <view class="content_b"></view>
		<view class="box">
			<span class="tits">标题：</span>
			<input v-model="formData.title" class="inputs" label="" placeholder="请输入" required></input >
		</view>
		<view class="box">
			<span class="tits">链接：</span>
			<input class="inputs" v-model="formData.lianjie"  label="" placeholder="请输入" required></input >
		</view>
		<view class="box">
			<span class="tits">关键字：</span>
			<input class="inputs" v-model="formData.keyword"  label="" placeholder="请输入" required></input >
		</view>
		<view class="box">
			<span class="tits">备注：</span>
			<input class="inputs" v-model="formData.beizhu"  label="" placeholder="请输入" required></input >
		</view>
		<view class="box">
			<span class="tits">部门：</span>
			<input class="inputs"  v-model="formData.bumen"  label="" placeholder="请输入" required></input >
		</view>
		<view class="box">
			<span class="tits">发布人：</span>
			<input class="inputs" label=""  v-model="user" disabled="" placeholder="请输入" required></input >
		</view >
			<view class="box">
				<span class="tits" style="width: 210rpx;">	选题id：</span>
				<input class="inputs" label=""  v-model="formData.xuanti_id"  placeholder="请输入" required></input >
			</view >
				<view class="box" >
					<span class="tits" style="width: 210rpx;">被指派人id：</span>
					<input class="inputs" label=""  v-model="formData.zhipai_user_id"  placeholder="请输入" required></input >
				</view >
			<view class="box">
				<span class="tits" style="width: 210rpx;">	是否关联选题：</span>
				<u-radio-group v-model="value">
					<u-radio 
						v-for="(item, index) in list" :key="index" 
						@change="radioChange(index)" 
						:name="item.name"
						:disabled="item.disabled">
						{{item.name}}
					</u-radio>
				</u-radio-group>
			</view>
			<view class="box">
		<span class="tits" style="width: 210rpx;">	是否签到：</span>
				<u-radio-group v-model="value1" >
					<u-radio 
						v-for="(item, index) in listtwo" :key="index" 
						:name="item.name"
						:disabled="item.disabled"
							@change="radioChange1(index)">
						{{item.name}}
					</u-radio>
				</u-radio-group>
			</view>
		<view class="box">
				<span class="tits">地址：</span>
				<input class="inputs" label=""  v-model="formData.address" placeholder="请输入" required></input >
		</view>
		<view class="boxs">
			<span class="tits">选择图片：</span>
			 <u-upload  @on-success="upSuccess"  max-count="1" :action="action" @on-remove="onRmove" :custom-btn="true" width="160" height="160" :typeList="typeList" :auto-upload="true">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<u-icon name="photo" size="100" color="#c0c4cc"></u-icon>
				</view>
			 </u-upload>
		</view>
		<view class="time">
			<span class="tits">开始时间：</span>
			<ruiDatePicker
				fields="second"
				start="2010-00-00 00:00:00"
				end="2030-12-30 23:59:59"
				:value="timeOne"
				@change="bindChangeone"
				@cancel="bindCancel"
			></ruiDatePicker>
		</view>
		<view class="time">
			<span class="tits">结束时间：</span>
			<ruiDatePicker 
				fields="second"
				start="2010-00-00 00:00:00"
				end="2030-12-30 23:59:59"
				:value="timeTwo"
				@change="bindChangetwo"
				@cancel="bindCancel"
			></ruiDatePicker>
		</view>

	
		<view class="box_nr" style="margin-top: 20rpx;margin-bottom: 20rpx;">
			<span class="tits"  >内容详情：</span>
			<u-input style="margin-top: 20rpx;" v-model="formData.content"  type="textarea" :border="true" :height="150" :auto-height="true" />
		</view>
		
	</view>
</template>

<script>
	import ruiDatePicker from '@/components/rattenking-dtpicker/rattenking-dtpicker.vue';
	export default {
	components: {ruiDatePicker},
		data() {
			return {
				list: [
					{
						name: '否',
						disabled: false
					},
					{
						name: '是',
						disabled: false
					}
					],
				listtwo: [
					{
						name: '否',
						disabled: false
					},
					{
						name: '是',
						disabled: false
					}
					
				],
				// u-radio-group的v-model绑定的值如果设置为某个radio的name，就会被默认选中
				value: '否',
				value1: '否',
				index1:'',
				index2:'',
				formData:{},
				timeTwo:'',
				timeOne:'',
				action: this.$apiUrl+'front/base/contenttype/frontcontent/imgUpload',
				photos:[],
				user:'',
				typeList:[{
						text: '选择图片',
						fontSize: 28
					}],
			}
		},
		onLoad() {
			console.log(uni.getStorageSync('info'))
			this.user = uni.getStorageSync('info')
		},
		methods: {
			backPageRefresh(){
				uni.navigateBack()
			},
			upSuccess(data, index, lists) {
				console.log(data, index, lists)
				console.log(lists,'22')
				this.photos = data.data.url
				// this.photos = lists.map(item => {
				// 	console.log(item.url)
				// 	return item.url
				// })
				console.log(this.photos)
			},
			//时间选择
			bindChangeone(val){
				console.log(val)
				this.timeOne = val
			},
			bindChangetwo(val){
				this.timeTwo = val
				console.log(val)
			},
			// 是否关联选题的0 和1
			radioChange(i) {
				console.log(i,' 是否关联选题的0 和1');
				this.index1=i
			},
			// 是否签到的0 和1
			radioChange1(i) {
				console.log(i,'是否签到的0 和1');
				this.index2=i
			},
			async rwAdd(){
				let data={
					title:this.formData.title,
					content:this.formData.content,
					lianjie:this.formData.lianjie,
					photo:this.photos[0],
					bumen:this.formData.bumen,
					user_id:this.user,
					str_time:this.timeOne,
					end_time:this.timeTwo,
					address:this.formData.address,
					beizhu:this.formData.beizhu,
					keyword:this.formData.keyword,
					is_xuanti:this.index1,
					is_qiandao:this.index2,
					zhipai_user_id:this.formData.zhipai_user_id,
					xuanti_id:this.formData.xuanti_id
					
				}
				const res = await this.$myRequest({
					url:'front/content/xiansuo/renwu/addrenwu',data
				})
				console.log(res)
				// if(res.data.data.result == 200){
				// 	uni.showToast({
				// 		title:es.data.data.msg
				// 	})
				// 	setTimeout(function(){
				// 		this.backPageRefresh()
				// 		; }, 1000);
				// }
			},
		}
	}
</script>

<style scoped lang="scss">
	// 头部样式
.content{
		height: var(--status-bar-height);  
		width: 100%;  
		background-color: #F8F8F8!important;
	    // top: 0;
	    // z-index: 999; 
	}
	.content_box{
		height: var(--status-bar-height);  
		width: 100%;  
		position: fixed;  
		background-color: #F8F8F8;  
		top: 0;  
		z-index: 999;  
	}
	.content_b{
		height: var(--status-bar-height);
		width: 100%;  
	}
	.ksfg{
		padding: 0 10rpx;
	}
	.top_box{
		width: 100%;
		/* display: flex;
		align-items: center;
		justify-content: center; */
	}
	.top_left{
		display: inline-block;
		width: 33%;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_z{
		display: inline-block;
		width: 33%;
		text-align: center;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_right{
		display: inline-block;
		width: 33%;
		text-align: right;
		height: 80rpx;
		line-height: 80rpx;
	}
	// 表单样式
	.box{
		height: 70rpx;
		line-height: 70rpx;
		border-bottom:2rpx solid #C0C0C0;
		padding: 0 10rpx;
		display:flex;
		align-items:center;/*垂直居中*/
	}
	.boxs{
		/* border-bottom:2rpx solid #C0C0C0; */
	}
	.inputs{
		display: inline-block;
		line-height: 70rpx;
		margin-left: 50rpx;
	}
	.time{
		height: 100rpx;
		line-height: 70rpx;
		border-bottom:2rpx solid #C0C0C0;
		padding: 0 10rpx;
		display:flex;
		align-items:center;/*垂直居中*/
	}
	// 时间的样式
	.time .tits{
		margin-right: 50rpx;
		width: 140rpx;
	}
	/deep/ .box_nr{
		width: 100%;
		padding: 10;
		 .uni-input-input{
			width: 100%;
			height: 200rpx;
			border: 2rpx soild #606266;
		}
		}
	.tits{
		width: 130rpx;
	}
	/deep/  .u-dropdown__menu__item{
		width: 250rpx!important;
	}
</style>
