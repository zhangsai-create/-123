<template>
	<view >
	<view class="content"></view>
	<view class="content_box"></view>
	 <view class="top_box">
	 	<view class="top_left" @click="backPageRefresh">返回</view>
	 	<view class="top_z">编辑</view>
	 	<view class="top_right">发表</view>
	 </view>
	 <view class="content_b"></view>
	<view class="box">
		<span class="tits">标题：</span>
		<input v-model="ipt.title" class="inputs" label="" placeholder="请输入" required></input >
	</view>
	<!--  -->
	<view class="box">
		<span class="tits">链接：</span>
		<input class="inputs" v-model="ipt.lianjie"  label="" placeholder="请输入" required></input >
	</view>
	<view class="box">
		<span class="tits">部门：</span>
		<input class="inputs"  v-model="ipt.bumen"  label="" placeholder="请输入" required></input >
	</view>
	<view class="box">
		<span class="tits">简介：</span>
		<input class="inputs" label=""  v-model="ipt.jianjie" placeholder="请输入" required></input >
	</view>

<view class="box">
		<span class="tits">地址：</span>
		<input class="inputs" label=""  v-model="ipt.jianjie" placeholder="请输入" required></input >
	</view>

	<view class="box_nr">
		<span class="tits">内容详情：</span>
		<u-input v-model="ipt.detail"  type="textarea" :border="true" :height="150" :auto-height="true" />
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ipt:{
					title:'',
					lianjie:'',
					bumen:'',
					detail:'',
					jianjie:'',
					
					
				},
				
			}
		},
		onLoad(val) {
		let data = JSON.parse(val.info)
		
		console.log(data.id)
		},
		methods: {
			backPageRefresh(){
				let pages = getCurrentPages(); // 当前页面
				let beforePage = pages[pages.length - 2]; // 前一个页面
				console.log("beforePage",beforePage);
				console.log(pages);
				uni.navigateBack({
					delta: 1,
					// success: function() {
					// 	beforePage.$vm.refreshRequest(); // 执行前一个页面的刷新
					// }
				});
			},
			async getcategory(){
				let data = {
					id:data.id,
					user_id:data.user_id,
					title:this.ipt.title,
					content	:$(".center").val(),
					lianjie	:this.ipt.lianjie,
					photo	:thumb,
					bumen   :this.ipt.bumen,
					address :$(".adress").val(),
					str_time:Date.parse($(".result").text())/1000,
					end_time:Date.parse($(".result2").text())/1000,
				}
				const res = await this.$myRequest({
							url:'front/content/xiansuo/baoti/updateBaoTi',data
					})
					console.log(res.data.data)
			
					
			},
		}
	}
</script>

<style scoped lang="scss">
	.ksfg{
		padding: 0 10rpx;
	}
	.top_box{
		width: 100%;
		/* display: flex;
		align-items: center;
		justify-content: center; */
	}
	.top_left{
		display: inline-block;
		width: 33%;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_z{
		display: inline-block;
		width: 33%;
		text-align: center;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_right{
		display: inline-block;
		width: 33%;
		text-align: right;
		height: 80rpx;
		line-height: 80rpx;
	}
	
	.box{
		height: 70rpx;
		line-height: 70rpx;
		border-bottom:2rpx solid #C0C0C0;
		padding: 0 10rpx;
		display:flex;
		align-items:center;/*垂直居中*/
	}
	.boxs{
		/* border-bottom:2rpx solid #C0C0C0; */
	}
	.inputs{
		display: inline-block;
		line-height: 70rpx;
		margin-left: 50rpx;
	}
	/deep/ .box_nr{
		width: 100%;
		padding: 10;
		 .uni-input-input{
			width: 100%;
			height: 200rpx;
			border: 2rpx soild #606266;
		}
		}
	.tits{
		width: 140rpx;
	}
	/deep/  .u-dropdown__menu__item{
		width: 250rpx!important;
	}
</style>
