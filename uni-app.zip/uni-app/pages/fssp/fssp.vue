<template>
	<view class="ksfg">
		<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left" @click="backPageRefresh">返回</view>
		 	<view class="top_z">编辑</view>
		 	<view class="top_right" @click="addInsert">发表</view>
		 </view>
		 <!-- <view class="content_b"></view> -->
		<view class="box">
			<span class="tits">标题：</span>
			<input  v-model="form.title" class="inputs" label="" placeholder="请输入标题" required></input >
		</view>
		<!--  -->
		<view class="box">
			<span class="tits">长标题：</span>
			<input v-model="form.longtitle" class="inputs"  label="" placeholder="请输入长标题" required></input >
		</view>
		<view class="box">
			<span class="tits">关键字：</span>
			<input v-model="form.tags" class="inputs"  label="" placeholder="请输入长标题" required></input >
		</view>
		<view class="box">
			<span class="tits">简介：</span>
			<input v-model="form.synopsis" class="inputs" label="" placeholder="请输入长标题" required></input >
		</view>
		<view class="box">
			<span class="tits">是否评论：</span>
			<u-dropdown class="u-dropdown_box">
				<u-dropdown-item @change="statusChange" v-model="currentStatus" :title="currentit" :options="StatusList"></u-dropdown-item>
			</u-dropdown>
		</view>
		<view class="boxs">
			<span class="tits">选择视频：</span>
			<view  @click="chooseVideo" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
				<u-icon name="photo" size="100" color="#c0c4cc"></u-icon>
			</view>
			<video v-if="typeSelect===1&&videoSrc" :controls="false" :show-fullscreen-btn="false" :src="videoSrc"></video>
			 <!-- <u-upload  @on-success="upSuccess"  max-count="3" :action="action" @on-remove="onRmove" :custom-btn="true" width="160" height="160" :typeList="typeList" :auto-upload="true">
			 	<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
			 		<u-icon name="photo" size="100" color="#c0c4cc"></u-icon>
			 	</view>
			 </u-upload> -->
			<!-- <u-upload ref="uUpload" @on-success="upSuccess" :action="action" @on-remove="onRmove" :typeList="typeList" :auto-upload="true"
			  @upSuccessVideo="upSuccessVideo">
			  </u-upload> -->
		</view>
		<view class="box_nr">
			<span class="tits">内容详情：</span>
			<u-input v-model="box_nr" type="textarea" :border="true" :height="150" :auto-height="true" />
		</view>
		<view class="box" style="margin-top: 20rpx;">
			<span class="tits">栏目：</span>
			<u-dropdown class="u-dropdown_box">
				<u-dropdown-item @change="lmChange"  v-model="lmNum" :title="lmTitle" :options="lmList"></u-dropdown-item>
			</u-dropdown>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form:{},
				action: this.$apiUrl+'front/base/contenttype/frontcontent/videoUpload',
				photos: [],
				typeList:[{
						text: '选择视频',
						fontSize: 28
					}],
				StatusList: [{
						label: '允许评论',
						value: 1,
					},
					{
						label: '禁止评论',
						value: 2,
					},
					{
						label: '审核评论',
						value: 3,
					}
				],
				currentStatus:1,
				currentit:'允许评论',
				box_nr:'',
				lmNum:0,
				lmTitle:'全部',
				lmList:[{value:0,label:'全部'}],
				videoSrc:'',
				typeSelect:null,
				urlVideo:''
			};
		},
		onLoad() {
			this.getcategory()
			console.log(uni.getStorageSync('info'))
		},
		mounted() {
		},
		methods: {
			//返回
			backPageRefresh(){
				let pages = getCurrentPages(); // 当前页面
				let beforePage = pages[pages.length - 2]; // 前一个页面
				console.log("beforePage",beforePage);
				console.log(pages);
				uni.navigateBack({
					delta: 1,
					// success: function() {
					// 	beforePage.$vm.refreshRequest(); // 执行前一个页面的刷新
					// }
				});
			},
			async getcategory(){
				let data = {
					uid:uni.getStorageSync('info')
				}
				const res = await this.$myRequest({
							url:'front/base/contenttype/frontcontent/getcategory',data
					})
					console.log(res.data.data)
					for(let i in res.data.data){
						// console.log(res.data.data)
						let val = {
							value:res.data.data[i].id,
							label:res.data.data[i].name
						}
						this.lmList.push(val)
					}
					// console.log(this.lmList)
			},
			statusChange(val) {
				console.log(val)
				this.currentStatus = val
				if (val === 1) {
					this.currentit = '允许评论'
				} else if (val === 2) {
					this.currentit = '禁止评论'
				} else if (val === 3) {
					this.currentit = '审核评论'
				}
			},
			lmChange(val){
				console.log(val)
				this.lmNum = val
				for(let i=0;i<this.lmList.length;i++){
					if(this.lmList[i].value == val){
						this.lmTitle=this.lmList[i].label
					}
				}
			},
			upSuccessVideo(url) {
				console.log(url)
				this.videoUrl = url
			},
			upSuccess(data, index, lists) {
				console.log(data, index, lists)
				console.log(lists,'22')
				this.photos = lists.map(item => {
					console.log(item.url)
					return item.url
				})
				console.log(this.photos)
			},
			onRmove(index) {
				this.photos.splice(index, 1)
			},
			chooseVideo(){
				const that = this;
				uni.chooseVideo({
					count: 1,
					sourceType: ['camera', 'album'],
					success: function(res) {
						console.log(res,'99')
						if (res.size / 1024 / 1024 > 100) {
							uni.showToast({
								title: '文件需小于100M'
							})
							return
						} else {
							uni.showLoading({
								title: '上传中，请稍后'
							})
						}
						uni.uploadFile({
							url: that.action, //仅为示例，非真实的接口地址
							filePath: res.tempFilePath,
							name: 'file',
							formData: {},
							success: (res2) => {
								console.log(res2)
								uni.showToast({
									title: '上传成功',
									icon: 'none'
								})
								that.typeSelect = 1
								that.videoSrc = res.tempFilePath;
								console.log(JSON.parse(res2.data),'urls');
								let vidUrl = JSON.parse(res2.data)
								that.urlVideo = vidUrl.data.url[0]
								console.log(this.urlVideo)
								// that.$emit('upSuccessVideo', JSON.parse(res2.data).data.file)
							},
							complete: () => {
								uni.hideLoading()
							}
						});
					}
				});
			},
			async addInsert(){
				console.log(uni.getStorageSync('info'))
				let data = {
					userid:uni.getStorageSync('info'),
					aid:'142',
					thumb:this.urlVideo,
					tags:this.form.tags,
					synopsis:this.form.synopsis,
					allowcomment:this.currentStatus,
					title:this.form.title,
					longtitle:this.form.longtitle,
					// neirong:this.box_nr,
					categoryid:this.lmNum,
					video:this.urlVideo
				}
				const res = await this.$myRequest({
							url:'front/base/contenttype/frontcontent/insert',data
					})
					console.log(res)
				if(res.data.status == true){
					uni.showToast({
						title:res.data.msg
					})
					setTimeout(function(){
						uni.navigateTo({
							url: '../index/index'
						})
						; }, 1000);
				}
			}
		}
	}
</script>

<style scoped>
	.content{
		height: var(--status-bar-height);  
		width: 100%;  
		background-color: #F8F8F8!important;
	    // top: 0;
	    // z-index: 999; 
	}
	.content_box{
		height: var(--status-bar-height);  
		width: 100%;  
		position: fixed;  
		background-color: #F8F8F8;  
		top: 0;  
		z-index: 999;  
	}
	.content_b{
		height: var(--status-bar-height);
		width: 100%;  
	}
	.ksfg{
		padding: 0 10rpx;
	}
	.top_box{
		width: 100%;
		/* display: flex;
		align-items: center;
		justify-content: center; */
	}
	.top_left{
		display: inline-block;
		width: 33%;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_z{
		display: inline-block;
		width: 33%;
		text-align: center;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_right{
		display: inline-block;
		width: 33%;
		text-align: right;
		height: 80rpx;
		line-height: 80rpx;
	}
	
	.box{
		height: 70rpx;
		line-height: 70rpx;
		border-bottom:2rpx solid #C0C0C0;
		padding: 0 10rpx;
		display:flex;
		align-items:center;/*垂直居中*/
	}
	.boxs{
		/* border-bottom:2rpx solid #C0C0C0; */
	}
	.inputs{
		display: inline-block;
		line-height: 70rpx;
		margin-left: 50rpx;
	}
	/deep/ .box_nr{
		width: 100%;
		padding: 10;
		 .uni-input-input{
			width: 100%;
			height: 200rpx;
			border: 2rpx soild #606266;
		}
		}
	.tits{
		width: 140rpx;
	}
	/deep/  .u-dropdown__menu__item{
		width: 250rpx!important;
	}
</style>
