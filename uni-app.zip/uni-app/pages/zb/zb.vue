<template>
	<view>
		<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left ksfg" @click="backPageRefresh">返回</view>
		 	<view class="top_z">	直播页面</view>
		 	<view class="top_right">设置</view>
		 </view>
		 <view class="content_b"></view>
	
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			//返回
			backPageRefresh(){
				let pages = getCurrentPages(); // 当前页面
				let beforePage = pages[pages.length - 2]; // 前一个页面
				console.log("beforePage",beforePage);
				console.log(pages);
				uni.navigateBack({
					delta: 1,
					// success: function() {
					// 	beforePage.$vm.refreshRequest(); // 执行前一个页面的刷新
					// }
				});
			},
		}
	}
</script>

<style scoped lang="scss">
.ksfg{
		padding: 0 10rpx;
	}
	.content{
		height: var(--status-bar-height);  
		width: 100%;  
		background-color: #F8F8F8!important;
	    // top: 0;
	    // z-index: 999; 
	}
	.content_box{
		height: var(--status-bar-height);  
		width: 100%;  
		position: fixed;  
		background-color: #F8F8F8;  
		top: 0;  
		z-index: 999;  
	}
	.content_b{
		height: var(--status-bar-height);
		width: 100%;  
	}
	.top_box{
		width: 100%;
		/* display: flex;
		align-items: center;
		justify-content: center; */
	}
	.top_left{
		display: inline-block;
		width: 33%;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_z{
		display: inline-block;
		width: 33%;
		text-align: center;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_right{
		display: inline-block;
		width: 33%;
		text-align: right;
		height: 80rpx;
		line-height: 80rpx;
	}
</style>
