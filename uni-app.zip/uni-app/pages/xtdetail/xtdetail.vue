<template>
	<view class="detail">
		<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left" @click="backPageRefresh">返回</view>
		 	<view class="top_z">详情</view>
		 	<!-- <view class="top_right" @click="addInsert">发表</view> -->
		 </view>
		<view class="img_box">
			<u-image class="img" :src="imgUrl+dataInfo.photo" width="600" height="300" mode="widthFix"  :lazy-load="true"></u-image>
		</view>
		<view class="titles">
			{{dataInfo.title}}
		</view>
		<view class="bt_box">
			<view>标题：{{dataInfo.title}}</view>
			<view>选题状态：{{dataInfo.status==0? '正常' : dataInfo.status==1? '软删除' : '硬删除'}}</view>
			<view>选题选择状态：{{statusTitle}}</view>
			<view>创建于：{{dataInfo.create_time}}</view>
			<view>结束于：{{dataInfo.update_time}}</view>
		</view>
		<view class="bt_box">
			<view>链接：{{dataInfo.lianjie}}</view>
			<view>发布人：{{dataInfo.user_id}}</view>
		</view>
		<view class="bottom_box">
			<!-- <view class="botton_btn">设为选题</view> -->
			<u-button size="medium" type="primary" @click="toRenwu">设为任务</u-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dataInfo:{},
				imgUrl:this.$apiUrl,
				statusTitle:'',
			};
		},
		onLoad(val) {
		let data = JSON.parse(val.info)
		this.dataInfo = data
		this.getBtstatus()
		},
		mounted() {
			this.dataInfo.update_time= this.$global.timestampFormat(this.dataInfo.update_time)
		},
		methods: {
			async toRenwu(){
				let data = {
					id:this.dataInfo.xuanti_id,
					user_id:uni.getStorageSync('info')
				}
				const res = await this.$myRequest({
					url:'front/content/xiansuo/xuanti/XuanTiforRenWu',data
				})
				console.log(res)
				if(res.data.code == 0){
					uni.showToast({
						title:res.data.data.data_msg
					})
					setTimeout(function(){
						let pages = getCurrentPages(); // 当前页面
						let beforePage = pages[pages.length - 2]; // 前一个页面
						console.log("beforePage",beforePage);
						console.log(pages);
						uni.navigateBack({
							delta: 1,
							success: function() {
								beforePage.$vm.getMine(); // 执行前一个页面的刷新
								beforePage.$vm.getMydata();
							}
						});
						; }, 1000);
				}
			},
			//报题选择状态
			async getBtstatus(){
				let data={
					id:this.dataInfo.xuanti_id
				}
				const res = await this.$myRequest({
					url:'front/content/xiansuo/xuanti/getXuanTiStatus',data
				})
				console.log(res)
				let val = res.data.data
				switch(parseInt(val.select_status)) {
					case 0:
						this.statusTitle = '未被选题'
						break;
				    case 1:
				        this.statusTitle = '已经被选题'
				        break;
				    case 2:
				        this.statusTitle = '开始'
				        break;
					case 3:
						this.statusTitle = '进行中'
						break;
					case 4:
						this.statusTitle = '终止'
						break;
				    case 5:
						this.statusTitle = '已完成'
						break;
					case 6:
						this.statusTitle = '过期'
						break;
				} 
			},
		}
	}
</script>

<style scoped lang="scss">
	.detail{
		width: 100%;
		.content{
			height: var(--status-bar-height);  
			width: 100%;  
			background-color: #F8F8F8!important;
		    // top: 0;
		    // z-index: 999; 
		}
		.content_box{
			height: var(--status-bar-height);  
			width: 100%;  
			position: fixed;  
			background-color: #F8F8F8;  
			top: 0;  
			z-index: 999;  
		}
		.top_left{
			display: inline-block;
			width: 33%;
			height: 80rpx;
			line-height: 80rpx;
		}
		.top_z{
			display: inline-block;
			width: 33%;
			text-align: center;
			height: 80rpx;
			line-height: 80rpx;
		}
		.top_right{
			display: inline-block;
			width: 33%;
			text-align: right;
			height: 80rpx;
			line-height: 80rpx;
		}
		padding: 25rpx;
		.img_box{
			text-align: center;
			.img{
			display: inline-block;
			}
		}
		.titles{
			font-size: 40rpx;
			height: 45rpx;
			line-height: 45rpx;
			text-align: center;
		}
		.bottom_box{
			margin-top: 15rpx;
			width: 100%;
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			.botton_btn{
				color: #fff;
				background: #007AFF;
				width: 220rpx;
				display: inline-block;
				border-radius: 10rpx;
			}
		}
	}
</style>
