<template>
	<view class="detail">
		<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left" @click="backPageRefresh">返回</view>
		 	<view class="top_z">详情</view>
		 	<!-- <view class="top_right" @click="addInsert">发表</view> -->
		 </view>
		<view class="img_box">
			<u-image class="img" :src="imgUrl+dataInfo.photo" width="600" height="300" mode="widthFix"  :lazy-load="true"></u-image>
		</view>
		<view class="titles">
			{{dataInfo.title}}
		</view>
		<view class="bt_box">
			<view>标题：{{dataInfo.title}}</view>
			<view>报题状态：{{dataInfo.status==0? '正常' : dataInfo.status==1? '软删除' : '硬删除'}}</view>
			<view>创建于：{{dataInfo.create_time}}</view>
			<view>结束于：{{dataInfo.end_time}}</view>
		</view>
		<view class="bt_box">
			<view>链接：{{dataInfo.lianjie}}</view>
			<view>发布人：{{dataInfo.user_id}}</view>
			<view>内容：{{dataInfo.content}}</view>
			<view>备注：{{dataInfo.beizhu}}</view>
			<view>修改人：{{dataInfo.update_user_id}}</view>
			<view>	是否关联选题：{{dataInfo.is_xuanti==0? '否' :'是'}}</view>
			<view>选题选择状态 ：{{dataInfo.select_status}}</view>
			<view>是否需要签到：{{dataInfo.is_qiandao==0? '否' :'是'}}</view>
			<view>关联的报题id：{{dataInfo.baoti_id? '未关联' : dataInfo.baoti_id}}</view>
		</view>
		<view class="bottom_box">
			<!-- <view class="botton_btn">设为选题</view> -->
			<u-button size="medium" type="primary" @click="toXt">设为选题</u-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dataInfo:{},
				imgUrl:this.$apiUrl,
				rwId:''
			};
		},
		onLoad(val) {
		this.rwId = JSON.parse(val.id)
		this.getRwdetail()
		// this.dataInfo = data
		// console.log(data)
		},
		methods: {
			backPageRefresh(){
				uni.navigateBack()
			},
			async getRwdetail(){
				let data = {
					id:this.rwId
				}
				const res = await this.$myRequest({
					url:'front/content/xiansuo/renwu/renwuDetail',data
				})
				console.log(res)
				if(res.data.code == 0){
					uni.showToast({
						title:res.data.data.msg
					})
					this.dataInfo = res.data.data
				}
			},
			async toXt(){
				let data = {
					id:this.dataInfo.id,
					user_id:uni.getStorageSync('info')
				}
				const res = await this.$myRequest({
					url:'front/content/xiansuo/baoti/BaoTiforXuanTi',data
				})
				console.log(res)
				if(res.data.data.result == 200){
					uni.showToast({
						title:res.data.data.result.msg
					})
				}
			}
		}
	}
</script>

<style scoped lang="scss">
	.detail{
		width: 100%;
		.content{
			height: var(--status-bar-height);  
			width: 100%;  
			background-color: #F8F8F8!important;
		    // top: 0;
		    // z-index: 999; 
		}
		.content_box{
			height: var(--status-bar-height);  
			width: 100%;  
			position: fixed;  
			background-color: #F8F8F8;  
			top: 0;  
			z-index: 999;  
		}
		.top_left{
			display: inline-block;
			width: 33%;
			height: 80rpx;
			line-height: 80rpx;
		}
		.top_z{
			display: inline-block;
			width: 33%;
			text-align: center;
			height: 80rpx;
			line-height: 80rpx;
		}
		.top_right{
			display: inline-block;
			width: 33%;
			text-align: right;
			height: 80rpx;
			line-height: 80rpx;
		}
		padding: 25rpx;
		.img_box{
			text-align: center;
			.img{
			display: inline-block;
			}
		}
		.titles{
			font-size: 40rpx;
			height: 45rpx;
			line-height: 45rpx;
			text-align: center;
		}
		.bottom_box{
			margin-top: 15rpx;
			width: 100%;
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			.botton_btn{
				color: #fff;
				background: #007AFF;
				width: 220rpx;
				display: inline-block;
				border-radius: 10rpx;
			}
		}
	}
</style>
