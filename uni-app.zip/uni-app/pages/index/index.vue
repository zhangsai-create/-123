<template>
	<view class="content">
		<image class="logos" src="/static/timg.jpg"></image>
		<view class="content_box" style="margin-top:15rpx">
			<view class="text-area" @click="ksfg">
				<image class="logo" src="/static/fg.png"></image>
				<view>快速发稿</view>
				<!-- <image class="logo" src="/static/tj.png"></image> -->
			</view>
			<view class="text-area" @click="fstj">
				<image class="logo" src="/static/tj.png"></image>
				<view>发送图集</view>
			</view>
			<view class="text-area" @click="fssp">
				<image class="logo" src="/static/sp.png"></image>
				<view>发送视频</view>
			</view>
		</view>
		<view class="content_box">
			<view class="text-area" @click="nrzx">
				<image class="logo" src="/static/nr.png"></image>
				<view>内容中心</view>
			</view>
			<view class="text-area" @click="gj">
				<image class="logo" src="/static/gj.png"></image>
				<view>待审稿件 </view>
			</view>
			<view class="text-area" @click="bt">
				<image class="logo" src="/static/gk.png"></image>
				<view>报题</view>
			</view>
		</view>
		<view class="content_box" >
			<view class="text-area" @click="xt">
				<image class="logo" src="/static/xw.png"></image>
				<view>选题</view>
			</view>
			<view class="text-area" @click="zb">
				<image class="logo" src="/static/zb.png"></image>
				<view>直播流</view>
			</view>
			<view class="text-area"  @click="rw">
				<image class="logo" src="/static/cf.png"></image>
				<view>采访任务</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {
			console.log(uni.getStorageSync('info'))
		},
		onShow(){
			console.log(uni.getStorageSync('info'))
		},
		methods: {
			ksfg(){
				uni.navigateTo({
					url: '../ksfg/ksfg'
				})
			},
			fstj(){
				uni.navigateTo({
					url: '../fstj/fstj'
				})
			},
			fssp(){
				uni.navigateTo({
					url: '../fssp/fssp'
				})
			},
			nrzx(){
				uni.navigateTo({
					url: '../nrzx/nrzx'
				})
			},
			bt(){
				uni.navigateTo({
					url: '../bt/bt'
				})
			},
			xt(){
				uni.navigateTo({
					url: '../xt/xt'
				})
			},
			rw(){
				uni.navigateTo({
					url: '../rw/rw'
				})
			},
			gj(){
				uni.navigateTo({
					url: '../dsgj/dsgj'
				})
			},
			zb(){
				uni.navigateTo({
					url: '../zb/zb'
				})
			}
		}
	}
</script>

<style>
	.content {
		/* display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center; */
	}
	.content_box{
		display: flex;
		/* flex-direction: column; */
		align-items: center;
		justify-content: center;
	}
	.logo {
		height: 100rpx;
		width: 100rpx;
		/* margin-top: 200rpx; */
		/* margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx; */
	}
	.logos{
		width:100%;
		height: 400rpx;
	}
	.text-area {
		width: 25%;
		height: 250rpx;
		text-align: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
