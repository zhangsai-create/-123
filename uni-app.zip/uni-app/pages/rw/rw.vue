<template>
<view class="bt">
	<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left" @click="backPageRefresh">返回</view>
		 	<view class="top_z">任务</view>
		 	<view class="top_right" @click="add">+</view>
		 </view>
		 <!-- <view class="content_b"></view> -->
		<view>
			<u-tabs :list="list" :is-scroll="false" :current="current" @change="change"></u-tabs>
		</view>
		<view v-if="current==0">
			<view class="list_box" v-for="item in myDatalist" :key="item.id" >
				<u-image class="img"   @click="rwDetail(item.renwu_id)"   :src="imgUrl+item.photo"  width="140" height="140" :lazy-load="true"></u-image>
				<view class="tit"   @click="rwDetail(item.renwu_id)">
					<view class="title" >{{item.title}}</view>
					<view class="time">{{item.update_time|formatDate}}</view>
				</view>
				<view class="right">
					<view class="title" @click="jump(item)">编辑</view>
					<view class="time" >删除</view>
				</view>
			</view>
		</view>
		<view v-if="current==1">
			<view class="list_box" v-for="item in mine" :key="item.id">
				<u-image class="img" @click="rwDetail(item.renwu_id)" :src="imgUrl+item.photo"  width="140" height="140" :lazy-load="true"></u-image>
				<view class="tit" @click="rwDetail(item.renwu_id)">
					<view class="title">{{item.title}}</view>
					<view class="time">{{item.update_time}}</view>
				</view>
				<view class="right">
					<view class="title" >编辑</view>
					<view class="time" @click="delets(item.id)">删除</view>
				</view>
			</view>
		</view>
		<view v-if="current==2">
			<view class="list_box" v-for="item in gethuidata" :key="item.id">
				<u-image class="img"  :src="imgUrl+item.photo"  width="140" height="140" :lazy-load="true"></u-image>
				<view class="tit">
					<view class="title">{{item.title}}</view>
					<view class="time">{{item.foundtime}}</view>
				</view>
				<view class="right">
					<view class="title">编辑</view>
					<view class="time" @click="delets(item.id)">删除</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
					name: '全部'
				}, {
					name: '我的'
				}, {
					name: '回收站',
				}],
				myDatalist:[],
				gethuidata:[],
				mine:[],
				imgUrl:this.$apiUrl,
				current:0
			}
		},
onLoad() {
	this.getMydata()
},
  //时间戳的处理    
        filters: {
            formatDate: function(value) {
                var date = new Date(value*1000);
              // 时间戳为10为需乘以1000
			  var y=date.getFullYear()+'-'
             var m= (date.getMonth()+1 < 10 ?'0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
                var h = date.getHours()+':';
				var d=date.getDate()+'  ';
				var r=date.getMinutes()+':';
             	var s=date.getSeconds();
					
              
                return y+m+d+h+r+s;
            }

        },
		methods: {
			
			change(index) {
				console.log(index)
				this.current = index;
				if(index==1){
				this.current = index;
				this.getMine()
				}else if(index==0){
			
					this.current = index;
								this.getMydata()
				}else{
					
					this.current = index;
					this.gethuishouData()
				}
			},
		
			//全部
			async getMydata(){
			
				const res = await this.$myRequest({
					url:'front/content/xiansuo/renwu/getrenwu'
				})
				console.log(res)
				if(res.statusCode == 200){
					uni.showToast({
						title:'请求成功'
					})
					this.myDatalist = res.data.data
					// uni.navigateTo({
					// 	url: '../index/index'
					// })
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			},
			
			//我的
			async getMine(){
			let data = {
				user_id:uni.getStorageSync('info')
			}
				const res = await this.$myRequest({
					url:'front/content/xiansuo/renwu/getUseRenwu',data
				})
				console.log(res)
				if(res.statusCode == 200){
					uni.showToast({
						title:'请求成功'
					})
					this.mine = res.data.data
					// uni.navigateTo({
					// 	url: '../index/index'
					// })
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			},
			
			// //回收站列表
			async gethuishouData(){
			
				const res = await this.$myRequest({
					url:'front/content/xiansuo/renwu/getRecyclerenwu'
				})
						console.log(res)
				if(res.statusCode == 200){
					uni.showToast({
						title:'请求成功'
					})
					this.gethuidata = res.data.data
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			},
			//返回
		backPageRefresh(){
			let pages = getCurrentPages(); // 当前页面
			let beforePage = pages[pages.length - 2]; // 前一个页面
			console.log("beforePage",beforePage);
			console.log(pages);
			uni.navigateBack({
				delta: 1,
				// success: function() {
				// 	beforePage.$vm.refreshRequest(); // 执行前一个页面的刷新
				// }
			});
		},
			// 添加
			add(){
				uni.navigateTo({
					url:'../addrw/addrw'
				})
			},
			//删除
			// async delets(val){
			// 	console.log(val)
			// 	let data = {
			// 		id:val,
			// 		userid:uni.getStorageSync('info')
			// 	}
			// 	const res = await this.$myRequest({
			// 		url:'front/base/contenttype/frontcontent/del',data
			// 	})
			// 	console.log(res)
			// 	if(res.data.status==true){
			// 		uni.showToast({
			// 			title:res.data.msg
			// 		})
			// 		this.getMydata()
			// 		if(this.current==0){
			// 			this.getMydata()
			// 		}else if(this.current==1){
			// 			this.getshdata()
			// 		}else{
			// 			this.gethuishouData()
			// 		}
			// 	}
			// },
			// //查看详情
			rwDetail(val){
				console.log(val)
				uni.navigateTo({
					url: '../rwDetail/rwDetail?id=' + JSON.stringify(val)
				})
			},
			// //编辑
			jump(){
			
			uni.navigateTo({
				url:'../rwbj/rwbj'
			})
			}
		}
	}
</script>

<style scoped lang="scss">
	.content{
		height: var(--status-bar-height);  
		width: 100%;  
		background-color: #F8F8F8!important;
	    // top: 0;
	    // z-index: 999; 
	}
	.content_box{
		height: var(--status-bar-height);  
		width: 100%;  
		position: fixed;  
		background-color: #F8F8F8;  
		top: 0;  
		z-index: 999;  
	}
	.content_b{
		height: var(--status-bar-height);
		width: 100%;  
	}
	.content_tab{
		border-bottom: 2rpx solid #f5f5f5;
	}
	.top_box{
		width: 100%;
		padding: 0 20rpx;
		/* display: flex;
		align-items: center;
		justify-content: center; */
	}
	.top_left{
		display: inline-block;
		width: 33%;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_z{
		display: inline-block;
		width: 33%;
		text-align: center;
		height: 80rpx;
		line-height: 80rpx;
	}
	.top_right{
		display: inline-block;
		width: 33%;
		text-align: right;
		height: 80rpx;
		line-height: 80rpx;
		font-size: 45rpx;
	}
.bt{
		.list_box{
			padding: 15rpx;
			border-bottom: 2rpx solid #f5f5f5;
			.img{
				display: inline-block;
			}
			.tit{
				display: inline-block;
				margin-left: 25rpx;
				// position: relative;
				width: 400rpx;
				height: 100%;
				.title{
					margin-bottom:55rpx;
					overflow: hidden;
					text-overflow:ellipsis;
					white-space: nowrap;
				}
				.time{
					overflow: hidden;
					text-overflow:ellipsis;
					white-space: nowrap;
				}
			}
			.right{
				float: right;
				display: inline-block;
				// margin-left: 25rpx;
				// position: relative;
				// width: 40rpx;
				height: 100%;
				.title{
					// display: inline-block;
					width: 80rpx;
					color: #459EFF;
				}
				.time{
					// display: inline-block;
					width: 80rpx;
					margin-top:55rpx;
					color: #459EFF;
				}
			}
		}
	}
</style>
