<template>
	<view class="nrzx">
		<view class="content"></view>
		<view class="content_box"></view>
		 <view class="top_box">
		 	<view class="top_left" @click="backPageRefresh">返回</view>
		 	<view class="top_z">编辑</view>
		 	<view class="top_right">发表</view>
		 </view>
		 <view class="content_b"></view>
		<view class="content_tab">
			<u-tabs :list="list" :is-scroll="false" :current="current" @change="change"></u-tabs>
		</view>
		<view v-if="current==0">
			<view class="list_box" v-for="item in myDatalist" :key="item.id" >
				<u-image class="img"  @click="showDetail(item)"  :src="imgUrl+item.thumb"  width="140" height="140" :lazy-load="true"></u-image>
				<view class="tit" @click="showDetail(item)">
					<view class="title">{{item.title}}</view>
					<view class="time">{{item.foundtime}}</view>
				</view>
				<view class="right">
					<view class="title" @click="toEdit(item)">编辑</view>
					<view class="time" @click="delets(item.id)">删除</view>
				</view>
			</view>
		</view>
		<view v-if="current==1">
			<view class="list_box" v-for="item in shDatalist" :key="item.id">
				<u-image class="img"  :src="imgUrl+item.thumb"  width="140" height="140" :lazy-load="true"></u-image>
				<view class="tit">
					<view class="title">{{item.title}}</view>
					<view class="time">{{item.foundtime}}</view>
				</view>
				<view class="right">
					<view class="title">编辑</view>
					<view class="time" @click="delets(item.id)">删除</view>
				</view>
			</view>
		</view>
		<view v-if="current==2">
			<view class="list_box" v-for="item in gethuidata" :key="item.id">
				<u-image class="img"  :src="imgUrl+item.thumb"  width="140" height="140" :lazy-load="true"></u-image>
				<view class="tit">
					<view class="title">{{item.title}}</view>
					<view class="time">{{item.foundtime}}</view>
				</view>
				<view class="right">
					<view class="title">编辑</view>
					<view class="time" @click="delets(item.id)">删除</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
					name: '我的'
				}, {
					name: '审核列表'
				}, {
					name: '回收站',
				}],
				current: 0,
				page:1,
				myDatalist:[],
				shDatalist:[],
				gethuidata:[],
				imgUrl:this.$apiUrl,
				isMent:null,
				iStatusBarHeight:0
			};
		},
		onLoad() {
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight
			this.getMydata()
			this.judgment()
			console.log(uni.getStorageSync('info'))
			console.log(this.iStatusBarHeight)
		},
		mounted() {
			// let a =  document.getElementsByClassName('uni-page-head-hd')[0].childNodes[0]
			// console.log(a)
			// a.style.display = 'none'
		},
		methods: {
			//返回
			backPageRefresh(){
				let pages = getCurrentPages(); // 当前页面
				let beforePage = pages[pages.length - 2]; // 前一个页面
				console.log("beforePage",beforePage);
				console.log(pages);
				uni.navigateBack({
					delta: 1,
					// success: function() {
					// 	beforePage.$vm.refreshRequest(); // 执行前一个页面的刷新
					// }
				});
			},
			change(index) {
				console.log(index)
				// this.current = index;
				if(index==1){
					if(this.isMent){
						this.getshdata()
						this.current = index;
					}else{
						uni.showToast({
							title:'没有权限'
						})
					}
				}else if(index==0){
					this.getMydata()
					this.current = index;
				}else{
					this.gethuishouData()
					this.current = index;
				}
			},
			//查看权限
			async judgment(){
				let data = {
					userid:uni.getStorageSync('info')
				}
				const res = await this.$myRequest({
					url:'front/base/contenttype/frontcontent/judgment',data
				})
				console.log(res)
				this.isMent = res.data.status
			},
			//我的
			async getMydata(){
				let data = {
					userid:uni.getStorageSync('info'),
					page:this.page,
					pagesize:15
				}
				const res = await this.$myRequest({
					url:'front/base/contenttype/frontcontent/indexajax',data
				})
				console.log(res)
				if(res.statusCode == 200){
					uni.showToast({
						title:'请求成功'
					})
					this.myDatalist = res.data.data
					// uni.navigateTo({
					// 	url: '../index/index'
					// })
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			},
			//审核列表sh
			async getshdata(){
				let data = {
					userid:uni.getStorageSync('info'),
					page:this.page,
					pagesize:15
				}
				const res = await this.$myRequest({
					url:'front/base/contenttype/frontcontent/shenhe',data
				})
				console.log(res)
				if(res.statusCode == 200){
					uni.showToast({
						title:'请求成功'
					})
					this.shDatalist = res.data.data
					// uni.navigateTo({
					// 	url: '../index/index'
					// })
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			},
			//回收站列表
			async gethuishouData(){
				let data = {
					userid:uni.getStorageSync('info'),
					page:this.page,
					pagesize:15,
					status:2
				}
				const res = await this.$myRequest({
					url:'front/base/contenttype/frontcontent/indexajax',data
				})
						console.log(res)
				if(res.statusCode == 200){
					uni.showToast({
						title:'请求成功'
					})
					this.gethuidata = res.data.data
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			},
			//删除
			async delets(val){
				console.log(val)
				let data = {
					id:val,
					userid:uni.getStorageSync('info')
				}
				const res = await this.$myRequest({
					url:'front/base/contenttype/frontcontent/del',data
				})
				console.log(res)
				if(res.data.status==true){
					uni.showToast({
						title:res.data.msg
					})
					this.getMydata()
					if(this.current==0){
						this.getMydata()
					}else if(this.current==1){
						this.getshdata()
					}else{
						this.gethuishouData()
					}
				}
			},
			//查看详情
			showDetail(val){
				console.log(val)
				uni.navigateTo({
					url: '../nrdetail/nrdetail?info=' + JSON.stringify(val)
				})
			},
			//编辑
			toEdit(val){
				console.log(val)
				uni.navigateTo({
					url: '../nredit/nredit?info=' + JSON.stringify(val)
				})
			}
		}
	}
</script>

<style scoped lang="scss">
	.nrzx{
		.content{
			height: var(--status-bar-height);  
			width: 100%;  
			background-color: #F8F8F8!important;
		    // top: 0;
		    // z-index: 999; 
		}
		.content_box{
			height: var(--status-bar-height);  
			width: 100%;  
			position: fixed;  
			background-color: #F8F8F8;  
			top: 0;  
			z-index: 999;  
		}
		.content_b{
			height: var(--status-bar-height);
			width: 100%;  
		}
		.content_tab{
			border-bottom: 2rpx solid #f5f5f5;
		}
		.top_box{
			padding: 0 20rpx;
			width: 100%;
			position: fixed;
			background-color: #F8F8F8;  
			top: var(--status-bar-height);  
			z-index: 999;  
			/* display: flex;
			align-items: center;
			justify-content: center; */
		}
		.top_left{
			display: inline-block;
			width: 33%;
			height: 80rpx;
			line-height: 80rpx;
		}
		.top_z{
			display: inline-block;
			width: 33%;
			text-align: center;
			height: 80rpx;
			line-height: 80rpx;
		}
		.top_right{
			display: inline-block;
			width: 33%;
			text-align: right;
			height: 80rpx;
			line-height: 80rpx;
		}
		.list_box{
			padding: 15rpx;
			border-bottom: 2rpx solid #f5f5f5;
			.img{
				display: inline-block;
			}
			.tit{
				display: inline-block;
				margin-left: 25rpx;
				// position: relative;
				width: 400rpx;
				height: 100%;
				.title{
					margin-bottom:55rpx;
					overflow: hidden;
					text-overflow:ellipsis;
					white-space: nowrap;
				}
				.time{
					overflow: hidden;
					text-overflow:ellipsis;
					white-space: nowrap;
				}
			}
			.right{
				float: right;
				display: inline-block;
				// margin-left: 25rpx;
				// position: relative;
				// width: 40rpx;
				height: 100%;
				.title{
					// display: inline-block;
					width: 80rpx;
					color: #459EFF;
				}
				.time{
					// display: inline-block;
					width: 80rpx;
					margin-top:55rpx;
					color: #459EFF;
				}
			}
		}
	}
</style>
