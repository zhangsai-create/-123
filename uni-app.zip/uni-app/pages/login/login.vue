<template>
	<view>
		<view class="loginBox">
			<view class="box">账号:
				<input  v-model="form.username" class="inputs" label="" placeholder="请输入用户名" required></input >
			</view>
			<!--  -->
			<view class="box">密码:
				<input v-model="form.password" class="inputs" :password="true" label="" placeholder="请输入密码" required></input >
			</view>
			<view class="btn">
				<view :loading="isLoading" @click="login">登录</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				form:{},
				isLoading:false
			};
		},
		onLoad() {
		
		},
		methods: {
			async login(){
				let data = {
					name:this.form.username,
					password:this.form.password
				}
				const res = await this.$myRequest({
							url:'front/base/contenttype/frontcontent/login',data
						})
						console.log(res)
				if(res.data.status == true){
					uni.setStorageSync('info', res.data.user_id)
					uni.showToast({
						title:res.data.msg
					})
					uni.navigateTo({
						url: '../index/index'
					})
				}else{
					uni.showToast({
						title:res.data.msg
					})
				}
			}
		}
	}
</script>

<style>
	.loginBox{
		width: 100%;
	}
	.box{
		width: 100%;
		height: 80rpx;
		line-height: 80rpx;
		padding: 0 20rpx;
		border-bottom:2rpx solid #C0C0C0;
		display:flex;
		 align-items:center;/*垂直居中*/
	}
	.inputs{
		width: 70%;
		display: inline-block;
		vertical-align: middle;
	}
	.btn{
		width: 95%;
		margin-left: 2.5%;
		height: 90rpx;
		text-align: center;
		line-height: 90rpx;
		background-color: #007AFF;
		color: #FFFFFF;
		margin-top: 50rpx;
	}
</style>
