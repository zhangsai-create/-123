// const apiUrl = 'http://111.53.54.166/'
const apiUrl = 'http://lscs.weitac.cn/'
export {
	apiUrl
}