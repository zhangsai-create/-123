
class Global {
    /**
     * 时间戳转标准格式 2016-09-05 13:46:52
     * @returns {{_year: string, _month: string, _day: string, getYear: date.getYear, getMonth: date.getMonth, getDay: date.getDay}}
     */
    timestampFormat(time) {
       var date = new Date(time*1000);
        // 时间戳为10为需乘以1000
        var y=date.getFullYear()+'-'
       var m= (date.getMonth()+1 < 10 ?'0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
          var h = date.getHours()+':';
       				var d=date.getDate()+'  ';
       				var r=date.getMinutes()+':';
       	var s=date.getSeconds();
       					
        
          return y+m+d+h+r+s;
    }
}
let global = new Global()
export {
    global
}