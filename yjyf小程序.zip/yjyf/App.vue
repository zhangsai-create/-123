<script>
	export default {
		// 此处globalData为了演示其作用，不是uView框架的一部分
		globalData: {
			username: '白居易'
		},
		data() {
			return {

			}
		},
		onLaunch() {
			/* #ifdef H5 */
			// uni.setStorageSync('uid', '45025672')
			/* #endif */
			// uni.setStorageSync('uid', '44845114')
			// 1.1.0版本之前关于http拦截器代码，已平滑移动到/common/http.interceptor.js中
			// 注意，需要在/main.js中实例化Vue之后引入如下(详见文档说明)：
			// import httpInterceptor from '@/common/http.interceptor.js'
			// Vue.use(httpInterceptor, app)
			const that = this

			uni.login({
				provider: 'weixin',
				success: function(loginRes) {
					console.log(loginRes,9987);
					that.getuserstatus(loginRes.code)
				}
			});

		},
		methods: {
			async getuserstatus(code) {
				const that = this
				let params = {
					code: code
				}
				let res = await that.$u.api.getuserstatus(params);
				console.log(res,'uid')
				// uni.setStorageSync('uid', '1')
				if (res.code !== 200) return
				uni.setStorageSync('uid', res.data.user_id)
			},
		}
	}
</script>

<style lang="scss">
	@import "uview-ui/index.scss";
	@import "common/demo.scss";

	/*每个页面公共css */
	button::after {
		border: none;
		box-sizing: border-box;
	}
</style>
