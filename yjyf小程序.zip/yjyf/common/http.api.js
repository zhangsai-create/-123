// 如果没有通过拦截器配置域名的话，可以在这里写上完整的URL(加上域名部分)

// 此处第二个参数vm，就是我们在页面使用的this，你可以通过vm获取vuex等操作，更多内容详见uView对拦截器的介绍部分：
// https://uviewui.com/js/http.html#%E4%BD%95%E8%B0%93%E8%AF%B7%E6%B1%82%E6%8B%A6%E6%88%AA%EF%BC%9F
const install = (Vue, vm) => {
	// 此处没有使用传入的params参数
	let getcolumn = (params = {}) => vm.$u.post('/yjyf/information/getcolumn', params); //首页资讯栏目
	let getcontentData = (params = {}) => vm.$u.post('/yjyf/information/getcontentlist', params); //首页资讯列表
	let getUserByCode = (params = {}) => vm.$u.post('/yjyfwechat/getUser', params);
	let updateUserStatus = (params = {}) => vm.$u.post('/yjyfuser/updateuserstatus', params);//获取用户信息
	let getStatuss = (params = {}) => vm.$u.post('/yjyfuser/getstatus', params);
	
	let getPersonalUser = (params = {}) => vm.$u.post('/yjyfuser/getpersonaluser', params);
	let addTopicComment = (params = {}) => vm.$u.post('/yjyfcomment/comment', params);
	let getRecommendList = (params = {}) => vm.$u.post('/yjyftag/getrecommendlist', params);//话题
	let updateUser = (params = {}) => vm.$u.post('/yjyfuser/updateuser', params);//修改用户信息
	let getSecondList = (params = {}) => vm.$u.post('/yjyfcategory/getSecondList', params);
	let getuserfocuslist = (params = {}) => vm.$u.post('/yjyfuser/getuserfocuslist', params);//用户关注的话题列表
	let getuserstatus = (params = {}) => vm.$u.post('/yjyfwechat/getuserstatus', params);
	let setRecord = (params = {}) => vm.$u.post('/yjyfuser/setRecord', params);
	let focusTag = (params = {}) => vm.$u.post('/yjyfuser/focususer', params);// 话题关注
	let getTagDetail = (params = {}) => vm.$u.post('/yjyftag/getdetail', params);
	let getBannerList = (params = {}) => vm.$u.post('/shou/getList', params); // 首页分类
	let getCategoryList = (params = {}) => vm.$u.post('/category/getList', params); // 首页分类
	let getUserRecord = (params = {}) => vm.$u.post('/yjyfuser/getRecord', params); // 首页记录
	// let getdoctorlist = (params = {}) => vm.$u.post('/hospital/getdocterlist', params);
	let getdoctorlist = (params = {}) => vm.$u.post('/yjyf/hospital/getdocterlist', params); //首页推荐医生getdoctorDetail
	let getdoctorDetail = (params = {}) => vm.$u.post('/yjyf/hospital/getdocter', params); //首页推荐医生详情
	// let getdoctorDetail = (params = {}) => vm.$u.post('/hospital/getdocter', params);
	let topicAdd = (params = {}) => vm.$u.post('/yjyftopic/add', params);//添加动态
	let commonUpload = (params = {}) => vm.$u.post('/yjyfcommon/upload', params);
	// let getHospitalList = (params = {}) => vm.$u.post('/hospital/gethospitallist', params);
	let getHospitalList = (params = {}) => vm.$u.post('/yjyf/hospital/gethospitallist', params);//学校列表
	// let followdocter = (params = {}) => vm.$u.post('/hospital/followdocter', params);
	let followdocter = (params = {}) => vm.$u.post('/yjyf/hospital/followdocter', params); //关注专家
	// let getHospitalDetail = (params = {}) => vm.$u.post('/hospital/gethospital', params);
	let getHospitalDetail = (params = {}) => vm.$u.post('/yjyf/hospital/gethospital', params);//学校详情
	// let getdepartmentlist = (params = {}) => vm.$u.post('/hospital/getdepartmentlist', params);
	let getdepartmentlist = (params = {}) => vm.$u.post('/yjyf/hospital/getdepartmentlist', params);//科目
	let getContentlistss = (params = {}) => vm.$u.post('/expertssaid/concentration', params);
	let getContentlist = (params = {}) => vm.$u.post('/yjyf/expertssaid/concentration', params);//共上一堂课列表 （专家说-直播页 横排列表）
	// let getExpertssaidList = (params = {}) => vm.$u.post('/expertssaid/getcontentlist', params);
	let getExpertssaidList = (params = {}) => vm.$u.post('/yjyf/expertssaid/getcontentlist', params);//获取专家说列表
	let getExpertssaid = (params = {}) => vm.$u.post('/yjyf/expertssaid/getcontent', params);//获取专家说详情
	let getExpertssaidZx = (params = {}) => vm.$u.post('/yjyf/information/getcontent', params);//获取首页资讯详情
	// let getExpertssaid = (params = {}) => vm.$u.post('/expertssaid/getcontent', params);
	let getcommentList = (params = {}) => vm.$u.post('/yjyf/expertssaid/getcommentlist', params); //专家说评论
	let getcommentListZx = (params = {}) => vm.$u.post('/yjyf/information/getcommentlist', params); //首页资讯评论
	// let getcommentList = (params = {}) => vm.$u.post('/expertssaid/getcommentlist', params); //专家说评论
	let addcomment = (params = {}) => vm.$u.post('/yjyf/information/addcomment', params); //评论添加
	// let addcomment = (params = {}) => vm.$u.post('/expertssaid/addcomment', params); //评论添加x
	let addTvcomment = (params = {}) => vm.$u.post('/yjyf/television/addcomment', params); //tv评论添加
	let getHotList = (params = {}) => vm.$u.post('/yjyftag/gethotlist', params);//获取热门话题列表
	let getUser = (params = {}) => vm.$u.post('/yjyfuser/getuser', params);
	let getTopicList = (params = {}) => vm.$u.post('/yjyftopic/getlist', params);//获取动态列表
	// let getfollowlist = (params = {}) => vm.$u.post('/hospital/getfollowlist', params);
	let getfollowlist = (params = {}) => vm.$u.post('/yjyf/hospital/getfollowlist', params);//关注专家列表
	let getTvcontentlist = (params = {}) => vm.$u.post('/yjyf/television/getcontentlist', params);
	// let getTvcontentlistGong = (params = {}) => vm.$u.post('/yjyf/television/getcontentlist', params);//共上一堂课
	// let getTvcontent = (params = {}) => vm.$u.post('/television/getcontent', params);
	let getTvcontent = (params = {}) => vm.$u.post('/yjyf/television/getcontent', params);//共上一堂课详情接口
	// let getTvcommentlist = (params = {}) => vm.$u.post('/television/getcommentlist', params);
	let getTvcommentlist = (params = {}) => vm.$u.post('/yjyf/television/getcommentlist', params);//共上 一堂课评论列表
	// let tvPushlike = (params = {}) => vm.$u.post('/television/pushlike', params);
	let tvPushlike = (params = {}) => vm.$u.post('/yjyf/television/pushlike', params);//共上一堂课收藏
	// let expPushlike = (params = {}) => vm.$u.post('/expertssaid/pushlike', params);
	let expPushlike = (params = {}) => vm.$u.post('/yjyf/expertssaid/pushlike', params);//专家说收藏
	let expPushlikeZx = (params = {}) => vm.$u.post('/yjyf/information/pushlike', params);//首页资讯收藏
	let topicZan = (params = {}) => vm.$u.post('yjyftopic/zan', params);
	let getSearchList = (params = {}) => vm.$u.post('/yjyfsearch/getlist', params);
	// let getExpertssaidNoticeList = (params = {}) => vm.$u.post('/expertssaid/notice', params);
	let getExpertssaidNoticeList = (params = {}) => vm.$u.post('/yjyf/expertssaid/notice', params);//话题直播预告
	let getMeetingList = (params = {}) => vm.$u.post('/Meeting/getMeetingList', params);
	// let getCollectlist = (params = {}) => vm.$u.post('/expertssaid/getcollectlist', params);
	let getCollectlist = (params = {}) => vm.$u.post('/yjyf/expertssaid/getcollectlist', params);//收藏列表
	let gettopiclistfortag = (params = {}) => vm.$u.post('/yjyftopic/gettopiclistfortag', params);
	// let expAddsubscribe = (params = {}) => vm.$u.post('/expertssaid/addsubscribe', params);
	let expAddsubscribe = (params = {}) => vm.$u.post('/yjyf/expertssaid/addsubscribe', params);//预约
	// let tvAddsubscribe = (params = {}) => vm.$u.post('/television/addsubscribe', params);
	let tvAddsubscribe = (params = {}) => vm.$u.post('/yjyf/television/addsubscribe', params);//共上一堂课预约接口
	let getTopicDetail= (params = {}) => vm.$u.post('/yjyftopic/gettopicdetail', params);
	// let addUserStatus= (params = {}) => vm.$u.post('/yjyfwechat/getuserstatus', params);
	let addUserStatus= (params = {}) => vm.$u.post('/yjyfuser/adduserstatus', params);
	let getIndexRecord= (params = {}) => vm.$u.post('/user/getRecord', params);
	let getAllRecord= (params = {}) => vm.$u.post('/user/getAllRecord', params);
	
	// let getsubscribelist= (params = {}) => vm.$u.post('/expertssaid/getsubscribelist', params);
	let getsubscribelist= (params = {}) => vm.$u.post('/yjyf/expertssaid/getsubscribelist', params);//预约列表
	let getaddress= (params = {}) => vm.$u.post('/common/getaddress', params); //市级
	// let commentLike= (params = {}) => vm.$u.post('/expertssaid/commentlike', params); 
	let commentLike= (params = {}) => vm.$u.post('/yjyf/expertssaid/commentlike', params); //评论点赞
	
	// 将各个定义的接口名称，统一放进对象挂载到vm.$u.api(因为vm就是this，也即this.$u.api)下
	vm.$u.api = {
		getcolumn,
		getcontentData,
		updateUserStatus,
		getStatuss,
		getUserByCode,
		getuserstatus,
		getuserfocuslist,
		updateUser,
		getCategoryList,
		getUserRecord,
		getdoctorlist,
		followdocter,
		getdoctorDetail,
		getHospitalList,
		getHospitalDetail,
		getdepartmentlist,
		getContentlist,
		getExpertssaid,
		getExpertssaidList,
		getcommentList,
		addTvcomment,
		addcomment,
		addTopicComment,
		getHotList,
		getUser,
		getTopicList,
		getfollowlist,
		getTvcontentlist,
		getTvcontent,
		getTvcommentlist,
		commonUpload,
		topicAdd,
		tvPushlike,
		getaddress,
		expPushlike,
		getRecommendList,
		getBannerList,
		topicZan,
		getSecondList,
		getSearchList,
		getExpertssaidNoticeList,
		getCollectlist,
		getTagDetail,
		focusTag,
		gettopiclistfortag,
		setRecord,
		tvAddsubscribe,
		expAddsubscribe,
		getTopicDetail,
		addUserStatus,
		getAllRecord,
		getIndexRecord,
		getsubscribelist,
		commentLike,
		getPersonalUser,
		expPushlikeZx,
		getExpertssaidZx,
		getcommentListZx,
		getContentlistss
	};
}

export default {
	install
}
