const apiUrl = 'https://static.sdetv.com.cn'
const askUrl = 'https://ym.sdetv.com.cn/v2'
export {
	apiUrl,
	askUrl
}