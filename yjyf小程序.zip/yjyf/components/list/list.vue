<template>
	<view>
		<view class="hot">
			<text class="line">|</text>
			<text class="zx">热门咨询</text>
		</view>
		<view class="cnt" @click="jump">
			<view class="stu1">
				<view style="width: 300rpx;">
					<image class="lf" src="../../static/img/chuzhong2.png" mode="aspectFit"></image>
					<view style="margin:10rpx 0;">
						<text>某某学生甲</text>
					</view>
					<view class="tm">
						<text>11:30</text>
						<text style="margin-left: 10rpx;">32人浏览</text>
					</view>
				</view>
				<view class="dz">
					<image class="img" src="../../static/img/zan1.png"></image>
					<text>187</text>
				</view>
			</view>
			<view class="dis">
				<text>现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				<view class="photo">
					<!-- 缩放 aspectFit 保持纵横比缩放图片，使图片的长边能完全显示出来。也就是说，可以完整地将图片显示出来。 -->
					<image src="../../static/img/login_top.png" mode="aspectFit"></image>
					<image src="../../static/img/login_top.png" mode="aspectFit"></image>
					<image src="../../static/img/login_top.png" mode="aspectFit"></image>
				</view>
				<view class="sj">

				</view>
				<view class="bg">
					<text> 崔冰卷回复:现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				</view>
			</view>
		</view>
		<!-- 一块内容 -->
		<view class="cnt">
			<view class="stu1">
				<view style="width: 300rpx;">
					<image class="lf" src="../../static/img/chuzhong2.png" mode="aspectFit"></image>
					<view style="margin:10rpx 0;">
						<text>某某学生甲</text>
					</view>
					<view class="tm">
						<text>11:30</text>
						<text style="margin-left: 10rpx;">32人浏览</text>
					</view>
				</view>
				<view class="dz">
					<image class="img" src="../../static/img/zan1.png"></image>
					<text>187</text>
				</view>
			</view>
			<view class="dis">
				<text>现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>

				<view class="sj">

				</view>
				<view class="bg">
					<text> 崔冰卷回复:现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				</view>
			</view>
		</view>
		<!-- 第二部分-->
		<view class="hot" style="margin-top: 20rpx;">

			<text class="zx" style="margin-left: 10rpx;">最新咨询</text>
		</view>
		<view class="cnt">
			<view class="stu1">
				<view style="width: 300rpx;">
					<image class="lf" src="../../static/img/chuzhong2.png" mode="aspectFit"></image>
					<view style="margin:10rpx 0;">
						<text>某某学生甲</text>
					</view>
					<view class="tm">
						<text>11:30</text>
						<text style="margin-left: 10rpx;">32人浏览</text>
					</view>
				</view>
				<view class="dz">
					<image class="img" src="../../static/img/zan1.png"></image>
					<text>187</text>
				</view>
			</view>
			<view class="dis">
				<text>现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				<view class="photo">
					<!-- 缩放 aspectFit 保持纵横比缩放图片，使图片的长边能完全显示出来。也就是说，可以完整地将图片显示出来。 -->
					<image src="../../static/img/login_top.png" mode="aspectFit"></image>
					<image src="../../static/img/login_top.png" mode="aspectFit"></image>
					<image src="../../static/img/login_top.png" mode="aspectFit"></image>
				</view>
				<view class="sj">

				</view>
				<view class="bg">
					<text> 崔冰卷回复:现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				</view>
			</view>
		</view>
		<view class="cnt">
			<view class="stu1">
				<view style="width: 300rpx;">
					<image class="lf" src="../../static/img/chuzhong2.png" mode="aspectFit"></image>
					<view style="margin:10rpx 0;">
						<text>某某学生甲</text>
					</view>
					<view class="tm">
						<text>11:30</text>
						<text style="margin-left: 10rpx;">32人浏览</text>
					</view>
				</view>
				<view class="dz">
					<image class="img" src="../../static/img/zan1.png"></image>
					<text>187</text>
				</view>
			</view>
			<view class="dis">
				<text>现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>

				<view class="sj">

				</view>
				<view class="bg">
					<text> 崔冰卷回复:现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
     jump(){
		 console.log(111)
		uni.navigateTo({
			url:'/pages/deal/deal'
		})
	 }
		}
	}
</script>

<style>
	.hot {
		width: 100%;
		height: 50rpx;
		background-color: #F0F0F0;
	}

	.hot .zx {
		color: #959595;
		line-height: 50rpx;
	}

	.hot .line {
		color: #FF5A51;
		margin-right: 20rpx;
	}

	.cnt {
		margin-top: 20rpx;
		width: 95%;
	}

	.cnt .stu1 {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.stu1 view .lf {
		width: 100rpx;
		height: 100rpx;
		float: left;
	}

	.stu1 .tm text {
		font-size: 22rpx;
		color: #D4D4D4;
	}

	.cnt .dz {
		color: #60B9E7;
	}

	.cnt .dz .img {
		width: 40rpx;
		height: 40rpx;
		vertical-align: bottom;
	}

	.cnt .dis {
		margin-left: 100rpx;
	}

	/* 三角形 */
	.cnt .sj {
		width: 0;
		height: 0;
		border-left: 20rpx solid #fff;
		border-right: 20rpx solid #fff;
		border-top: 20rpx solid #fff;
		border-bottom: 20rpx solid #F4F4F4;
		position: relative;
		left: 20%;

	}

	.cnt .dis .bg {
		width: 100%;
		height: 120rpx;
		font-size: 25rpx;
		padding: 20rpx;
		background-color: #F4F4F4;
		color: #919191;
	}

	.cnt .dis .photo {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.cnt .dis .photo image {
		height: 200rpx;
	}
</style>
