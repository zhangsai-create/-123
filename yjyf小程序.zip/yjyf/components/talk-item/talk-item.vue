<template>
	<view class="talk">
		<!-- 大图 -->
		<view class="list-item" v-if="item.style===4" @click.stop="goWhere(item)">
			<view class="subject item-title">{{item.title}}</view>
			<view class="da">
				<view class="d-img-wrp live" v-if="item.style===4">
					<u-image class="play" v-if="item.type==='audio'||item.type==='video'|item.type==='live'" src="/static/img/video_play2.png" width="59" height="59" :lazy-load="true"></u-image>
					<u-image :src="apiUrl+item.thumb"  width="100%" height="300"></u-image>
			
				</view>
			</view>
			<view class="item-foot">
				<view class="left">
					<view class="author" v-text="item.dname" v-if="item.dname"></view>
					<view class="label" @click.stop="goHua(item)" v-if="item.tname">
						<text class="label-item">#{{item.tname}}</text>
					</view>
				</view>
			
				<view class="date">{{item.releasetime | time}}</view>
			</view>
		</view>
		<!-- 三图 -->
		<view class="list-item" v-if="item.style===1" @click.stop="goWhere(item)">
			<view class="subject item-title">{{item.title}}</view>
			<view class="thumb">
				<view class="th-item live" v-for="(son,index) in item.thumbs" :key="index" v-if="item.style===1&&item.type==='text'">
					<u-image class="video" :borderRadius="20" :src="apiUrl+son" width="222" height="150"></u-image>
				</view>
			</view>
			<view class="item-foot">
				<view class="left">
					<view class="author" v-text="item.dname" v-if="item.dname"></view>
					<view class="label" @click.stop="goHua(item)" v-if="item.tname">
						<text class="label-item">#{{item.tname}}</text>
					</view>
				</view>
			
				<view class="date">{{item.releasetime | time}}</view>
			</view>
		</view>
		<!-- 左图 白底-->
		<view class="list-item" v-if="item.style===2&&item.type!=='audio'||item.style===3 " @click.stop="goWhere(item)">
			<view class="live-content bg-white">
				<view class="live" v-if="item.style===2">
					<u-image class="thumb" :borderRadius="20" :src="apiUrl+item.thumb" width="250" height="165"></u-image>
					<u-image class="play" v-if="item.type==='audio'||item.type==='video'|item.type==='live'"  src="/static/img/video_play2.png" width="59" height="59"
					 :lazy-load="true"></u-image>
				</view>
				<view class="content">
					<view class="syn">
						{{item.title}}
					</view>
					<view class="foot">
						<view class="left">
							<view class="author" v-if="item.dname" v-text="item.dname"></view>
							<view class="date">{{item.releasetime | time}}</view>
						</view>
						<view class="label" @click.stop="goHua(item)" v-if="item.tname">
							<text class="label-item">#{{item.tname}}</text>
						</view>
			
			
					</view>
				</view>
				<view class="live right" v-if="item.style===3">
					<u-image class="thumb" :borderRadius="20" :src="apiUrl+item.thumb" width="250" height="165"></u-image>
					<u-image class="play" v-if="item.type==='audio'||item.type==='video'|item.type==='live'"  src="/static/img/video_play2.png" width="59" height="59"
					 :lazy-load="true"></u-image>
				</view>
			</view>
		</view>
		
		<!-- 音频 灰色 -->
		<view class="list-item" v-if="item.type==='audio'&&item.style===2" @click.stop="goWhere(item)">
			<view class="subject item-title">{{item.title}}</view>
			<!-- 音频 灰色 -->
			<view class="item-content" >
				<view class="left audio">
					<u-image class="video" :src="apiUrl+item.thumb" :borderRadius="20" width="211" height="211"></u-image>
					<u-image class="play" src="/static/img/video_play1.png" v-if="item.type==='audio'" width="59" height="59"
					 :lazy-load="true"></u-image>
				</view>
				<view class="con-right" v-if="item.type==='audio'&&item.style===2">
					<view class="con-description">{{item.synopsis}}</view>
					<view class="con-listener">{{item.pv}}收听 <text class="remark">{{item.review||0}}评论 </text></view>
				</view>
			</view>

			<view class="item-foot" v-if="item.type!=='live'">
				<view class="left">
					<view class="author" v-text="item.dname" v-if="item.dname"></view>
					<view class="label" @click.stop="goHua(item)" v-if="item.tname">
						<text class="label-item">#{{item.tname}}</text>
					</view>
				</view>

				<view class="date">{{item.releasetime | time}}</view>
			</view>

		</view>
	</view>
</template>

<script>
	import moment from '@/common/moment';
	export default {
		props: {
			item: Object,
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			}
		},
		data() {
			return {
				apiUrl: this.$apiUrl
			};
		},
		methods: {
			goWhere(item) {
				if (item.type === 'audio') {
					uni.navigateTo({
						url: '../audioDetail/audioDetail?cid=' + item.id
					})
				} else if (item.type === 'live') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + item.id
					})
				} else if (item.type === 'text') {
					uni.navigateTo({
						url: '../articleDetail/articleDetail?cid=' + item.id
					})
				} else if (item.type === 'video') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + item.id
					})
				}

			},
			goHua(item) {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + item.tid
				})
			},
		}
	}
</script>

<style lang="scss">
	.talk {
		padding: 0 36rpx;
		.da{
			position: relative;
			.play{
				position: absolute;
				top: 50%;
				left: 50%;
				transform: 50% 50%;
				z-index: 99;
			}
		}

		.list-item {
			border-bottom: #E9E9E9 solid 1rpx;
			padding: 27rpx 0;
		}

		.subject {
			color: #494949;
			font-size: 27rpx;
			line-height: 60rpx;
		}

		.con-description {
			padding-right: 20rpx;
			height: 70rpx;
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
		}

		.thumb {
			display: flex;
			margin-top: 8rpx;

			.th-item {
				margin-right: 20rpx;
				border-radius: 20rpx;
				overflow: hidden;
			}
		}



		.item-content {
			border-radius: 10rpx;
			margin-top: 19rpx;
			display: flex;
			align-items: center;
			background-color: #F0F0F0;


			.left {
				height: 211rpx;
				width: 211rpx;

				.play {
					position: relative;
					left: 130rpx;
					bottom: 85rpx;
				}

			}


			.con-right {
				padding-left: 20rpx;
			}

			.con-listener {
				font-size: 23rpx;
				margin-top: 22rpx;
				color: #606060;

				.remark {
					padding-left: 30rpx;
				}
			}
		}

		.bg-white {
			background-color: #FFFFFF;
		}

		.live-content {
			display: flex;
			align-items: center;

			.live {
				position: relative;
				height: 165rpx;
				border-radius: 20rpx;
				overflow: hidden;
				vertical-align: top;

				.play {
					position: absolute;
					left: 100rpx;
					bottom: 50rpx;
				}
			}

			.content {
				padding-left: 20rpx;
				flex: 1;

				.syn {
					font-size: 28rpx;
					margin-bottom: 20rpx;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
					color: #282828;
				}

				.foot {
					display: flex;
					justify-content: space-between;
					font-size: 24rpx;
					color: #6c6c6c;

					.left {
						display: flex;
						flex: 1;
						box-sizing: border-box;

						.date {
							color: #494949;
							margin: 0 8rpx;
						}
					}

					.label {
						max-width: 140rpx;
						margin-left: 10rpx;
						background-color: #F0F0F0;
						border-radius: 100rpx;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						padding: 0rpx 20rpx;
						color: #8F8F8F;
					}
				}
			}
		}


		.item-foot {
			display: flex;
			margin-top: 22rpx;
			align-items: center;
			justify-content: space-between;

			.left {
				display: flex;
				flex: 1;

				.author {
					flex: 1;
					color: #5A5A5A;
					max-width: 90rpx;
					font-size: 23rpx;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}

				.label {
					max-width: 400rpx;
					margin-left: 10rpx;
					background-color: #F0F0F0;
					border-radius: 100rpx;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
					padding: 0rpx 20rpx;
					color: #8F8F8F;
				}
			}

			.date {
				font-size: 20rpx;
				color: #494949;
			}
		}



	}
</style>
