<template>
	<view>
		<view class="item" @click="goDetail">
			<view class="left">
				<u-image class="thumb" :src="apiUrl+item.thumb" width="292" height="164" :borderRadius="10"></u-image>
				<u-image class="play" src="/static/img/video_play2.png" width="71" height="71"></u-image>
				<!-- <u-image class="state" v-if="item.label" :src="item.label |stateIcon" width="122" height="38"></u-image> -->
			</view>
			<view class="right">
				<view class="title"> {{item.title}}</view>
				<view class="r-bottom">
					<view>优妈育儿堂</view>
					<view>{{item.releasetime | time}}</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import moment from '@/common/moment';
	export default {
		props: {
			item: Object,
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			},
			stateIcon(label) {
				switch (label) {
					case "直播中":
						return "/static/img/living.png"
					case "未开始":
						return "/static/img/live-soon.png"
					case "回放":
						return "/static/img/replay.png"
					default:
						return null
				}
			}
		},
		data() {
			return {
				apiUrl:this.$apiUrl
			}
		},
		methods: {
			goDetail() {
				uni.navigateTo({
					url: '/pages/momDetail/momDetail?cid=' + this.item.id
				})
			}
		}
	}
</script>

<style>
	.item {
		display: flex;
		align-items: center;
		padding: 25rpx 37rpx;
		border-bottom: 1rpx solid #EBEBEB;
	}

	.left {
		position: relative;
	}

	.play {
		position: absolute;
		top: 50%;
		left: 50%;
		margin-left: -35rpx;
		margin-top: -35rpx;
	}

	.state {
		position: absolute;
		top: 10rpx;
		left: 10rpx;
	}

	.right {
		flex: 1;
		margin-left: 36rpx;
		color: #505050;
		font-size: 25rpx;
		font-weight: 700;
	}

	.r-bottom {
		display: flex;
		margin-top: 34rpx;
		font-weight: 400;
		justify-content: space-between;
	}
</style>
