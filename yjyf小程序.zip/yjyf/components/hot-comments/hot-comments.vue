<template>
	<view>

		<view class="item">
			<u-image width="68rpx" height="68rpx" :src="apiUrl+item.user.openname" shape="circle"></u-image>
			<view class="item-mid">
				<view class="item-mid-title">{{item.user.openname}}</view>
				<view class="item-mid-time">{{item.time| time}}</view>
				<view class="item-mid-des">{{item.comment}}</view>
			</view>
			<view class="zan" @click="like">
				<view>
					<u-image src="/static/img/zan_live.png" width="34" height="34" v-if="item.likestatus===1"></u-image>
					<u-image src="/static/img/zan_no_live.png" width="34" height="34" v-else></u-image>
				</view>
				<view class="zan_count">{{item.likes}}</view>
			</view>
		</view>



	</view>
</template>

<script>
	import moment from '@/common/moment';

	export default {
		props: {
			item: {}
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日 HH:mm');
			}
		},
		data() {
			return {
				apiUrl: this.$apiUrl

			};
		},
		methods: {
			like() {
				this.$emit('like', this.item)
			}
		}
	}
</script>

<style lang="scss">
	.item {
		padding: 33rpx 22rpx;
		display: flex;

		.item-mid {
			margin-left: 22rpx;
			flex: 1;
		}

		.item-mid-title {
			color: #575757;
			font-size: 28rpx;
		}

		.item-mid-time {
			color: #808080;
			font-size: 25rpx;
		}

		.item-mid-des {
			color: #5F5F5F;
			font-size: 25rpx;
		}

		.zan {
			display: flex;

			.zan_count {
				color: #5F5F5F;
				font-size: 25rpx;
				margin-left: 11rpx;
			}
		}
	}
</style>
