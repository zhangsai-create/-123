<template>
	<view class="list-item">
		<view @click="goPostDetail">
			<view class="tou">
				<view class="avatar">
					<u-image class="img" v-if="item.avatar" :src="apiUrl+item.avatar|| info.avatarUrl" width="106" height="106" shape="circle"
					 :lazy-load="true"></u-image>
					<u-image class="img" v-else :src="info.avatarUrl" width="106" height="106" shape="circle" :lazy-load="true"></u-image>
				</view>
				<view class="content">
					<view class="name">
						{{item.user_name}}
					</view>
					<view class="time">
						{{
							item.created_time| time
						}}
					</view>
				</view>
			</view>
			<view class="desc">
				{{item.content}}
			</view>
			<view class="img-wrp" @click.stop="preview" v-if="item.photos.length>0">
				<u-image class="img" v-for="(item,$index) in item.photos" :key="$index" :src="apiUrl+item" width="212" height="212"
				 :lazy-load="true"></u-image>
			</view>
			<view class="video-wrp" @click.stop="">
				<video v-if="item.video" :src="apiUrl+item.video"></video>

			</view>
		</view>

		<view class="tool-wrp">
			<view class="hua">
				<view class="title" @click="goHuaDetail">
					<text class="text">#</text>{{item.tags}}
				</view>
			</view>
			<view class="action">
				<button class="item" open-type="share" :title="item.content" :id="item.id" @click="share">
					<u-image class="img" mode="aspectFit" src="/static/img/zhuan.png" width="28" height="28" :lazy-load="true"></u-image>
					<text class="place">转发</text>
				</button>
				<view class="item" @click="remarkAction">
					<u-image class="img" mode="aspectFit" src="/static/img/pinglun.png" width="28" height="28" :lazy-load="true"></u-image>

					<text class="place">评论</text>
				</view>
				<view class="item" @click="zanClick(item)">
					<u-image class="img" mode="aspectFit" src="/static/img/zan.png" width="28" height="28" :lazy-load="true"></u-image>
					<text class="place">赞</text>
				</view>
			</view>

		</view>
		<view class="remark-wrp">
			<view class="title" v-if="item.zan_list.length>0">
				<u-image class="img" mode="aspectFit" src="/static/img/xihuan.png" width="28" height="28" :lazy-load="true"></u-image>
				<text class="name" v-for="(son, index) in item.zan_list" :key="index">
					{{son.zan_user}}
					<text v-if="item.zan_list.length!==index+1">，</text>
				</text>

			</view>
			<view class="remk" v-if="item.comment_list.length>0" v-for="son2 in item.comment_list" :key="item.id">
				<text class="name">{{son2.user_name}}: </text>
				{{son2.content}}
			</view>
		</view>
		<!-- 评论组件 -->
		<!-- <formTextarea :isVisible="isVisible" @close="close" @onConfirm="addcomment"></formTextarea> -->
		<inputReplay ref="replay" :isVisible="isVisible" @close="close" @addcomment="addcomment"></inputReplay>
	</view>
</template>

<script>
	import moment from '@/common/moment';
	import formTextarea from "../form-textarea/index.vue"
	import inputReplay from "../input-replay/input-replay.vue"

	export default {
		components: {
			formTextarea,
			inputReplay
		},
		props: {
			item: Object,
			cango: {
				type: Boolean,
				default: true
			},

		},
		data() {
			return {
				apiUrl: this.$apiUrl,
				current: {},
				isVisible: false,
				info: uni.getStorageInfoSync('info')


			};
		},
		watch: {
			item(nVal, oVal) {
				//IOS聚焦问题
				let that = this;
				setTimeout(() => {
					that.current = nVal;
				}, 100)
				// this.$emit("update:isVisible", true);
			},
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('YYYY-MM-DD HH:mm');
			}
		},

		methods: {
			goPostDetail() {
				console.log(this.$route)
				if (!this.cango) return
				uni.navigateTo({
					url: '/pages/postDetail/postDetail?id=' + this.item.id
				})
			},
			preview() {
				// 预览图片
				uni.previewImage({
					urls: this.item.photos.map(item =>{
						return this.$apiUrl+item
					}),
					longPressActions: {
						itemList: ['发送给朋友', '保存图片', '收藏'],
						success: function(data) {
							console.log('选中了第' + (data.tapIndex + 1) + '个按钮,第' + (data.index + 1) + '张图片');
						},
						fail: function(err) {
							console.log(err.errMsg);
						}
					}
				});
			},
			remarkAction() {
				this.$refs.replay.inputValue = ''
				this.isVisible = true
			},
			goHuaDetail() {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + this.item.tags
				})
			},
			async addcomment(val) {
				if (!val) {
					uni.showToast({
						title: '请输入评论内容'
					})
				}
				let params = {
					topic_id: this.item.id,
					user_id: uni.getStorageSync('uid'),
					comment: val,
					comment_type: 0
				}
				let res = await this.$u.api.addTopicComment(params);

				uni.showToast({
					title: res.msg,
					icon: 'none'
				})
				this.isVisible = false
				this.$emit('update', val)
			},
			share() {
				// 该对象已集成到this.$u中，内部属性如下
				this.$u.mpShare = {
					title: '', // 默认为小程序名称，可自定义
					path: '/pages/postDetail/postDetail?id=' + this.current.id, // 默认为当前页面路径，一般无需修改，QQ小程序不支持
					// 分享图标，路径可以是本地文件路径、代码包文件路径或者网络图片路径。
					// 支持PNG及JPG，默认为当前页面的截图
					imageUrl: ''
				}
			},
			close() {
				this.isVisible = false
			},
			async zanClick(item) {
				let params = {
					topic_id: item.id,
					user_id: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.topicZan(params);
				uni.showToast({
					title: res.msg,
					icon: 'none'
				})
				this.$emit('update')
			}
		}
	}
</script>

<style lang="scss">
	.list-item {
		margin-bottom: 20rpx;

		.avatar {
			margin-right: 20rpx;
		}

		.tou {
			display: flex;
			align-items: center;

			.content {
				flex: 1;
				font-size: 24rpx;

				.name {
					color: $base-color;
					margin-bottom: 20rpx;
				}

				.time {
					color: $font-color-light;
					font-size: 20rpx;
				}
			}
		}

		.desc {
			font-size: 28rpx;
			margin-top: 20rpx;
			color: $font-color-base;
		}

		.img-wrp {
			display: flex;
			flex-wrap: wrap;
			margin: 10rpx 0;


			.img {
				margin: 0rpx;
				margin-bottom: 20rpx;
				margin-right: 20rpx;

				&:nth-of-type(3n) {
					margin-right: 0;
				}
			}
		}

		.tool-wrp {
			display: flex;
			justify-content: space-between;
			margin: 20rpx 0;
			font-size: 24rpx;
			color: $font-color-base;

			.hua {
				flex: 1;

				.title {
					display: inline-block;
					background-color: $page-color-base;
					line-height: 60rpx;
					padding: 0 20rpx;
					border-radius: 30rpx;

					.text {
						margin-right: 10rpx;
					}
				}
			}

			.action {
				display: flex;
				align-items: center;
				line-height: 60rpx;
				height: 60rpx;

				button {
					background-color: #fff;
					line-height: 60rpx;
				}

				.item {
					display: flex;
					vertical-align: mi;
					margin-left: 30rpx;
					font-size: 24rpx;
					color: #8a8a8a;

					.img {
						display: inline-block;
						margin-right: 10rpx;
						vertical-align: top;
						margin-top: 5rpx;
					}
				}
			}
		}

		.remark-wrp {
			background-color: #f7f7f7;

			.title {
				display: flex;
				align-items: center;
				font-size: 24rpx;
				padding: 20rpx 30rpx;

				.img {
					margin-right: 16rpx;
					vertical-align: top;
				}
			}

			.remk {
				font-size: 24rpx;
				color: $font-color-base;
				padding-bottom: 10rpx;
				padding-left: 20rpx;
				padding-right: 20rpx;

				.name {
					color: $base-color;
					margin-right: 16rpx;
				}

			}
		}
	}
</style>
