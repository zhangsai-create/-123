<template>
	<view>
		<view class="re-wrp">
			<view class="head">
				<u-image class="photo" src="/static/img/hot_comm.png" height="29" width="260"></u-image>
			</view>

			<empty info="还没有评论哦~" v-if="commentList.length===0"></empty>

			<hotComment v-for="item in commentList" :key="item.id" :item="item" @like="commentLike"></hotComment>

		</view>
		<view class="comment">
			<view class="input" @click="remarkAction">
				<view class="place">
					我来说两句
				</view>
			</view>
			<u-image class="like" src="/static/img/like.png" width="37" height="37" @click="pushlike" mode="aspectFit"></u-image>
			<button open-type="share" class="share">
				<u-image src="/static/img/share.png" style="margin-top: 0rpx;" width="37" height="37"></u-image>
			</button>
		</view>
		<!-- 评论组件 -->
		<inputReplay ref="replay" :isVisible="isVisible" @close="close" @addcomment="addcomment"></inputReplay>


	</view>
</template>

<script>
	import inputReplay from "../input-replay/input-replay.vue"

	import formTextarea from "../form-textarea/index.vue"
	import empty from "../../components/rf-empty/index.vue";
	import hotComment from '../../components/hot-comments/hot-comments.vue'

	export default {
		components: {
			formTextarea,
			empty,
			inputReplay,
			hotComment
		},
		props: {
			commentList: Array,
			cid: String,
			type: {
				type: String,
				default: 'exp'
			}
		},
		data() {
			return {
				isVisible: false

			};
		},
		methods: {
			async addcomment(val) {
				console.log('hj', val)
				console.log(this.type)
				if (!val) {
					uni.showToast({
						title: '请输入评论内容'
					})
				}
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					comment: val,
					comment_type: 0
				}
				let res
				if (this.type === 'tv') {
					res = await this.$u.api.addTvcomment(params);
				} else {
					res = await this.$u.api.addcomment(params);
				}

				uni.showToast({
					title: res.data,
					icon: 'none'
				})
				this.isVisible = false
				this.$emit('update')
			},
			remarkAction() {
				this.$refs.replay.inputValue = ''
				this.isVisible = true
			},
			pushlike() {
				if (this.type === 'tv') {
					this.$emit('tvPushlike')

				} else {
					this.$emit('expPushlike')
				}
			},
			async commentLike(item) {
				console.log(item)
				let params = {
					pid: item.id,
					uid: uni.getStorageSync('uid'),
					type: item.likestatus === 1 ? 2 : 1
				}
				let res = await this.$u.api.commentLike(params);
				this.$emit('update')
			},
			close() {
				this.isVisible = false
			}
		}
	}
</script>

<style lang="scss" scoped>
	.head {
		padding: 35rpx 0;
		text-align: center;

		.photo {
			display: inline-block;
		}
	}

	.re-wrp {
		padding-bottom: 90rpx;
	}

	.comment {
		position: fixed;
		background-color: rgba(255, 255, 255, 0.8);
		left: 0;
		width: 100%;
		box-sizing: border-box;
		bottom: 0;
		height: 80rpx;
		display: flex;
		padding: 20rpx 30rpx;
		align-items: center;

		.input {
			background-color: #F0F0F0;
			border-radius: 30rpx;
			display: flex;
			justify-content: space-between;
			color: #a8a8a8;
			padding: 10rpx 20rpx;
			flex: 1;
			align-items: center;
		}

		.like {
			margin-left: 40rpx;
		}

		button {
			background-color: rgba(0, 0, 0, 0);
			line-height: 50rpx;
			padding: 0;
		}

		.share {
			margin: 0 34rpx 0 27rpx;
		}


	}
</style>
