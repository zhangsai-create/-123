<template>
	<view>
		<u-popup v-model="isVisible" mode="bottom" border-radius="14" @close="close">
			<view class="re-wrp" :style="{paddingBottom:bottomHeight+'rpx'}" cursor-spacing=100>
				<view class="title">
					发评论
				</view>
				<view class="input-wrp">
					<u-input v-model="inputValue" :adjust-position='false' type="textarea" :placeholder="commentDesc" />

				</view>
				<view class="btn-wrp">
					<view class="btn" @click="addcomment">
						发表
					</view>
				</view>

			</view>
		</u-popup>
	</view>
</template>

<script>
	export default {
		props: {
			isVisible: {
				type: Boolean,
				default: false
			},
			bottomHeight:{
				type: Number,
				default: 30
			},
			//输入框提示语
			commentDesc: {
			    type: String,
			    default: '想说点什么……'
			},
		},
		data() {
			return {
				inputValue: ''
			};
		},
		methods: {
			close() {
				this.$emit('close')
			},
			addcomment() {
				this.$emit('addcomment', this.inputValue)
			}
		}
	}
</script>

<style lang="scss">
	.re-wrp {
		padding: 0 30rpx;

		.title {
			line-height: 80rpx;
		}

		.input-wrp {
			background-color: #f8f8f8;
			padding: 0 20rpx;
		}

		.btn-wrp {
			text-align: right;
			margin-top: 30rpx;
		}

		.btn {
			display: inline-block;
			width: 130rpx;
			text-align: center;
			background-color: $base-color;
			line-height: 60rpx;
			color: #FFFFFF;
			border-radius: 40rpx;
		}
	}
</style>
