<template>
	<view class="doctor-item" @click="getDoctorDetail(itemBean.id)">
		<u-image class="avatar" :src="apiUrl+itemBean.thumb" width="95" height="95" shape="circle" :lazy-load="true"></u-image>
		<view class="right">
			<view> {{itemBean.name}} {{itemBean.position}} </view>
			<view class="department"> {{itemBean.dname}} {{itemBean.hname}} </view>
			<view class="good-list"> 擅长：{{itemBean.expert}} </view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'doctor-item',
		props: {
			itemBean: Object,
		},
		data() {
			return{
				apiUrl: this.$apiUrl
			}
		},
		onLoad() {
		},
		methods: {
			getDoctorDetail(id) {
				console.log(id)
				uni.navigateTo({
					url: '/pages/doctorDetail/doctorDetail?did=' + id
				})
			},
		}
	}
</script>

<style lang="scss">
	.doctor-item {
		display: flex;
		border-bottom: #EAEAEA 1rpx solid;
		padding: 30rpx;
		align-items: center;

		.right {
			width: 0;
			font-size: 24rpx;
			margin-left: 39rpx;
			color: #282828;
			flex: 1;

			.department {
				margin-top: 10rpx;
			}

			.good-list {
				margin-top: 10rpx;
				color: #949494;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
			}
		}
	}
</style>
