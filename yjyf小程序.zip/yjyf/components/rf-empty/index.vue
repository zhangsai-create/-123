<template>
	<view class="empty">
		<view class="empty-content" :class="{ emptyOnly: !isRecommendShow }">
			<u-image class="img" mode="aspectFit" src="/static/img/empty.png" width="200" height="200" :lazy-load="true"></u-image>
			<text class="empty-content-info">{{ info }}</text>
		</view>
	</view>
</template>

<script>
export default {
	props: {
		src: {
			type: String,
			default: 'empty'
		},
		isRecommendShow: {
			type: Boolean,
			default: true
		},
		info: {
			type: String,
			default: ''
		},
		bottom: {
			type: Number,
			default: 0
		}
	},
	data() {
		return {};
	},
	computed: {}
};
</script>

<style lang="scss">
.empty {
	background-color: $color-white;
	.empty-content {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		padding: 20rpx 0 80rpx;
		.empty-content-info {
			font-size: 24rpx;
			color: $font-color-base;
		}
		.img{
			margin: 30rpx;
		}
	}
	.emptyOnly {
		position: fixed;
		left: 0;
		top: 0;
		right: 0;
		bottom: 0;
	}
}
</style>
