<template>
	<view>
		<view class="item">
			<view class="left">
				<u-image  width="292" height="164" style="border-radius: 10rpx;"></u-image>
				<u-image class="play" src="/static/img/video_play2.png" width="71" height="71"></u-image>
				<u-image class="state" src="/static/img/living.png" width="122" height="38"></u-image>
			</view>
			<view class="right">
				<view class="title"> 总觉得自己奶少宝宝不够吃,专家教你避开雷区 </view>
				<view class="r-bottom">
					<view>优妈育儿堂</view>
					<view>8月16日19：00</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	.item {
		display: flex;
		align-items: center;
		padding: 25rpx 37rpx;
		border-bottom: 1rpx solid #C8C8C8;
	}

	.left {
		position: relative;
		border-radius: 10rpx;
	}

	.play {
		position: absolute;
		top: 50%;
		left: 50%;
		margin-left: -35rpx;
		margin-top: -35rpx;
	}

	.state {
		position: absolute;
		top: 10rpx;
		left: 10rpx;
	}

	.right {
		margin-left: 36rpx;
		color: #505050;
		font-size: 25rpx;
		font-weight: 700;
	}

	.r-bottom {
		display: flex;
		margin-top: 34rpx;
		font-weight: 400;
		justify-content: space-between;
	}
</style>
