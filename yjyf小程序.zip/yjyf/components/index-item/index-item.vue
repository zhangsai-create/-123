<template>
	<view class="list-item">
		<view @click="goPostDetail" class="one_box">
			<view class="sec-two">
				<u-image src="/static/img/login_top.png" width="100%" height="180"   shape="circle" class="images" :lazy-load="true"></u-image>
			</view>
			<view class="img_info">适时断奶对宝,对妈都好,不哭不闹不强制断奶的方法都在这里了!</view>
		</view>
		<view class="two_box">
			<view class="img_info">适孩子黄疸超过一个与不好应该怎么办？</view>
			<view class="content">
				<view class="img-wrp">
					<u-image class="icon" src="/static/img/login_top.png" mode="aspectFill" width="250" height="164" :lazy-load="true"></u-image>
				</view>
				<view class="right_box">
					<view class="">
						宝妈如何正确对待黄疸
					</view>
					<view>
						9373收听 &nbsp 644评论
					</view>
				</view>
			</view>
			<view class="box_bottom">
				<view class="box_name">李金斗</view>
				<!-- <talkItem :item="item" ></talkItem> -->
				<!-- <view class="content-wrp">
					<block v-for="item in expertssaidList" :key="item.id">
						<talkItem :item="item" @goWhere="goContentDetail" @goHua="goHua"></talkItem>
					</block>
					<u-loadmore :status="status" v-if="expertssaidList.length>=pageSize" />
					
				</view> -->
				<view class="box_time">8月13日 11:30</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import talkItem from '../talk-item/talk-item.vue'
	export default {
		// components: {talkItem},
		data() {
			return {
			item:{style:1,type:'text',title:'456'}
			}
		}
	}
</script>

<style lang="scss">
	.list-item{
		padding: 0 20rpx;
		.one_box{
			border-bottom: 1px solid #DADADA;
			width: 100%;
			.sec-two{
				margin: 0;
				padding: 4rpx 0;
				// display: flex;
				// justify-content: center;
			}
			.img_info{
				margin-top: 10rpx;
				// border-bottom: 1px solid #DADADA;
			}
		}
		.two_box{
			border-bottom: 1px solid #DADADA;
			.img_info{
				margin: 10rpx 0;
			}
			.content{
				display: flex;
				justify-content: center;
				.img-wrp{
					display: inline-block;
				}
				.right_box{
					width: 460rpx;
					display: inline-block;
					padding: 50rpx 0;
					// line-height: 164rpx;
					// float: right;
				}
			}
			.box_bottom{
				height: 60rpx;
				line-height: 60rpx;
				.box_name{
					display: inline-block;
				}
				.box_time{
					display: inline-block;
					float: right;
				}
			}
		}
	}
</style>
