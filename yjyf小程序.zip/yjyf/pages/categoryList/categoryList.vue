<template>
	<view class="content">
		<empty v-if="categoryList.length===0" info="还没有相关内容哦"></empty>
		<view class="c-item" v-for="item in categoryList" :key="item.id">
			<view class="title">
				{{item.name}}
			</view>
			<view class="s-item">

				<view class="h-item" v-for="son in item.children" :key="son.id" @click="goHuaDetail(item.id)">
					<view class="title">
						# {{son.name}}
					</view>
					<view class="next-title">
						<view class="text">
							{{son.description}}
						</view>
						<u-image class="img" :src="apiUrl+son.image" width="48" height="48" :lazy-load="true"></u-image>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue";
	export default {
		components:{
			empty,
		},
		data() {
			return {
				pid: '',
				apiUrl: this.$apiUrl,
				categoryList: [],
				is_mama: 0
			};
		},
		onLoad(val) {
			console.log(val)
			uni.setNavigationBarTitle({
				title: val.name
			})
			this.pid = val.id
			this.is_mama = val.ismum
			this.getCategoryList()
		},
		methods:{
			goHuaDetail(id){
				console.log(id)
				uni.navigateTo({
					url:'/pages/huaDetail/huaDetail?tid='+id
				})
			},
			async getCategoryList() {
				let params = {
					is_mama: this.is_mama,
					uid: uni.getStorageSync('uid'),
					pid: this.pid
				}
				let res = await this.$u.api.getSecondList(params);
				this.categoryList =res.data
			},
		}
	}
</script>

<style lang="scss">
	.content{
		padding: 0 $spacing-lg;
	}
	.c-item{
		color: #616161;
		.title{
			line-height: 90rpx;
		}
	}
	.s-item {
		display: flex;
		flex-wrap: wrap;

		.h-item {
			display: flex;
			align-items: center;
			display: inline-block;
			width: 31%;
			padding-left: 20rpx;
			margin-top: 20rpx;
			background-color: #FDF3F8;
			border-radius: 20rpx;
			position: relative;
			margin-bottom: 20rpx;
			margin-right: 16rpx;
			background-color: #FFFFFF;
			color: #616161;
			border: 1rpx solid #d4d4d4;
			min-height: 116rpx;
			
			.title {
				font-size: 32rpx;
				height: 30rpx;
				line-height: 30rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				margin-top: 20rpx;
			}

			.next-title {
				margin-top: 20rpx;
				font-size: 22rpx;
				color: #989898;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				display: flex;
				align-items: center;
				justify-content: space-between;
			}



		}
	}
</style>
