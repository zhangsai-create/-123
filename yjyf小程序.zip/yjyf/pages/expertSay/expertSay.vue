<template>
	<view>
		<u-navbar :is-back="false" title="养教有方" :border-bottom="false"></u-navbar>
		<view class="search-wrap">
			<view class="right" @click="goSearch">
				<u-icon name="search" color="#676767" size="26"></u-icon><text class="place">寻找你关心的话题</text>
			</view>
		</view>
		<u-tabs :list="tabList" active-color="#11B5FF" :is-scroll="false" :current="current" @change="tabChange"></u-tabs>
		<view class="reco-wrp" v-if="current===0">
			<view class="sec-one">
				<!-- 电视直播 -->
				<view class="r-item tv" v-if="television.title" @click="goMum(television)">
					<u-image class="icon-left" src="/static/img/naozhong.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
					<view class="top">
						<text class="time">{{television.starttime|time}}</text>
						<!-- <view class="status">
							<u-image class="icon" v-if="television.label==='直播中'" src="/static/img/boico.png" mode="aspectFit" width="30"
							 height="30" :lazy-load="true"></u-image>
							<u-image class="icon" v-else src="/static/img/shu.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
							{{television.label}}
						</view> -->
					</view>
					<view class="content">
						<view class="img-wrp">
							<u-image class="icon" :src="apiUrl+television.thumb" :borderRadius="20" mode="aspectFill" width="200" height="250"
							 :lazy-load="true"></u-image>

						</view>
						<view class="right">
							<view class="title">

								{{television.title}}

							</view>
							<view class="info">
								<view class="author">
									<u-image class="icon" src="/static/img/yin.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
									《优妈育儿堂》
								</view>
							</view>
							<view class="status-wrp">
								<view class="left">
									<view class="left" v-if="television.label==='未开始'">
										<u-image class="icon" src="/static/img/yyz.png" width="80" height="40" :lazy-load="true"></u-image>
										<view class="text" v-if="television.subscribestatus===0">
											{{television.subscribe}}
										</view>
									</view>
									<!-- <view class="left" v-if="television.label==='直播中'">
										<u-image class="icon" src="/static/img/zhiboz.png" width="80" height="40" :lazy-load="true"></u-image>
										<view class="text">
											{{television.pv}}
										</view>
									</view> -->

								</view>
								<view class="right">
									<view class="btn green" @click.top="tvAddsubscribe(television)" v-if="television.label==='未开始'&&television.subscribestatus!==2">
										{{television.subscribestatus===0? '预约提醒': '已预约'}}
									</view>
									<u-image class="icon" v-if="expertssaid.label==='回放'" mode="aspectFit" src="/static/img/ljgk.png" width="196"
									 height="54" :lazy-load="true"></u-image>
								</view>
							</view>
						</view>
					</view>
				</view>
				<!-- 专家说 -->
				<view class="r-item zhuan" v-if="expertssaid.title" @click="goContentDetail(expertssaid)">
					<u-image class="icon-left" src="/static/img/naozhong.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
					<view class="top">
						<text class="time">{{expertssaid.starttime|time}}</text>
						<view class="status" v-if="expertssaid.label">
							<!-- <u-image class="icon" v-if="expertssaid.label==='直播中'" src="/static/img/boico.png" mode="aspectFit" width="30"
							 height="30" :lazy-load="true"></u-image> -->
							<u-image class="icon" v-if="expertssaid.label!=='直播中'" src="/static/img/shu.png" mode="aspectFit" width="30"
							 height="30" :lazy-load="true"></u-image>
							{{expertssaid.label}}
						</view>
					</view>
					<view class="content">
						<view class="img-wrp">
							<u-image class="icon" :src="apiUrl+expertssaid.thumb" mode="aspectFill" width="200" height="250" :lazy-load="true"></u-image>

						</view>
						<view class="right">
							<view class="title">

								{{expertssaid.title}}

							</view>
							<view class="info">
								<view class="author">
									<u-image class="icon" src="/static/img/geren.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
									{{expertssaid.dname}}
								</view>
								<view class="hua" @click="goHuaDetail(expertssaid.tid)">
									#{{expertssaid.tname}}
								</view>
							</view>
							<view class="status-wrp">
								<view class="left">
									<view class="left" v-if="expertssaid.label==='直播中'">
										<u-image class="icon" src="/static/img/zhiboz.png" width="80" height="40" :lazy-load="true"></u-image>

										<view class="text">
											{{expertssaid.pv}}
										</view>
									</view>
									<view class="left" v-if="expertssaid.label==='未开始'">
										<u-image class="icon" src="/static/img/yyz.png" width="80" height="40" :lazy-load="true"></u-image>

										<view class="text">
											{{expertssaid.subscribe}}
										</view>
									</view>
								</view>
								<view class="right">
									<view class="btn green" v-if="expertssaid.label!=='回放'&&expertssaid.subscribestatus!==2" @click.stop="expAddsubscribe(expertssaid)">
										{{expertssaid.subscribestatus===0? '预约提醒': '已预约'}}
									</view>
									<u-image class="icon" v-if="expertssaid.label==='回放'" mode="aspectFit" src="/static/img/ljgk.png" width="196"
									 height="54" :lazy-load="true"></u-image>

								</view>
							</view>
						</view>
					</view>
				</view>
			</view>

		</view>

		<view class="zhi-wrp" v-if="current===1">
			<u-swiper :list="tvcontentlist" top synopsis @listClick="goTvDetail" effect3d-previous-margin=180 :effect3d="true"></u-swiper>

			<u-waterfall v-model="flowList" ref="uWaterfall">
				<template v-slot:left="{ leftList }">
					<view class="demo-warter" v-for="(item, index) in leftList" :key="index" @click="goContentDetail(item)">
						<!-- 警告：微信小程序不支持嵌入lazyload组件，请自行如下使用image标签 -->
						<!-- #ifndef MP-WEIXIN -->
						<u-lazy-load threshold="-450" border-radius="10" :image="item.img" :index="index"></u-lazy-load>
						<!-- #endif -->
						<!-- #ifdef MP-WEIXIN -->
						<view class="demo-img-wrap">
							<image class="status" v-if="item.label==='回放'" src="/static/img/zhf.png" mode="aspectFit" height="38"></image>
							<!-- <image class="status" v-if="item.label!=='回放'" src="/static/img/zzbz.png" mode="aspectFit" height="38"></image> -->

							<image class="play" src="/static/img/video_play2.png" mode="aspectFit"></image>
							<image class="demo-image" :src="item.img" mode="widthFix"></image>
						</view>
						<!-- #endif -->
						<view class="zhi-title">{{ item.title }}</view>
						<view class="author">
							<view class="left">
								<image class="ren" src="/static/img/geren.png" mode="aspectFit" style="width: 32rpx;height: 32rpx;"></image>

								{{ item.dname }}
							</view>
							<view class="right" @click="goHuaDetail(item.tid)">
								# {{item.tname}}
							</view>
						</view>
						<!-- 微信小程序无效，因为它不支持在template中引入组件 -->
						<!-- <view class="u-close">
							<u-icon name="close-circle-fill" color="#fa3534" size="34" @click="remove(item.id)"></u-icon>
						</view> -->
					</view>
				</template>
				<template v-slot:right="{ rightList }">
					<view class="demo-warter" v-for="(item, index) in rightList" :key="index" @click="goContentDetail(item)">
						<!-- #ifndef MP-WEIXIN -->
						<u-lazy-load threshold="-450" border-radius="10" :image="item.img" :index="index"></u-lazy-load>
						<!-- #endif -->
						<!-- #ifdef MP-WEIXIN -->
						<view class="demo-img-wrap">
							<image class="status" v-if="item.label==='回放'" src="/static/img/zhf.png" mode="aspectFit" height="38"></image>
							<!-- <image class="status" v-if="item.label!=='回放'" src="/static/img/zzbz.png" mode="aspectFit" height="38"></image> -->

							<image class="play" src="/static/img/video_play2.png" mode="aspectFit"></image>

							<image class="demo-image" :src="item.img" mode="widthFix"></image>
						</view>
						<!-- #endif -->
						<view class="zhi-title">{{ item.title }}</view>
						<view class="author">
							<view class="left">
								<image class="ren" src="/static/img/geren.png" mode="aspectFit" style="width: 32rpx;height: 32rpx;"></image>
								{{ item.dname }}
							</view>
							<view class="right" @click="goHuaDetail(item.tid)">
								# {{item.tname}}
							</view>
						</view>
						<!-- 微信小程序无效，因为它不支持在template中引入组件 -->
						<!-- <view class="u-close">
							<u-icon name="close-circle-fill" color="#fa3534" size="34" @click="remove(item.id)"></u-icon>
						</view> -->
					</view>
				</template>
			</u-waterfall>

		</view>
		<view class="sec-two" v-if="current!==1">
			<u-image class="title" v-if="current==0" src="/static/img/z-title.png" height="88" width="750"></u-image>
			<view class="content-wrp">
				<block v-for="item in expertssaidList" :key="item.id">
					<talkItem :item="item"></talkItem>
				</block>
			</view>

		</view>
		<u-loadmore :status="status" v-if="expertssaidList.length>=pageSize" />

	</view>
</template>

<script>
	import moment from '@/common/moment';
	import talkItem from '../../components/talk-item/talk-item.vue'
	export default {
		components: {
			talkItem
		},
		data() {
			return {
				current: 0,
				apiUrl: this.$apiUrl,
				// 类型 ：text：文章 video：视频 live：直播流 audio：音频
				type: '',
				flowList: [],
				audioList: [{}],
				list: [],
				hotList: [],
				tvcontentlist: [],
				tabList: [{
						name: '热门推荐'
					}, {
						name: '同上一堂课'
					}, {
						name: '音频资料'
					},
					{
						name: '图文资讯'
					}
				],
				page: 1,
				pageSize: 10,
				television: {},
				expertssaid: {},
				expertssaidList: [],
				flowList: [],
				status: '',
				nomore: false,
				statuss:''
			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			},
			stateIcon(label) {
				switch (label) {
					case "直播中":
						return "/static/img/zzbz.png"
					case "未开始":
						return "/static/img/yyz.png"
					case "回放":
						return "/static/img/zhf.png"
					default:
						return "/static/img/ljgk.png"
				}
			}
		},
		onLoad() {
			// this.getExpertssaidList()
			// uni.startPullDownRefresh()
			// this.getTvcontentlist()
			// this.getHotExpertssaidList()
			this.tabChange(this.current)

		},
		onShow() {
			const that = this
			console.log(uni.getStorageSync('uid'),'99888')
			if (!uni.getStorageSync('uid') >= 0) {
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						console.log(loginRes);
						that.getuserstatus(loginRes.code)
					}
				});
			} 
		},
		onPullDownRefresh() {
			console.log('refresh');
			this.page = 1
			this.getExpertssaidList()
		},
		// 触底
		onReachBottom() {
			const that = this
			this.status = 'loading';
			console.log(that.page, this.nomore)
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					that.page += 1;

					that.getExpertssaidList()
					that.status = 'loading';
				}
			}, 2000)
		},
		methods: {
			async getuserstatus(code){
				let params = {
					code: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getStatuss(params);
				console.log(res,'9999')
				this.statuss = res.data.status
				// this.getUser()
			},
			addRandomData() {
				for (let i = 0; i < 10; i++) {
					let index = this.$u.random(0, this.expertssaidList.length - 1);
					// 先转成字符串再转成对象，避免数组对象引用导致数据混乱
					let item = JSON.parse(JSON.stringify(this.expertssaidList[index]))
					item.id = this.$u.guid();
					this.flowList.push(item);
				}
			},
			goMum(item) {
				uni.navigateTo({
					url: '/pages/momDetail/momDetail?cid=' + item.id
				})
			},

			// 共上一堂课
			async getHotExpertssaidList() {
				let params = {
					uid: uni.getStorageSync('uid'),
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getContentlist(params);
				console.log(res,'优妈')
				this.television = res.data.television
				this.expertssaid = res.data.expertssaid
			},

			// 预约tv
			async tvAddsubscribe(item) {
				let params = {
					cid: item.id,
					type: item.subscribestatus === 1 ? 2 : 1,
					uid: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.tvAddsubscribe(params);
				uni.showToast({
					title: res.data,
					icon: 'none'
				})
				uni.requestSubscribeMessage({
					tmplIds: ['qAI8nWEplo_OIhugOlza7jdJSg50y3WxmQIxUxoJ9uc'],
					success(res) {
						console.log(res)
					},
					fail(err) {
						console.log(err)
					}
				})
				this.getHotExpertssaidList()
			},
			// 预约专家说
			async expAddsubscribe(item) {
				let params = {
					cid: item.id,
					type: item.subscribestatus === 1 ? 2 : 1,
					uid: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.expAddsubscribe(params);
				uni.showToast({
					title: res.data,
					icon: 'none'
				})
				uni.requestSubscribeMessage({
					tmplIds: ['qAI8nWEplo_OIhugOlza7jdJSg50y3WxmQIxUxoJ9uc'],
					success(res) {
						console.log(res)
					},
					fail(err) {
						console.log(err)
					}
				})
				this.getHotExpertssaidList()
			},
			async getExpertssaidList() {
				console.log(this.statuss,'666')
				console.log(this.page, this.nomore)
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					hot: this.current === 0 ? 1 : 0,
					mold:1,
					type: this.type,
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getExpertssaidList(params);

				uni.stopPullDownRefresh();
				let list = res.data.map(item => {
					item.img = this.apiUrl + item.thumb
					return item
				})
				this.expertssaidList = this.page === 1 ? list : this.expertssaidList.concat(list)

				if (res.data.length < this.pageSize) {
					this.nomore = true
				} else {
					this.nomore = false
				}
				this.flowList = this.expertssaidList
				console.log(this.expertssaidList)
			},
			goHuaDetail(id) {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + id
				})
			},
			goContentDetail(val) {
				console.log(val)
				if (val.type === 'audio') {
					uni.navigateTo({
						url: '../audioDetail/audioDetail?cid=' + val.id
					})
				} else if (val.type === 'live') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + val.id
					})
				} else if (val.type === 'text') {
					uni.navigateTo({
						url: '../articleDetail/articleDetail?cid=' + val.id
					})
				} else if (val.type === 'video') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + val.id
					})
				}
			},

			async getTvcontentlist() {
				let params = {
					famous: 1
				}
				let res = await this.$u.api.getTvcontentlist(params);
				this.tvcontentlist = res.data.map(item => {
					item.image = this.$apiUrl + item.thumb
					return item
				})
			},
			goTvDetail(val) {
				uni.navigateTo({
					url: '/pages/momDetail/momDetail?cid=' + this.tvcontentlist[val].id
				})
			},
			goSearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			tabChange(val) {
				console.log(val)
				this.current = val
				this.expertssaidList = []
				this.page = 1
				if (val === 0) {
					this.type = ''
					this.getHotExpertssaidList()
				} else if (val === 1) {
					this.flowList = []
					this.type = 'videolive'
					this.getTvcontentlist()
				} else if (val === 2) {
					this.type = 'audio'
				} else {
					this.type = 'text'
				}
				this.getExpertssaidList()
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #FFFFFF;
	}

	.search-wrap {
		background-color: #FFFFFF;
		display: flex;
		padding: 10rpx $spacing-lg;
		line-height: 61rpx;
		color: $font-color-base;
		font-size: 24rpx;

		.right {
			background-color: $uni-bg-color-grey;
			flex: 1;
			border-radius: 32rpx;
			padding: 0 $spacing-lg;

			icon {
				margin-right: 20rpx;
			}

			.place {
				margin-left: 20rpx;
			}
		}
	}

	.reco-wrp {
		margin-top: 20rpx;
		background-color: #FFFFFF;

		.sec-one {
			padding: 0 $spacing-lg;
			border-bottom: 20rpx solid $page-color-base;

			.r-item {
				position: relative;
				padding-left: 40rpx;
				padding-bottom: 20rpx;

				&::before {
					content: '';
					width: 1rpx;
					height: 100%;
					position: absolute;
					top: 10rpx;
					left: 14rpx;
					background-color: $page-color-base;

				}

				.icon-left {
					position: absolute;
					top: 6rpx;
					left: 0;
					background-color: #FFFFFF;
				}

				.top {
					display: flex;
					align-items: center;
					margin-bottom: 20rpx;

					.time {
						color: $font-color-light;
						margin-right: 30rpx;
					}

					.status {
						color: $font-color-base;
						display: flex;

						.icon {
							margin-right: 20rpx;
						}
					}
				}

				.content {
					display: flex;

					.right {
						margin-left: 20rpx;
						flex: 1;

						.title {
							font-size: 28rpx;
							color: $font-color-base;
							min-height: 60rpx;
							margin-bottom: 20rpx;
							overflow: hidden;
							display: -webkit-box; //将元素设为盒子伸缩模型显示
							-webkit-box-orient: vertical; //伸缩方向设为垂直方向
							-webkit-line-clamp: 2; //超出3行隐藏，并显示省略号
						}

						.info {
							display: flex;
							justify-content: space-between;
							align-items: center;
							color: $font-color-light;
							font-size: 24rpx;

							.author {
								display: flex;
								font-size: 24rpx;
							}

							.hua {
								background: $page-color-base;
								padding: 6rpx 20rpx;
								border-radius: 30rpx;
							}
						}

						.status-wrp {
							display: flex;
							justify-content: space-between;
							align-items: center;
							margin-top: 30rpx;

							.left {
								display: flex;
								flex: 1;
								height: 40rpx;
								color: #fff;
								vertical-align: top;
								align-items: top;

								.text {
									background-color: #a8a8a8;
									height: 40rpx;
									line-height: 40rpx;
									font-size: 20rpx;
									padding: 0 16rpx;
								}


							}

							.right {
								.btn {
									// margin-right: 20rpx;s
									width: 160rpx;
									text-align: center;
									color: #FFFFFF;
									border-radius: 40rpx;
									line-height: 54rpx;
									font-size: 30rpx;

								}

							}
						}
					}
				}
			}

		}

		.sec-two {}
	}

	.green {
		background-color: #56B7AD;
	}

	.zhi-wrp {
		.demo-warter {
			border-radius: 8px;
			margin: 5px;
			background-color: #ffffff;
			padding: 8px;
			position: relative;
		}

		.demo-img-wrap {
			position: relative;

			.status {
				display: inline-block;
				position: absolute;
				top: 0;
				left: 0;
				height: 30rpx;
				width: 80rpx;
				z-index: 99;
			}

			.play {
				width: 72rpx;
				height: 72rpx;
				position: absolute;
				z-index: 99;
				top: 50%;
				left: 50%;
				/*偏移*/
				transform: translateY(50%);
				transform: translateX(-50%);
				z-index: 99;

			}
		}

		.demo-image {
			width: 100%;
			border-radius: 4px;
			z-index: 2;
		}

		.zhi-title {
			font-size: 30rpx;
			margin-top: 5px;
			color: $font-color-dark;
			overflow: hidden;
			display: -webkit-box; //将元素设为盒子伸缩模型显示
			-webkit-box-orient: vertical; //伸缩方向设为垂直方向
			-webkit-line-clamp: 2; //超出3行隐藏，并显示省略号
		}

		.author {
			display: flex;
			width: 100%;
			justify-content: space-between;
			font-size: 22rpx;
			color: $u-tips-color;
			margin-top: 5px;

			.ren {
				margin-right: 10rpx;
				vertical-align: middle;
			}

			.right {
				white-space: nowrap;
				text-overflow: hidden;
				flex: 1;
				text-align: right;
			}

		}
	}
</style>
