<template>
	<view>
		<u-navbar :is-back="false" title="专家说" :border-bottom="false"></u-navbar>
		<view class="search-wrap">
			<view class="right" @click="goSearch">
				<u-icon name="search" color="#676767" size="26"></u-icon><text class="place">寻找你关心的话题</text>
			</view>
		</view>
		<u-tabs :list="tabList" active-color="#EF9F9F" :is-scroll="false" :current="current" @change="tabChange"></u-tabs>
		<view class="reco-wrp" v-if="current===0">
			<view class="sec-one">
				<!-- 电视直播 -->
				<view class="r-item tv" v-if="television.title">
					<u-image class="icon-left" src="/static/img/naozhong.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
					<view class="top">
						<text class="time">{{television.starttime|time}}</text>
						<view class="status">
							<u-image class="icon" v-if="television.type!=='yu'" src="/static/img/boico.png" mode="aspectFit" width="30"
							 height="30" :lazy-load="true" :borderRadius="20"></u-image>
							<u-image class="icon" v-else src="/static/img/shu.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
							{{television.label}}
						</view>
					</view>
					<view class="content">
						<view class="img-wrp">
							<u-image class="icon" :src="apiUrl+television.thumb" :borderRadius="20" mode="aspectFill" width="200" height="250"
							 :lazy-load="true"></u-image>

						</view>
						<view class="right">
							<view class="title">

								{{television.title}}

							</view>
							<view class="info">
								<view class="author">
									<u-image class="icon" src="/static/img/yin.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
									《优妈育儿堂》
								</view>
								<view class="hua">
									#{{television.tname}}
								</view>
							</view>
							<view class="status-wrp">
								<view class="left">
									<u-image class="icon" :src="television.label |stateIcon" width="80" height="40" :lazy-load="true"></u-image>
									<view class="text">
										{{television.pv}}
									</view>
									<view class="text" v-if="television.subscribestatus===0">
										{{television.subscribe}}
									</view>
								</view>
								<view class="right">
									<view class="btn green">
										{{television.subscribestatus===0? '预约提醒': '已预约'}}
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<!-- 专家说 -->
				<view class="r-item zhuan" v-if="expertssaid.title">
					<u-image class="icon-left" src="/static/img/naozhong.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
					<view class="top">
						<text class="time">{{expertssaid.starttime|time}}</text>
						<view class="status">
							<u-image class="icon" v-if="expertssaid.type!=='yu'" src="/static/img/boico.png" mode="aspectFit" width="30"
							 height="30" :lazy-load="true"></u-image>
							<u-image class="icon" v-else src="/static/img/shu.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
							{{expertssaid.label}}
						</view>
					</view>
					<view class="content">
						<view class="img-wrp">
							<u-image class="icon" :src="apiUrl+expertssaid.thumb" mode="aspectFill" width="200" height="250" :lazy-load="true"></u-image>

						</view>
						<view class="right">
							<view class="title">

								{{expertssaid.title}}

							</view>
							<view class="info">
								<view class="author">
									<u-image class="icon" src="/static/img/geren.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
									{{expertssaid.dname}}
								</view>
								<view class="hua">
									#{{expertssaid.tname}}
								</view>
							</view>
							<view class="status-wrp">
								<view class="left">
									<u-image class="icon" v-if="expertssaid.type!=='yu'" src="/static/img/zhiboz.png" width="80" height="40"
									 :lazy-load="true"></u-image>

									<u-image class="icon" v-else :src="expertssaid.label |stateIcon" width="80" height="40" :lazy-load="true"></u-image>
									<view class="text">
										{{expertssaid.pv}}
									</view>
									<view class="text" v-if="expertssaid.subscribestatus===0">
										{{expertssaid.subscribe}}
									</view>
								</view>
								<view class="right">
									<u-image class="icon" mode="aspectFit" :src="expertssaid.label |stateIcon" width="196" height="54" :lazy-load="true"></u-image>

								</view>
							</view>
						</view>
					</view>
				</view>
			</view>

		</view>

		<view class="zhi-wrp" v-if="current===1">
			<u-swiper :list="tvcontentlist" top synopsis @listClick="goTvDetail" effect3d-previous-margin=180 :effect3d="true"></u-swiper>
			<!-- {{flowList}} -->
			<u-waterfall v-model="flowList" ref="uWaterfall">
				<template v-slot:left="{ leftList }">
					<view class="demo-warter" v-for="(item, index) in leftList" :key="index">
						<!-- 警告：微信小程序不支持嵌入lazyload组件，请自行如下使用image标签 -->
						<!-- #ifndef MP-WEIXIN -->
						<u-lazy-load threshold="-450" border-radius="10" :image="item.image" :index="index"></u-lazy-load>
						<!-- #endif -->
						<!-- #ifdef MP-WEIXIN -->
						<view class="demo-img-wrap">
							<image class="state" v-if="item.label" :src="item.label |stateIcon" mode="aspectFit" height="38"></image>
							<image class="play" src="/static/img/video_play2.png" mode="aspectFit"></image>

							<image class="demo-image" :src="item.image" mode="widthFix"></image>
						</view>
						<!-- #endif -->
						<view class="zhi-title">{{ item.title }}</view>
						<view class="author">
							<view class="left">
								<!-- <u-icon name="account-fill"></u-icon>{{ item.dname }} -->
							</view>
							<view class="right" @click="goHuaDetail(item.tid)">
								# {{item.tname}}
							</view>
						</view>
					</view>
				</template>
				<template v-slot:right="{ rightList }">

					<view class="demo-warter" v-for="(item, index) in rightList" :key="index">

						<view class="demo-img-wrap">
							<u-image class="state" v-if="item.label" :src="item.label |stateIcon" mode="aspectFit" height="38"></u-image>
							<u-image class="play" src="/static/img/video_play2.png" width="72" mode="aspectFit" height="72"></u-image>
							<image class="demo-image" :src="item.image" mode="widthFix"></image>
						</view>
						<view class="zhi-title">{{ item.title }}</view>

						<view class="author">
							<view class="left">
								<u-icon name="account-fill"></u-icon>{{ item.dname }}
							</view>
							<view class="right" @click="goHuaDetail(item.tid)">
								# {{item.tname}}
							</view>
						</view>
					</view>
				</template>
			</u-waterfall>
		
		</view>
		<view class="sec-two" v-if="current!==1">
			<u-image class="title" v-if="current==0" src="/static/img/z-title.png" height="88" width="750"></u-image>
			<view class="content-wrp">
				<block v-for="item in expertssaidList" :key="item.id">
					<talkItem :item="item"></talkItem>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import moment from '@/common/moment';
	import talkItem from '../../components/talk-item/talk-item.vue'
	export default {
		components: {
			talkItem
		},
		data() {
			return {
				current: 0,
				apiUrl: this.$apiUrl,
				// 类型 ：text：文章 video：视频 live：直播流 audio：音频
				type: '',
				flowList: [],
				audioList: [{}],
				list: [],
				hotList: [],
				tvcontentlist: [],
				tabList: [{
						name: '热门推荐'
					}, {
						name: '直播视频'
					}, {
						name: '音频资料'
					},
					{
						name: '图文咨询'
					}
				],
				page: 1,
				pageSize: 10,
				television: {},
				expertssaid: {},
				expertssaidList: [],
				flowList: [],
				list: [{
						price: 35,
						title: '北国风光，千里冰封，万里雪飘',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic.sc.chinaz.com/Files/pic/pic9/202002/zzpic23327_s.jpg',
					},
					{
						price: 75,
						title: '望长城内外，惟余莽莽',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic.sc.chinaz.com/Files/pic/pic9/202002/zzpic23325_s.jpg',
					},
					{
						price: 385,
						title: '大河上下，顿失滔滔',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic2.sc.chinaz.com/Files/pic/pic9/202002/hpic2119_s.jpg',
					},
					{
						price: 784,
						title: '欲与天公试比高',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic2.sc.chinaz.com/Files/pic/pic9/202002/zzpic23369_s.jpg',
					},
					{
						price: 7891,
						title: '须晴日，看红装素裹，分外妖娆',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic2.sc.chinaz.com/Files/pic/pic9/202002/hpic2130_s.jpg',
					},
					{
						price: 2341,
						shop: '李白杜甫白居易旗舰店',
						title: '江山如此多娇，引无数英雄竞折腰',
						image: 'http://pic1.sc.chinaz.com/Files/pic/pic9/202002/zzpic23346_s.jpg',
					},
					{
						price: 661,
						shop: '李白杜甫白居易旗舰店',
						title: '惜秦皇汉武，略输文采',
						image: 'http://pic1.sc.chinaz.com/Files/pic/pic9/202002/zzpic23344_s.jpg',
					},
					{
						price: 1654,
						title: '唐宗宋祖，稍逊风骚',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic1.sc.chinaz.com/Files/pic/pic9/202002/zzpic23343_s.jpg',
					},
					{
						price: 1678,
						title: '一代天骄，成吉思汗',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic1.sc.chinaz.com/Files/pic/pic9/202002/zzpic23343_s.jpg',
					},
					{
						price: 924,
						title: '只识弯弓射大雕',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic1.sc.chinaz.com/Files/pic/pic9/202002/zzpic23343_s.jpg',
					},
					{
						price: 8243,
						title: '俱往矣，数风流人物，还看今朝',
						shop: '李白杜甫白居易旗舰店',
						image: 'http://pic1.sc.chinaz.com/Files/pic/pic9/202002/zzpic23343_s.jpg',
					},
				]
			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			},
			stateIcon(label) {
				switch (label) {
					case "直播中":
						return "/static/img/zzbz.png"
					case "未开始":
						return "/static/img/yyz.png"
					case "回放":
						return "/static/img/zhf.png"
					default:
						return "/static/img/ljgk.png"
				}
			}
		},
		onLoad() {
			// this.getExpertssaidList()
			// uni.startPullDownRefresh()
			// this.getTvcontentlist()
			// this.getHotExpertssaidList()
			this.tabChange(this.current)

		},
		onPullDownRefresh() {
			console.log('refresh');
			this.page = 1
			this.getExpertssaidList()
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getExpertssaidList()
					this.status = 'loading';
				}
			}, 2000)
		},
		methods: {
			addRandomData() {
				for (let i = 0; i < 10; i++) {
					let index = this.$u.random(0, this.list.length - 1);
					// 先转成字符串再转成对象，避免数组对象引用导致数据混乱
					let item = JSON.parse(JSON.stringify(this.list[index]))
					item.id = this.$u.guid();
					this.flowList.push(item);
				}
			},
			// 精选
			async getHotExpertssaidList() {
				let params = {
					uid: uni.getStorageSync('uid'),

				}
				let res = await this.$u.api.getContentlist(params);
				this.television = res.data.television
				this.expertssaid = res.data.expertssaid
			},
			async getExpertssaidList() {
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					hot: this.current === 0 ? 1 : 0,
					type: this.type,
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getExpertssaidList(params);
				uni.stopPullDownRefresh();
				let list = res.data.map(item => {
					item.img = this.apiUrl + item.thumb
					return item
				})
				this.expertssaidList = this.page === 1 ? list : this.expertssaidList.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				}
				// this.flowList = this.expertssaidList

				console.log(this.expertssaidList)
			},
			goHuaDetail(id) {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + id
				})
			},
			goContentDetail(val) {
				console.log(val)
				if (val.type === 'audio') {
					uni.navigateTo({
						url: '../audioDetail/audioDetail?cid=' + val.id
					})
				} else if (val.type === 'live') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + val.id
					})
				} else if (val.type === 'text') {
					uni.navigateTo({
						url: '../articleDetail/articleDetail?cid=' + val.id
					})
				} else if (val.type === 'video') {
					uni.navigateTo({
						url: '../articleDetail/articleDetail?cid=' + val.id
					})
				}
			},

			async getTvcontentlist() {
				let params = {
					famous: 1
				}
				let res = await this.$u.api.getTvcontentlist(params);
				this.tvcontentlist = res.data.map(item => {
					item.image = this.$apiUrl + item.thumb
					return item
				})
			},
			goTvDetail(val) {
				uni.navigateTo({
					url: '/pages/momDetail/momDetail?cid=' + this.tvcontentlist[val].id
				})
			},
			goSearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			tabChange(val) {
				this.current = val
				if (val === 0) {
					this.getHotExpertssaidList()
				} else if (val === 1) {
					this.type = 'live'
					this.addRandomData()
					this.getTvcontentlist()
				} else if (val === 2) {
					this.type = 'audio'
				} else {
					this.type = 'text'
				}
				this.getExpertssaidList()

			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #FFFFFF;
	}

	.search-wrap {
		background-color: #FFFFFF;
		display: flex;
		padding: 10rpx $spacing-lg;
		line-height: 61rpx;
		color: $font-color-base;
		font-size: 24rpx;

		.right {
			background-color: $uni-bg-color-grey;
			flex: 1;
			border-radius: 32rpx;
			padding: 0 $spacing-lg;

			icon {
				margin-right: 20rpx;
			}

			.place {
				margin-left: 20rpx;
			}
		}
	}

	.reco-wrp {
		margin-top: 20rpx;
		background-color: #FFFFFF;

		.sec-one {
			padding: 0 $spacing-lg;
			border-bottom: 20rpx solid $page-color-base;

			.r-item {
				position: relative;
				padding-left: 40rpx;
				padding-bottom: 20rpx;

				&::before {
					content: '';
					width: 1rpx;
					height: 100%;
					position: absolute;
					top: 10rpx;
					left: 14rpx;
					background-color: $page-color-base;

				}

				.icon-left {
					position: absolute;
					top: 6rpx;
					left: 0;
					background-color: #FFFFFF;
				}

				.top {
					display: flex;
					align-items: center;
					margin-bottom: 20rpx;

					.time {
						color: $font-color-light;
						margin-right: 30rpx;
					}

					.status {
						color: $font-color-base;
						display: flex;

						.icon {
							margin-right: 20rpx;
						}
					}
				}

				.content {
					display: flex;

					.right {
						margin-left: 20rpx;
						flex: 1;

						.title {
							font-size: 28rpx;
							color: $font-color-base;
							min-height: 60rpx;
							margin-bottom: 20rpx;
							overflow: hidden;
							display: -webkit-box; //将元素设为盒子伸缩模型显示
							-webkit-box-orient: vertical; //伸缩方向设为垂直方向
							-webkit-line-clamp: 2; //超出3行隐藏，并显示省略号
						}

						.info {
							display: flex;
							justify-content: space-between;
							align-items: center;
							color: $font-color-light;
							font-size: 24rpx;

							.author {
								display: flex;
								font-size: 24rpx;
							}

							.hua {
								background: $page-color-base;
								padding: 6rpx 20rpx;
								border-radius: 30rpx;
							}
						}

						.status-wrp {
							display: flex;
							justify-content: space-between;
							align-items: center;
							margin-top: 30rpx;

							.left {
								display: flex;
								flex: 1;
								height: 40rpx;
								color: #fff;
								vertical-align: top;
								align-items: top;

								.text {
									background-color: #a8a8a8;
									height: 40rpx;
									line-height: 40rpx;
									font-size: 20rpx;
									padding: 0 16rpx;
								}


							}

							.right {
								.btn {
									// margin-right: 20rpx;s
									width: 160rpx;
									text-align: center;
									color: #FFFFFF;
									border-radius: 40rpx;
									line-height: 54rpx;
									font-size: 30rpx;

								}

							}
						}
					}
				}
			}

		}

		.sec-two {}
	}

	.green {
		background-color: #56B7AD;
	}

	.zhi-wrp {
		.demo-warter {
			border-radius: 8px;
			margin: 5px;
			background-color: #ffffff;
			padding: 8px;
			position: relative;
		}

		.demo-img-wrap {
			position: relative;

			.status {
				display: inline-block;
				position: absolute;
				top: 0;
				left: 0;
			}

			.play {
				width: 72rpx;
				height: 72rpx;
				position: absolute;
				top: 50%;
				left: 50%;
				/*偏移*/
				transform: translateY(50%);
				transform: translateX(-50%);
				z-index: 99;

			}
		}

		.demo-image {
			width: 100%;
			border-radius: 4px;
		}

		.zhi-title {
			font-size: 30rpx;
			margin-top: 5px;
			color: $font-color-dark;
			overflow: hidden;
			display: -webkit-box; //将元素设为盒子伸缩模型显示
			-webkit-box-orient: vertical; //伸缩方向设为垂直方向
			-webkit-line-clamp: 2; //超出3行隐藏，并显示省略号
		}

		.author {
			display: flex;
			width: 100%;
			justify-content: space-between;
			font-size: 22rpx;
			color: $u-tips-color;
			margin-top: 5px;

			.right {
				white-space: nowrap;
				text-overflow: hidden;
				flex: 1;
				text-align: right;
			}

		}
	}
</style>
