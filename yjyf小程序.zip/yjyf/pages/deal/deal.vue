<template>
	<view>
		<view class="cnt">
			<view class="stu1">
				<view style="width: 300rpx;">
					<image class="lf" src="../../static/img/chuzhong2.png" mode="aspectFit"></image>
					<view style="margin:10rpx 0;">
						<text>某某学生甲</text>
					</view>
					<view class="tm">
						<text>11:30</text>
						<text style="margin-left: 10rpx;">32人浏览</text>
					</view>
				</view>
				<view class="dz">
					<image class="img" src="../../static/img/zan1.png"></image>
					<text>187</text>
				</view>
			</view>
			<view class="dis">
				<text>现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>

				<view class="sj">

				</view>
				<view class="bg">
					<text> 崔冰卷回复:现在上大学应该学什么专业，毕业后能很快的找到稳定的工作？专科的大学有必要上吗？</text>
				</view>
			</view>
		</view>
		<view style="width: 100%;height: 17rpx;background-color: #F4F4F4;margin-top: 30rpx;">

		</view>
		<view class="disscuss">
			<image src="../../static/img/news.png" mode="aspectFill"></image>
			<text style="margin-left: 20rpx;">全部评论</text>
		</view>
		<view class="stu1" style="margin-top: 20rpx;">
			<view style="width: 300rpx;">
				<image class="lf" src="../../static/img/chuzhong2.png" mode="aspectFit"></image>
				<view style="margin:10rpx 0;">
					<text>某某学生乙</text>
				</view>
				<view class="tm">
					<text>6天前</text>
				
				</view>
			</view>
			<view class="dz">
				<image class="img" src="../../static/img/zan.png"></image>
				<!-- <text>187</text> -->
			</view>
		</view>
		<inputReplay ref="replay" :isVisible="isVisible" @close="close" @addcomment="addcomment"></inputReplay>
	</view>
</template>

<script>
	import inputReplay from "../../components/input-replay/input-replay.vue"
	export default {
		components: {

			inputReplay
		},
		props: {
			item: Object,
			cango: {
				type: Boolean,
				default: true
			},

		},
		data() {
			return {
				apiUrl: this.$apiUrl,
				current: {},
				isVisible: false,
				info: uni.getStorageInfoSync('info')


			};
		},
		watch: {
			item(nVal, oVal) {
				//IOS聚焦问题
				let that = this;
				setTimeout(() => {
					that.current = nVal;
				}, 100)
				// this.$emit("update:isVisible", true);
			},
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('YYYY-MM-DD HH:mm');
			}
		},

		methods: {
			goPostDetail() {
				console.log(this.$route)
				if (!this.cango) return
				uni.navigateTo({
					url: '/pages/postDetail/postDetail?id=' + this.item.id
				})
			},
			preview() {
				// 预览图片
				uni.previewImage({
					urls: this.item.photos.map(item => {
						return this.$apiUrl + item
					}),
					longPressActions: {
						itemList: ['发送给朋友', '保存图片', '收藏'],
						success: function(data) {
							console.log('选中了第' + (data.tapIndex + 1) + '个按钮,第' + (data.index + 1) + '张图片');
						},
						fail: function(err) {
							console.log(err.errMsg);
						}
					}
				});
			},
			remarkAction() {
				this.$refs.replay.inputValue = ''
				this.isVisible = true
			},
			goHuaDetail() {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + this.item.tags
				})
			},
			async addcomment(val) {
				if (!val) {
					uni.showToast({
						title: '请输入评论内容'
					})
				}
				let params = {
					topic_id: this.item.id,
					user_id: uni.getStorageSync('uid'),
					comment: val,
					comment_type: 0
				}
				let res = await this.$u.api.addTopicComment(params);

				uni.showToast({
					title: res.msg,
					icon: 'none'
				})
				this.isVisible = false
				this.$emit('update', val)
			},
			share() {
				// 该对象已集成到this.$u中，内部属性如下
				this.$u.mpShare = {
					title: '', // 默认为小程序名称，可自定义
					path: '/pages/postDetail/postDetail?id=' + this.current.id, // 默认为当前页面路径，一般无需修改，QQ小程序不支持
					// 分享图标，路径可以是本地文件路径、代码包文件路径或者网络图片路径。
					// 支持PNG及JPG，默认为当前页面的截图
					imageUrl: ''
				}
			},
			close() {
				this.isVisible = false
			},
			async zanClick(item) {
				let params = {
					topic_id: item.id,
					user_id: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.topicZan(params);
				uni.showToast({
					title: res.msg,
					icon: 'none'
				})
				this.$emit('update')
			}
		}
	}
</script>

<style>
	.cnt {
		margin-top: 20rpx;
		width: 95%;
	}

	.cnt .stu1 {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.stu1 {
		width: 95%;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	

	.stu1 view .lf {
		width: 100rpx;
		height: 100rpx;
		float: left;
	}

	.stu1 .tm text {
		font-size: 22rpx;
		color: #D4D4D4;
	}

	.stu1 .dz .img {
		width: 40rpx;
		height: 40rpx;
		vertical-align: bottom;

	}

	.cnt .dz {
		color: #60B9E7;
	}

	.cnt .dz .img {
		width: 40rpx;
		height: 40rpx;
		vertical-align: bottom;
	}

	.cnt .dis {
		margin-left: 100rpx;
	}

	
	
	.cnt .dis .bg {
		width: 100%;
		height: 120rpx;
		font-size: 25rpx;
		padding: 20rpx;
		background-color: #F4F4F4;
		color: #919191;
	}

	.disscuss {
		width: 100%;
		height: 80rpx;
		line-height: 80rpx;
		border-bottom: 1rpx solid #F1F1F1;
		padding-left: 20rpx;
	}

	.disscuss image {
		width: 40rpx;
		height: 40rpx;
		vertical-align: middle;

	}

	.cnt .dz {
		color: #60B9E7;
	}

	.cnt .dz .img {
		width: 40rpx;
		height: 40rpx;
		vertical-align: bottom;
	}

	.cnt .dis {
		margin-left: 100rpx;
	}
</style>
