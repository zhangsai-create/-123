<template>
	<view>
		<view class="head" style="display: flex; justify-content: center; align-items: center;">
			<view style="background-color: #F3ADAE; height: 5rpx; width: 50rpx;"></view>
			<view style="margin: 0 10rpx; font-size: 28rpx; color:#F3ADAE;">热门评论</view>
			<view style="background-color: #F3ADAE; height: 5rpx; width: 50rpx;"></view>
		</view>

		<view class="item">
			<u-image width="68rpx" height="68rpx" shape="circle"></u-image>
			<view class="item-mid">
				<view class="item-mid-title">夜里的猫</view>
				<view>07-06 16:55:31</view>
				<view>这娃求生欲很强啊**</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss">
	.item {

		padding: 0 22rpx;
		display: flex;

		.item-mid {
			margin-left: 22rpx;
			flex: 1;
		}

		.item-mid-title {
			color: #575757;
			font-size: 28rpx;
		}

		&:nth-of-type(2) {
			color: #808080;
		}

	}
</style>
