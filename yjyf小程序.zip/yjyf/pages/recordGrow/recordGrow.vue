<template>
	<view class="p-wrp">
		<u-input v-model="content" class="text bg" :type="type" :border="border" :height="height" placeholder="说点什么吧"
		 :auto-height="autoHeight" />
		<view class="up">
			<u-upload ref="uUpload" uploadText="图片" type="image" @upSuccessVideo="upSuccessVideo" @on-success="upSuccess"
			 @on-remove="onRmove" :action="action" :auto-upload="true"></u-upload>
		</view>

		<view class="btn-wrp">
			<view class="c-btn" @click="recordAdd">
				保存
			</view>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value: '',
				type: 'textarea',
				border: true,
				action: this.$askUrl + '/common/upload',
				height: 200,
				autoHeight: true,
				selectHuaShow: false,
				actionStyle: {
					width: '120rpx',
					background: '#11B5FF',
					padding: '10rpx 30rpx',
					color: '#fff',
					borderRadius: '40rpx'
				},
				photo: [],
				content: '',
				videoUrl: ''
			};
		},
		methods: {
			async recordAdd() {
				console.log(this.photo, !this.content)
				if (this.photo.length === 0 && !this.content && !this.videoUrl) {
					uni.showToast({
						title: "请填写内容",
						icon: 'none'
					})
					return
				}
				let params = {
					user_id: uni.getStorageSync('uid'),
					photo: JSON.stringify(this.photo),
					content: this.content,
					video: this.videoUrl
				}
				let res = await this.$u.api.setRecord(params);
				if (res.code == 200) {
					this.$refs.uToast.show({
						title: res.msg,
						type: 'warning',
						back: true
					})

				}
			},
			onRmove(index) {
				this.photo.splice(index, 1)
			},
			upSuccessVideo(url) {
				console.log(url)
				this.videoUrl = url
			},
			upSuccess(data, index, lists) {
				console.log(data, index, lists)
				this.photo = lists.map(item => {
					console.log(item.response)
					return item.response
				})
			}
		}
	}
</script>

<style lang="scss">
	page {}

	.p-wrp {
		padding: 0 $spacing-base;
	}

	.bg {
		background-color: #fff;
		border: none;
	}

	.up {
		margin: 30rpx 0;
	}

	.btn-wrp {
		text-align: center;

		.c-btn {
			display: inline-block;
			background-color: $base-color;
			padding: 16rpx 30rpx;
			color: #FFFFFF;
			width: 160rpx;
			text-align: center;
			border-radius: 40rpx;
		}
	}
</style>
