<template>
	<view>
		<!-- <u-popup v-model="showLogin" mode="center" borderRadius="30">
			<chooseStatus></chooseStatus>
		</u-popup> -->
		<u-navbar :is-back="false" title="养教有方" :border-bottom="false"></u-navbar>
		<view class="search-wrap">
			<view class="left">
				<u-dropdown active-color="#11B5FF" height="70rpx">
					<u-dropdown-item @change="statusChange" v-model="currentStatus" :title="currentStatusText" :options="StatusList"></u-dropdown-item>
				</u-dropdown>
				<!-- <text>宝宝</text> -->
				<!-- <u-icon name="arrow-down" color="#676767" size="26"></u-icon> -->
			</view>
			<view class="right" @click="goSearch">
				<u-icon name="search" color="#676767" size="26"></u-icon><text class="place">搜索</text>
			</view>
		</view>
		<view>
			<u-tabs :list="tabList" active-color="#11B5FF" :is-scroll="true" :current="currentNum" @change="tabChange"></u-tabs>
			<view class="view_bottom"></view>
			<view>
				<block v-for="item in contentDatalist" :key="item.id">
					<talkItem :item="item"></talkItem>
				</block>
			</view>
		</view>
		
		<!-- 广告区域 -->
		<!-- <view class="sec-two">
			<u-swiper :list="bannerList" height="196" :borderRadius="20"></u-swiper>
		</view> -->
		<!-- 话题区域 -->
		<!-- <view class="sec-three">
			<view class="tab-wrp">
				<view class="tab-item" :class="{'active':huaActive===0}" @click="huaTabChange(0)">
					<u-image src="/static/img/tab1.png" class="img" width="60" height="60" :lazy-load="true"></u-image>
					妈妈
				</view>
				<view class="tab-item" :class="{'active':huaActive===1}" @click="huaTabChange(1)">
					<u-image src="/static/img/tab2.png" class="img" width="60" height="60" :lazy-load="true"></u-image>
					宝宝
				</view>
			</view>
			<view class="con-wrp">
				<scroll-view class="scroll-view_H" scroll-x="true" @scroll="scroll" scroll-left="120">
					<view class="h-item" v-for="item in categoryList" :key="item.id" @click="goCategory(item)">
						<view class="img-wrp">
							<u-image class="img" :src="apiUrl+item.image" width="60" height="60" :lazy-load="true"></u-image>
						</view>
						<view class="text">
							{{item.name}}
						</view>
					</view>
				</scroll-view>
			</view>
		</view> -->
		<view class="sec-doc">
			<view class="sec-title">
				<view class="label">
					解惑答疑
				</view>
				<view class="more" @click="goAskDoctor()">
					更多 <u-icon class="icon" name="arrow-right" size="26"></u-icon>

				</view>
			</view>
			<view class="lei-wrp">
				<scroll-view class="scroll-view_H" scroll-x="true" @scroll="scroll" scroll-left="120">
					<view class="lei-item" v-for="item in departmentlist" :key="item.id" @click="goDeptDoctor(item)">
						{{item.name}}
					</view>
				</scroll-view>
			</view>
			<!-- 专家 -->
			<view class="doc-wrp">
				<view class="d-item" v-for="item in doctorList" :key="item.id" @click="goDoctorDetail(item.id)">
					<view class="img-wrp">
						<u-image class="img" :src="apiUrl+item.thumb" shape="circle" width="110" height="110" mode="aspectFill"
						 :lazy-load="true"></u-image>
					</view>
					<view class="text">
						<text class="name">{{item.name}}</text><text class="post">{{item.dname}}</text>
					</view>
					<view class="hos">
						{{item.hname}}
					</view>
				</view>


			</view>
		</view>
		<view class="sec-hua">
			<view class="sec-title">
				<view class="label">
					推荐话题
				</view>
			</view>
			<view class="hua-wrp">
				<view class="h-item" v-for="item in recommendList" :key="item.id" @click="goHuaDetail(item.id)">
					<view class="title">
						{{item.name}}
					</view>
					<view class="next-title">
						<view class="text">
							{{item.synopsis}}
						</view>
						<u-image class="img" :src="apiUrl+item.thumb" width="48" height="48" :lazy-load="true"></u-image>
					</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import moment from '@/common/moment';
	import talkItem from '../../components/talk-item/talk-item.vue'
	import items from "../../components/index-item/index-item.vue";
	export default {
		components: {items,talkItem},
		data() {
			return {
				type: 'create',
				editInfo: {},
				currentStatus: 1,
				birthDateShow: false,
				showChildren: false,
				showYuMod: false,
				recordList: [{}, {}],
				yuDateShow: false,
				showLogin: true,
				currentStatusText: '小学',
				userInfo: {
					name: '',
					birthDate: null,
					sexName: ''
				},
				sexShow: false,
				sexList: [{
					text: '男',
					fontSize: 28
				}, {
					text: '女',
					fontSize: 28
				}],
				currentNum:0,
				tabList: [
					{id:0,name:'推荐'}
				],
				chooseStatus: '',
				// 怀孕状态 0 :备孕 1：怀孕 2：宝宝
				StatusList: [{
						label: '小学',
						value: 1,
					},
					{
						label: '初中',
						value: 2,
					},
					{
						label: '高中',
						value: 3,
					}
				],
				apiUrl: this.$apiUrl,
				yuDate: null,
				params: {
					year: true,
					month: true,
					day: true,
					hour: false,
					minute: false,
					second: false,
					timestamp: true
				},
				huaActive: 0,
				old: {
					scrollTop: 0
				},
				doctorList: [],
				departmentlist: [],
				hotList: [],
				bannerList: [],
				categoryList: [],
				userInfo: {},
				childInfo: '',
				recommendList: [],
				code: '',
				columnData:{},
				contentDatalist:[],
				columnid:'',
				statuss:''
			}
		},
		watch: {
			currentStatus(val, oVal) {
				//IOS聚焦问题
				let that = this;
				if (val === '0') {
					this.currentStatusText = '小学'
				} else if (val === '1') {
					this.currentStatusText = '初中'
				} else if (val === '2') {
					this.currentStatusText = '高中'
				}
			},
		},

		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('YYYY年MM月DD日');
			},
			age(val) {
				console.log('当前日期:' + moment().format("YYYY-MM-DD")) //当前日期:2019-01-30
				let age = moment().diff(moment(birthday), 'years')
				console.log('周岁年龄:' + age) //周岁年龄:25
			}
		},
		onShow() {
			const that = this
			// console.log(parseInt(uni.getStorageInfoSync('uid')),456)
			if (!parseInt(uni.getStorageSync('uid')) > 0 ) {
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						that.getuserstatus(loginRes.code)
					}
				});
			} else {
				this.getUserRecord()
			}

		},
		onLoad() {
			const that = this
			uni.stopPullDownRefresh();
			this.getBannerList()
			this.getdoctorlist()
			this.getdepartmentlist()
			this.getRecommendList()
			this.getCategoryList()
			this.getcolumn()
			this.getStatuss()
			// this.getcontentData()
		},
		onPullDownRefresh() {
			const that = this
			if (!parseInt(uni.getStorageSync('uid')) > 0) {
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						console.log(loginRes);
						that.getuserstatus(loginRes.code)
					}
				});
			} else {
				this.getUserRecord()
			}
			console.log('refresh');
			this.getBannerList()
			this.getdoctorlist()
			this.getdepartmentlist()
			this.getRecommendList()
			this.getCategoryList()
			uni.stopPullDownRefresh();
		},
		methods: {
			async getuserstatus(code) {
				const that = this
				let params = {
					code: code
				}
				let res = await that.$u.api.getuserstatus(params);
				if (res.code !== 200) return
				uni.setStorageSync('uid', res.data.user_id)
				// this.getUser()
			},
			//获取状态
			async getStatuss(){
				let params = {
					user_id: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getStatuss(params);
				console.log(res,'状态')
				this.statuss=  res.data.status
				if (res.code !== 200 && res.code !== 1) return
			},
			//获取资讯栏目
			async getcolumn() {
				let params = {}
				let res = await this.$u.api.getcolumn(params);
				console.log(res,'获取资讯栏目')
				// this.tabList.push = res.data
				this.tabList.push.apply(this.tabList,res.data)
				this.columnid = this.tabList[0].id
				this.getcontentData(this.columnid)
				// console.log(this.tabList)
			},
			//获取资讯列表
			async getcontentData(id) {
				console.log(id)
				let hotId
				if(id==0){
					hotId = 1
				}else{
					hotId = 0
				}
				let params = {
					uid:uni.getStorageSync('uid'),
					mold:this.currentStatus,
					columnid:id,
					hot:hotId
				}
				let res = await this.$u.api.getcontentData(params);
				let list = res.data.map(item => {
					item.img = this.apiUrl + item.thumb
					return item
				})
				console.log(res,'获取资讯列表')
				this.contentDatalist = list
			},
			tabChange(val){  
				console.log(val)
				let ids 
				for(let i=0;i<this.tabList.length;i++){
					if(val == i)
					ids= this.tabList[i].id
				}
				this.contentDatalist = []
				this.getcontentData(ids)
				this.currentNum = val
				}, 
			async getuserstatus(code) {
				const that = this
				let params = { 
					code: code
				}
				let res = await that.$u.api.getuserstatus(params);
				if (res.code !== 200) return
				uni.setStorageSync('uid', res.data.user_id)
				// uni.setStorageSync('uid', '1')
				this.getUser()
			},
			async getUser(status) {
				let params = {
					user_id: uni.getStorageSync('uid'),
					pregnancy_status: status | null
				}
				let res = await this.$u.api.getUser(params);
				this.getUserRecord()
				this.userInfo = res.data
				this.currentStatus = res.data.pregnancy_status
				console.log('当前日期:' + moment(parseInt(res.data.birth_time) * 1000).format("YYYY-MM-DD"), moment(parseInt(res.data.child_age) *
					1000).format(
					"YYYY-MM-DD")) //当前日期:2019-01-30
				this.userInfo.yuDate = moment(parseInt(res.data.birth_time) * 1000).format("YYYY年MM月DD日")
				this.userInfo.child_age_info = moment(parseInt(res.data.child_age) * 1000).format("YYYY年MM月DD日")

				let momths = moment().diff(moment(parseInt(res.data.child_age) * 1000), 'months')
				console.log('周岁年龄:' + parseInt(momths / 12), momths % 12) //周岁年龄:25
				this.childInfo = parseInt(momths / 12) > 0 ? parseInt(momths / 12) + '岁  ' + momths % 12 + '个月  ' + momths % 12 %
					30 + '  天' : "",
					this.type = 'create'
				if (status === '1' && !res.data.birth_time) {
					this.showYuMod = true
				} else if (status === '2' && !res.data.child_age) {
					this.showChildren = true
				}

			},

			goDeptDoctor(item) {
				uni.navigateTo({
					url: "/pages/doctorList/doctorList?type=dept&&name=" + item.name + "&&deptId=" + item.id
				})
			},

			async getCategoryList() {
				let params = {
					is_mama: this.huaActive,
					num: 10
				}
				let res = await this.$u.api.getCategoryList(params);
				this.categoryList = res.data
			},
			async getBannerList() {
				let res = await this.$u.api.getBannerList({});
				console.log(res)
				this.bannerList = res.data.map(item => {
					item.image = this.$apiUrl + item.img
					return item
				})
			},
			async getRecommendList() {
				let params = {
					num: 6,
					place: 1
				}
				let res = await this.$u.api.getRecommendList(params);
				this.recommendList = res.data
				console.log(res,'话题')
			},
			// async getHotList() {
			// 	let params = {
			// 		num: 12
			// 	}
			// 	let res = await this.$u.api.getHotList(params);
			// 	this.hotList = res.data
			// },
			async getdoctorlist() {
				let params = {
					status: 1
				}
				let res = await this.$u.api.getdoctorlist(params);
				console.log(res,'专家6个')
				this.doctorList = res.data
			},
			goCategory(item) {
				uni.navigateTo({
					url: '/pages/categoryList/categoryList?name=' + item.name + '&id=' + item.id + '&ismum=' + this.huaActive
				})
			},
			async getdepartmentlist() {
				let params = {
					type: 1
				}
				let res = await this.$u.api.getdepartmentlist(params);
				this.departmentlist = res.data
			},
			sexClick(index) {
				this.editInfo.child_sex = this.sexList[index].text
			},
			async getUserRecord() {
				let params = {
					user_id: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.getIndexRecord(params);

				this.recordList = res.data.length > 0 ? res.data : [{}, {}]
			},
			goSearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			goHospitalDetail() {
				uni.navigateTo({
					url: "../hospitalDetail/hospitalDetail"
				})
			},
			goRecordGrow() {
				uni.navigateTo({
					url: "/pages/recordGrow/recordGrow"
				})
			},
			goAskDoctor() {
				uni.navigateTo({
					url: '/pages/askDoctor/askDoctor'
				})
			},
			goDoctorDetail(id) {
				uni.navigateTo({
					url: '/pages/doctorDetail/doctorDetail?did=' + id
				})
			},
			goHuaDetail(id) {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + id
				})
			},
			scroll(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			changeYuDate(e) {
				console.log(e)
				this.editInfo.birth_time = e.timestamp
				this.editInfo.yuDate = e.year + "-" + e.month + "-" + e.day
			},
			changeBirthDate(e) {
				console.log(e)
				this.editInfo.child_age = e.timestamp
				this.editInfo.child_age_info = e.year + "-" + e.month + "-" + e.day
			},
			async goChildrenSatus() {
				if (!this.editInfo.child_name) {
					uni.showToast({
						title: "请输入宝宝昵称",
						icon: 'none'
					})
					return
				}
				if (!this.editInfo.child_age) {
					uni.showToast({
						title: "请选择出生日期",
						icon: 'none'
					})
					return
				}
				if (!this.editInfo.child_sex) {
					uni.showToast({
						title: "请选择性别",
						icon: 'none'
					})
					return
				}
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: '2',
					child_name: this.editInfo.child_name,
					child_age: this.editInfo.child_age,
					child_sex: this.editInfo.child_sex

				}
				let res = {}
				if (this.type === 'create') {
					res = await this.$u.api.addUserStatus(params);
				} else {
					res = await this.$u.api.updateUserStatus(params);
				}
				if (res.code !== 200 && res.code !== 1) return
				this.showChildren = false
				this.getUser('2')
			},
			//进入预产状态
			async goYuSatus() {
				if (!this.editInfo.yuDate) {
					uni.showToast({
						title: "请选择预产期",
						icon: 'none'
					})
					return
				}
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: '1',
					birth_time: this.editInfo.birth_time
				}
				let res = {}
				if (this.type === 'create') {
					res = await this.$u.api.addUserStatus(params);

				} else {
					res = await this.$u.api.updateUserStatus(params);

				}
				if (res.code !== 200 && res.code !== 1) return
				this.showYuMod = false
				this.getUser('1')

			},
			editBao() {
				this.showChildren = true
				this.type = 'edit'
				this.editInfo = this.userInfo
			},
			editYu() {
				this.showYuMod = true
				this.type = 'edit'
				this.editInfo = this.userInfo
			},
			async statusChange(val) {
				console.log(val)
				if (val.value === 1) {
					this.currentStatusText = '小学'
				} else if (val.value === 2) {
					this.currentStatusText = '初中'
				} else if (val.value === 3) {
					this.currentStatusText = '高中'
				}
				this.chooseStatus = val.value
				this.currentStatus = val.value
				this.setStatuss(val.value)
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: val.value,
					// child_age: this.child_time,
					// child_name: this.child_name,
					// child_sex: this.sex
				}
				let res = await this.$u.api.updateUserStatus(params);
				console.log(res,'保存状态')
				// if (val.value == 0) {
				// 	this.getUser('-1')
				// } else {
				// 	this.getUser(val.value)

				// }


			},
			async setStatuss(val){
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: val
				}
				let res = await this.$u.api.addUserStatus(params);
				console.log(res)
				if (res.code !== 200 && res.code !== 1) return
			},
			huaTabChange(val) {
				this.huaActive = val
				this.getCategoryList()
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #FFFFFF;
	}

	.mo-warp {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 100%;

		.content {
			width: 80%;
			min-height: 260rpx;
			background-color: #FFFFFF;
			border-radius: 30rpx;
			padding: 20rpx 30rpx;
			color: #474747;
			font-size: 24rpx;

			.btn-wrp {
				font-size: 24rpx;
				text-align: center;
				margin-top: 70rpx;

				.btn {
					display: inline-block;
					width: 250rpx;
					font-size: 26rpx;
					background-color: $base-color;
					color: #FFFFFF;
					line-height: 80rpx;
					border-radius: 40rpx;
				}
			}

			.label {
				line-height: 80rpx;

			}

			.tip {
				color: #a7a7a7;
				line-height: 40rpx;
				margin-bottom: 20rpx;

			}

			.input-wrp {
				// width: 60%;
				height: 70rpx;
				border: 1rpx solid #a9a9a9;
				padding: 0 30rpx;
				font-size: 28rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-radius: 6rpx;

				.input-text {
					font-size: 28rpx;
					flex: 1;
				}
			}
		}

	}


	.view_bottom{
		width: 100%;
		border-bottom:1px solid #D3D3D3;
		margin-top: -6rpx;
	}
	.search-wrap {
		background-color: #FFFFFF;
		display: flex;
		padding: 0 $spacing-lg;
		line-height: 70rpx;
		color: $font-color-base;
		font-size: 24rpx;

		.left {
			background-color: $uni-bg-color-grey;
			margin-right: 30rpx;
			min-width: 150rpx;
			text-align: center;
			border-radius: 50rpx;
			padding-right: 0 20rpx;


		}

		.right {
			background-color: $uni-bg-color-grey;
			flex: 1;
			border-radius: 32rpx;
			padding: 0 $spacing-lg;

			icon {
				margin-right: 20rpx;
			}

			.place {
				margin-left: 20rpx;
			}
		}
	}

	.sec-one {
		position: relative;
		background-color: #FFFFFF;
		min-height: 200rpx;
		background-color: $page-color-base;
		margin: $spacing-lg;
		border-radius: 20rpx;
		margin-top: 100rpx;
		padding: $spacing-base;
		color: $font-color-base;

		.avatar {
			position: absolute;
			top: -65rpx;
			left: 20rpx;
		}

		.top {
			display: flex;
			min-height: 70rpx;
			justify-content: space-between;

			.left {
				padding-top: 60rpx;
				min-height: 65rpx;

				.name {
					margin-right: 20rpx;
				}

				.brith {
					font-size: 22rpx;
					margin-top: 20rpx;

					.icon {
						margin-left: 20rpx;
					}

				}
			}

			.right {
				display: flex;
				font-size: 20rpx;
				justify-content: center;

				.r-item {
					min-width: 90rpx;
					text-align: center;
					color: $base-color;
					margin: 0 8rpx;

					image {
						display: inline-block;

					}
				}
			}
		}

		.hua {
			font-size: 26rpx;
			margin-top: 10rpx;
		}
	}


	.scroll-view_H {
		width: 100%;
		white-space: nowrap;
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
	}

	.pic-wrp {
		padding: 20rpx 0;



		.pic-item {
			display: inline-block;
			margin-right: 20rpx;

		}

		.action {
			display: inline-block;
			background-color: $base-color;
			color: #FFFFFF;
			width: 98rpx;
			vertical-align: top;
			height: 160rpx;
			border-radius: 20rpx;
			text-align: center;
			font-size: 22rpx;

			.icon {
				margin: 20rpx 0;
			}
		}
	}

	.sec-two {
		margin: $spacing-lg;
	}

	.sec-three {
		margin: $spacing-lg;

		.tab-wrp {
			display: flex;
			align-items: flex-end;

			.tab-item {
				flex: 1;
				text-align: center;
				vertical-align: bottom;
				background-color: #d6f1ec;
				height: 78rpx;
				line-height: 78rpx;
				border-radius: 20rpx 20rpx 0 0;

				.img {
					display: inline-block;
					vertical-align: middle;
					margin-right: 30rpx;
				}
			}

			.active {
				background-color: #f8d7e8;
				height: 90rpx;
				line-height: 90rpx;
			}
		}

		.con-wrp {
			border-bottom: 20rpx solid $page-color-base;
			min-height: 170rpx;

			.scroll-view_H {
				width: 100%;
				white-space: nowrap;
				display: flex;
				flex-wrap: nowrap;
				align-items: center;
			}

			.h-item {
				width: 160rpx;
				display: inline-block;
				text-align: center;
				padding: 20rpx 10rpx;
				font-size: 24rpx;
				color: $font-color-base;

				.img-wrp {
					height: 80rpx;
					line-height: 80rpx;
					text-align: center;

					.img {
						display: inline-block;
					}
				}
			}
		}
	}

	.sec-title {
		display: flex;
		justify-content: space-between;
		height: 80rpx;
		line-height: 80rpx;
		font-size: 28rpx;

		.more {
			color: $font-color-light;

			.icon {
				margin-left: 10rpx;
			}
		}
	}

	.sec-doc {
		padding: 0 $spacing-base;
		border-bottom: 20rpx solid $page-color-base;

		.lei-wrp {
			.lei-item {
				display: inline-block;
				min-width: 90rpx;
				background-color: $page-color-base;
				border-radius: 20rpx;
				margin-right: 28rpx;
				line-height: 40rpx;
				height: 40rpx;
				font-size: 24rpx;
				color: #8e8e8e;
				padding: 0 20rpx;
			}
		}

		.doc-wrp {
			display: flex;
			flex-wrap: wrap;
			padding-bottom: 20rpx;
			align-items: center;

			.d-item {
				display: inline-block;
				width: 33%;
				text-align: center;
				margin-top: 20rpx;
				font-size: 28rpx;

				.img-wrp {
					display: flex;
					align-items: center;
					justify-content: center;
					margin: 0 auto;
				}

				.text {
					color: $font-color-base;

					.name {
						margin-right: 10rpx;
					}
				}

				.hos {
					font-size: 20rpx;
					color: $font-color-light;
				}
			}
		}

	}

	.sec-hua {
		padding: 0 $spacing-base;
		border-bottom: 20rpx solid $page-color-base;

		.hua-wrp {
			display: flex;
			flex-wrap: wrap;

			.h-item {
				display: flex;
				align-items: center;
				display: inline-block;
				width: 31%;
				padding-left: 20rpx;
				margin-top: 20rpx;
				background-color: #FDF3F8;
				border-radius: 10rpx;
				position: relative;
				padding-top: 10rpx;
				padding-bottom: 10rpx;
				margin-bottom: 20rpx;
				margin-right: 20rpx;

				&:nth-of-type(2) {
					background-color: #F7FFFC;
				}

				&:nth-of-type(5) {
					background-color: #F7FFFC;
				}

				&:nth-of-type(6) {
					margin-right: 0;
					background-color: #F8FAFF;
				}

				&:nth-of-type(3) {
					margin-right: 0;
					background-color: #F8FAFF;
				}

				.title {
					font-size: 30rpx;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}

				.next-title {
					font-size: 20rpx;
					color: $font-color-light;
					height: 50rpx;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					display: flex;
					align-items: center;
					justify-content: space-between;
				}



			}
		}
	}
</style>
