<template>
	<view>
		<view class="status-wrp">
			<view class="s-item" @click="activeStatus=1" :class="{'active':activeStatus===1}">
				<view class="img-wrp">
					<u-image class="img" v-if="activeStatus!==1" src="/static/img/xiaoxue1.png" :fade="false" width="166" height="166"
					 shape="circle"></u-image>
					<u-image class="img" v-if="activeStatus===1" src="/static/img/xiaoxue2.png" :fade="false" width="180" height="180"
					 shape="circle"></u-image>
				</view>
				<view class="text">
					小学
				</view>
				<u-image v-if="activeStatus===1" class="active" src="/static/img/xia.png" width="24" height="24"></u-image>
			</view>
			<view class="s-item" @click="activeStatus=2" :class="{'active':activeStatus===2}">
				<view class="img-wrp">
					<u-image class="img" v-if="activeStatus!==2" src="/static/img/chuzhong1.png" :fade="false" width="166" height="166"
					 shape="circle"></u-image>
					<u-image class="img" v-if="activeStatus===2" src="/static/img/chuzhong2.png" :fade="false" width="180" height="180"
					 shape="circle"></u-image>
				</view>

				<view class="text">
					初中
				</view>
				<u-image v-if="activeStatus===2" class="active" src="/static/img/xia.png" width="24" height="24"></u-image>
			</view>
			<view class="s-item" @click="activeStatus=3" :class="{'active':activeStatus===3}">
				<view class="img-wrp">
					<u-image class="img" v-if="activeStatus!==3" src="/static/img/gaozhong1.png" :fade="false" width="166" height="166"
					 shape="circle"></u-image>
					<u-image class="img" v-if="activeStatus===3" src="/static/img/gaozhong2.png" :fade="false" width="180" height="180"
					 shape="circle"></u-image>
				</view>

				<view class="text">
					高中
				</view>
				<u-image v-if="activeStatus===3" class="active" src="/static/img/xia.png" width="24" height="24"></u-image>
			</view>
		</view>

		<!-- <view class="sec-1" v-if="activeStatus==2">
			<view class="item">
				<view class="label">
					请输入预产期
				</view>
				<view class="tip">
					请输入产检时专家告知的预产期
				</view>
				<view class="input-wrp" @click="yuDteShow=true">
					<text v-if="!yuDate">请选择日期</text>
					<view v-else>
						{{yuDate}}
					</view>
					<u-icon name="calendar" size="30rpx"></u-icon>
				</view>
			</view>

			<u-picker mode="time" v-model="yuDteShow" confirm-color="#11B5FF" @confirm="changeYuDate" :params="params"></u-picker>

		</view>
		<view class="sec-1" v-if="activeStatus==3">
			<view class="item">
				<view class="label">
					宝宝昵称
				</view>
				<view class="input-wrp">
					<input v-model="child_name" auto-focus type="text" placeholder="请输入" />
					<u-icon name="calendar" size="30rpx"></u-icon>
				</view>
			</view>
			<view class="item">
				<view class="label">
					宝宝生日
				</view>
				<view class="input-wrp" @click="BirthDateShow = true">
					<text v-if="!child_age">请选择出生日期</text>
					<view v-else>
						{{child_age}}
					</view>
					<u-icon name="calendar" size="30rpx"></u-icon>
				</view>
				<u-picker mode="time" v-model="BirthDateShow" confirm-color="#11B5FF" @confirm="changeBirthDate" :params="params"></u-picker>


			</view>
			<view class="item">
				<view class="label">
					宝宝性别
				</view>
				<view class="input-wrp" @click="sexShow = true">
					<text v-if="!sex">请选择性别</text>
					<view v-else>
						{{sex}}
					</view>
					<u-icon name="calendar" size="30rpx"></u-icon>
				</view>
			</view>
			<u-action-sheet :list="sexList" v-model="sexShow" @click="sexClick" :cancel-btn="true"></u-action-sheet>
		</view> -->
		<view class="btn-wrp">
			<button open-type="getUserInfo" class="btn" @getuserinfo="saveInfo" withCredentials>
				保存
			</button>

		</view>
		<view class="tip-wrp">
			<text class="tips" @click="goIndex">先逛逛</text>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				activeStatus: 1,
				BirthDateShow: false,

				sexShow: false,
				sexList: [{
					text: '男',
					fontSize: 28
				}, {
					text: '女',
					fontSize: 28
				}],
				yuDteShow: false,
				code: '',
				params: {
					year: true,
					month: true,
					day: true,
					hour: false,
					minute: false,
					second: false,
					timestamp: true
				},
				yuDate: '',
				birth_time: '',
				child_age: '',
				child_time: '',
				child_name: '',
				sex: ''
			}
		},
		watch: {

			activeStatus(nVal, oVal) {
				//IOS聚焦问题
				let that = this;
				setTimeout(() => {
					that.yuDate = ''
					that.birth_time = ''
					that.child_age = ''
					that.child_time = ''
					that.child_name = ''
					that.sex = ''
				}, 100)
			},
		},
		onShow() {
			this.getCode()
		},
		methods: {
			getCode() {
				const that = this
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						console.log(loginRes);
						that.code = loginRes.code
					}
				});
			},
			async getUserByCode(val) {
				let result = null
								if (!uni.getStorageSync('uid')) {
									if (!val.target.iv) return
									let params = {
										code: this.code,
										iv: val.target.iv,
										encryptedData: val.target.encryptedData
									}
									result = await this.$u.api.getUserByCode(params);
									console.log(result)
									uni.setStorageSync('uid', result.data.id)
								} else {
									let params = {
										code: this.code
									}
									result = await this.$u.api.getuserstatus(params);
									uni.setStorageSync('uid', result.data.user_id)
								}
								if (this.activeStatus === 1) {
									let params = {
										user_id: uni.getStorageSync('uid'),
										status: 1
									}
									let res = await this.$u.api.addUserStatus(params);
									if (res.code !== 200 && res.code !== 1) return
									uni.switchTab({
										url: '/pages/index/index'
									})
								} else
								if (this.activeStatus === 2) {
									this.goYuStatus()
								} else if (this.activeStatus === 3) {
									this.goBaoStatus()
								}

			},
			goIndex() {
				uni.switchTab({
					url: '/pages/index/index'
				})
			},
			async saveInfo(val) {
				// console.log(val, this.activeStatus)
				// let params = {
				// 	code: this.code,
				// 	iv: val.target.iv,
				// 	encryptedData: val.target.encryptedData
				// }
				// let result = await this.$u.api.getUserByCode(params);
				// console.log(result.data.id)
				// 	let datas = {
				// 		user_id: result.data.id,
				// 		status: 1
				// 	}
				// let res = await this.$u.api.addUserStatus(datas);
				// uni.setStorageSync('uid', result.data.id)
				// uni.switchTab({
				// 	url: '/pages/index/index'
				// })
				uni.setStorageSync('info', val.target.userInfo)
				this.getUserByCode(val)
			},
			sexClick(index) {
				this.sex = this.sexList[index].text
			},
			async goYuStatus() {
				// if (!this.yuDate) {
				// 	uni.showToast({
				// 		title: '请选择预产期',
				// 		icon: 'none'
				// 	})
				// 	return
				// }
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: 2,
					// birth_time: this.birth_time
				}
				let res = await this.$u.api.addUserStatus(params);
				if (res.code !== 200 && res.code !== 1) return

				uni.switchTab({
					url: '/pages/index/index'
				})

			},
			async goBaoStatus() {
				// if (!this.child_name) {
				// 	uni.showToast({
				// 		title: '请输入宝宝昵称',
				// 		icon: 'none'
				// 	})
				// 	return
				// }
				// if (!this.child_time) {
				// 	uni.showToast({
				// 		title: '请选择出生日期',
				// 		icon: 'none'
				// 	})
				// 	return
				// }
				// if (!this.sex) {
				// 	uni.showToast({
				// 		title: '请选择性别',
				// 		icon: 'none'
				// 	})
				// 	return
				// }
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: 3,
					// child_age: this.child_time,
					// child_name: this.child_name,
					// child_sex: this.sex
				}
				let res = await this.$u.api.addUserStatus(params);
				if (res.code !== 200 && res.code !== 1) return

				uni.switchTab({
					url: '/pages/index/index'
				})

			},
			changeYuDate(e) {
				console.log(e)
				this.yuDate = e.year + "-" + e.month + "-" + e.day
				this.birth_time = e.timestamp
			},
			changeBirthDate(e) {
				this.child_age = e.year + "-" + e.month + "-" + e.day
				this.child_time = e.timestamp
			}
		}
	}
</script>

<style lang="scss">
	.tip-wrp {
		text-align: center;
		margin-top: 40rpx;
	}

	.tips {
		color: #a7a7a7;
		line-height: 40rpx;
		margin: 20rpx 0;
		text-decoration: underline;
	}

	.status-wrp {
		border-bottom: 20rpx solid $page-color-base;
		display: flex;

		.img-wrp {
			height: 200rpx;
		}

		.s-item {
			margin-top: 20rpx;
			flex: 1;
			text-align: center;
			font-size: 24rpx;
			padding-bottom: 20rpx;
			color: #a9a9a9;

			.text {
				margin: 20rpx 0;
			}

			.img {
				display: inline-block;
				margin: 30rpx auto;
			}

			.active {
				display: inline-block;
				margin: 20rpx auto;
			}
		}

		.active {
			color: #272727;
		}
	}

	.sec-1 {
		padding: 20rpx 30rpx;
		color: #474747;
		font-size: 24rpx;

		.label {
			line-height: 80rpx;

		}

		.tip {
			color: #a7a7a7;
			line-height: 40rpx;
			margin-bottom: 20rpx;

		}

		.input-wrp {
			width: 60%;
			border: 1rpx solid #a9a9a9;
			line-height: 60rpx;
			padding: 0 30rpx;
			display: flex;
			font-size: 28rpx;
			justify-content: space-between;
			border-radius: 6rpx;

			input {
				font-size: 28rpx;
				line-height: 60rpx;
				height: 60rpx;
			}

			.btn {
				font-size: 28rpx;
			}
		}
	}

	.btn-wrp {
		font-size: 24rpx;
		text-align: center;
		margin-top: 70rpx;

		.btn {
			display: inline-block;
			width: 250rpx;
			font-size: 30rpx;
			background-color: $base-color;
			color: #FFFFFF;
			line-height: 80rpx;
			border-radius: 40rpx;
		}
	}
</style>
