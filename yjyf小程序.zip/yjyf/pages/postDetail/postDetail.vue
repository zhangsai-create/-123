<template>
	<view>
		<view class="sec-two">
			<mumSayItem :cango="false" @update="getTopicDetail()" :item="dataDetail"></mumSayItem>
		</view>
	</view>
</template>

<script>
	import mumSayItem from "../../components/mum-say-item/mum-say-item.vue";
	
	export default {
		data() {
			return {
				dataDetail: {},
				id: ''
			};
		},
		onLoad(val) {
			this.id = val.id||22
			this.getTopicDetail()
		},
		components:{
			mumSayItem
		},
		methods:{
			
			async getTopicDetail() {
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					id: this.id
				}
				let res = await this.$u.api.getTopicDetail(params);
				this.dataDetail = res.data
				this.dataDetail.photos = typeof this.dataDetail.photos === 'string' ? this.dataDetail.photos.split(',') : this.dataDetail.photos
				
			},
			
		}
	}
</script>

<style lang="scss">
	.sec-two {
		padding: 0 $spacing-lg 20rpx;
	}

</style>
