<template>
	<view class="content">
		<view class="content_view">
			<u-image src="/static/img/login_top.png" width="251" height="265"   shape="circle" class="images" :lazy-load="true"></u-image>
			<!-- <u-image src="/static/img/login_btn1.png" width="300" height="45"  ></u-image>
			<u-image src="/static/img/login_btn2.png" width="300" height="45"  ></u-image> -->
		</view>
		<view class="image_box">
			<!-- <u-image src="/static/img/login_btn2.png" width="622" height="96" class="imgs1" @click="go"></u-image> -->
			<navigator target="miniProgram" open-type="navigate" app-id="wx348e78dd7d1eb16c" path="/pages/index/index" extra-data="" version="release" class="go_btn1">学&nbsp前&nbsp版</navigator>
		</view>
		<view class="image_box">
			<!-- <u-image src="/static/img/login_btn1.png" width="622" height="96" class="imgs1" @click="goIndex"></u-image> -->
			<navigator url="../index/index" open-type="switchTab" class="go_btn2">中&nbsp小&nbsp学&nbsp&nbsp版</navigator>
		</view>
		<view class="image_buttom">
			<u-image src="/static/img/login_bottom.png" width="750" height="512" class="img_bottom"></u-image>
			<text class="bottom_text">养教有方,提升家长素养,助力儿童全面发展</text>
		</view>
	</view>
</template>
<script>
	export default {
		methods: {
			goIndex() {
				console.log(1)
				uni.navigateTo({
					url: '../index/index'
				})
			}
		}
	}
</script>

<style lang="scss">
	.content{
		.content_view{
			display: flex;  
			justify-content: center;
			.images{
				margin-top: 100rpx;
			}
		}
		.image_box{
			display: flex;
			justify-content: center;
			// .imgs1{
			// 	margin-top: 50rpx;
			// }
			.go_btn1{
				width: 622rpx;
				height: 96rpx;
				line-height: 96rpx;
				text-align: center;
				background: linear-gradient(90deg, #F79798, #F3A7A9);
				border-radius: 45rpx;
				color: #FFFFFF;
				font-size: 42rpx;
				margin-top: 50rpx;
			}
			.go_btn2{
				width: 622rpx;
				height: 96rpx;
				line-height: 96rpx;
				text-align: center;
				background: linear-gradient(90deg, #187FFF, #13B3FF);
				border-radius: 45rpx;
				color: #FFFFFF;
				font-size: 42rpx;
				margin-top: 40rpx;
			}
		}
		.image_buttom{
			// height: 100%;
			width: 100%;
			height: 520rpx;
			// background: url('../../static/img/login_bottom.png');
			display: flex;
			justify-content: center;
			position: fixed;
			bottom: 0;
			.bottom_text{
				color: #989697;
				font-size: 28rpx;
				position: absolute;
				bottom: 30rpx;
			}
		}
	}
</style>
