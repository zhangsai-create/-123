<template>
	<view class="content-wrp">
		<u-navbar :is-back="true" backIconColor="#fff" isFixed :title="tabTitle" titleColor="#fff" :background="background"
		 :border-bottom="false"></u-navbar>
		<view class="info">
			<u-image :src="apiUrl+infoData.thumb" class="avatar" width='125' height='125' shape="circle" :lazy-load="true"></u-image>
			<view class="mid">
				<view class="name"> {{infoData.name}} </view>
				<view class="m-title"> {{infoData.dname}} {{infoData.position}} </view>
				<view class="m-title"> {{infoData.hname}} </view>
			</view>
			<view class="follw-btn" @click="followdocter">{{infoData.followstatus===0? '关注': '不再关注'}}</view>
		</view>
		<u-tabs :list="tabList" active-color="#11B5FF" :is-scroll="false" :current="current" @change="tabChange"></u-tabs>
		<view class="basic-info" v-show="current==0">
			<view class="title">专家擅长</view>
			<view class="content">{{infoData.expert}}</view>
			<view class="title">专家简介</view>
			<view class="content">{{infoData.synopsis}}
			</view>
			<view class="title">单位信息</view>
			<view class="hos-inf0" @click="goHouseDetail">

				<view class="right">
					<view class="hos">
						<view class="hos-name">
							<u-image class="icon" src="/static/img/yiyuan.png" width="30" height="30" size="36"></u-image>
							{{infoData.hname}}
						</view>
						<u-icon name="arrow-right" color="#9A9A9A" size="24"></u-icon>
					</view>

				</view>
				<view class="label">
					<view class="l-item" v-for="(item,index) in infoData.labels" :key="index">{{item}}</view>
				</view>
			</view>


			<!-- <view class="contact">
				<u-icon name="/static/img/dianhua.png" size="36"></u-icon>
				<view class="c-mobile-title">联系电话</view>
				 <view class="c-mobile">{{infoData.phone}}</view> -->
				<!-- <u-icon name="arrow-right" color="#9A9A9A" size="24"></u-icon> -->
			<!-- </view> -->
		</view>
		<view class="say-wrp" v-show="current==1">
			<empty v-if="expertssaidList.length===0" info="没有发布哦~"></empty>


			<block v-for="item in expertssaidList" :key="item.id">
				<talkItem :item="item"></talkItem>
			</block>
		</view>
		<view class="jj" v-show="current==2">
		   <jj></jj>
		  </view>
		<!-- <view class="questions-btn" @click="makeCall"><text>向{{tabTitle}}提问</text></view> -->
	</view>
</template>

<script>
	import talkItem from '../../components/talk-item/talk-item.vue'
	import empty from "../../components/rf-empty/index.vue";
		import jj from "../../components/list/list.vue";

	export default {
		components: {
			talkItem,
			empty,
			jj
		},
		data() {
			return {
				apiUrl: this.$apiUrl,
				tabTitle: "",
				expertssaidList: [],
				background: {
					'background-image': 'linear-gradient(90deg, #187FFF, #13B3FF)'
				},
				tabList: [{
					name: '基本信息'
				}, {
					name: '专家说'
				},{
					name:'咨询'
				}],
				current: 0,
				doctorId: null,
				infoData: {
					"id": 4,
					"name": "",
					"hid": "",
					"did": "",
					"thumb": "",
					"position": "",
					"expert": "",
					"synopsis": "",
					"phone": "",
					"famous": 0,
					"volunteer": 0,
					"follow": 0,
					"city": "",
					"status": 0,
					"dname": "",
					"hname": "",
					"followstatus": 0,
					"labels": [],
				},
				page: 1,
				pageSize: 10
			};
		},
		onLoad(val) {
			uni.startPullDownRefresh()
			this.doctorId = val.did || 1
			this.getdoctorDetail()
			this.getExpertssaidList()

		},
		methods: {
			async getdoctorDetail() {
				let params = {
					did: this.doctorId,
					uid: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getdoctorDetail(params);
				this.infoData = res.data
				this.tabTitle = this.infoData.name
			},
			async getExpertssaidList() {
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					did: this.doctorId,
					mold:1,
					page: this.page,
					pageSize: this.pageSize
				}
				let res = await this.$u.api.getExpertssaidList(params);
				console.log(res,'专家说列表')
				uni.stopPullDownRefresh()
				this.expertssaidList = res.data
			},

			goHouseDetail() {
				uni.navigateTo({
					url: '/pages/hospitalDetail/hospitalDetail?hid=' + this.infoData.hid
				})
			},
			async followdocter() {
				let params = {
					did: this.doctorId,
					uid: uni.getStorageSync('uid'),
					type: this.infoData.followstatus === 0 ? '1' : '2'
				}
				let res = await this.$u.api.followdocter(params);
				if (res.code !== 200 && res.code !== 1) return
				this.getdoctorDetail()
			},

			tabChange(val) {
				this.current = val
			},
			makeCall() {
				if (this.infoData.phone) {
					uni.makePhoneCall({
						phoneNumber: this.infoData.phone //仅为示例
					});
				} else {
					uni.showToast({
						title: "暂无法咨询",
						icon: 'none'
					})
				}

			}
		}
	}
</script>

<style lang="scss">
	.content-wrp {
		padding-bottom: 100rpx;
	}

	.say-wrp {}

	.info {
		background: linear-gradient(90deg,  #187FFF, #13B3FF);
		display: flex;
		color: #FFFFFF;
		// align-items: center;
		padding: 46rpx 30rpx;

		.mid {
			flex-grow: 5;
			margin-left: 17rpx;

			.name {
				font-size: 27rpx;
				font-weight: 400;
			}

			.m-title {
				margin-top: 18rpx;
				font-size: 23rpx;
			}
		}

		.follw-btn {
			font-size: 23rpx;
			border: #fff solid 2rpx;
			border-radius: 100rpx;
			height: 53rpx;
			line-height: 53rpx;
			padding: 0rpx 23rpx;
		}
	}

	.basic-info {
		padding-left: 32rpx;
		padding-right: 32rpx;

		.title {
			margin-top: 36rpx;
		}

		.content {
			margin-top: 30rpx;
			font-size: 27rpx;
			color: #7C7C7C;
		}

		.hos-inf0 {
			margin-top: 50rpx;

			.right {
				.hos {
					display: flex;
					justify-content: space-between;
				}
			}

			.hos-name {
				display: flex;
				color: #5A5A5A;
				font-size: 27rpx;

				.icon {
					margin-right: 20rpx;
				}
			}
		}

		.label {
			display: flex;
			margin-top: 30rpx;
			margin-left: 50rpx;

			.l-item {
				border-radius: 50rpx;
				border: #13B3FF solid 1rpx;
				padding: 5rpx 10rpx;
				margin-right: 10rpx;
				font-size: 27rpx;
				color: #13B3FF;
			}
		}

		.contact {
			padding-top: 30rpx;
			padding-bottom: 30rpx;
			border-bottom: #E9E9E9 solid 1rpx;
			border-top: #E9E9E9 solid 1rpx;
			display: flex;
			justify-content: center;
			margin-top: 35rpx;

			.c-mobile-title {
				margin-left: 24rpx;
				flex-grow: 10;
			}

			.c-mobile {
				margin-right: 66rpx;
			}
		}
	}

	.expert-list {
		padding: 0 36rpx;

		.list-item {
			border-bottom: #E9E9E9 solid 1rpx;
			padding: 27rpx 0;
		}

		.subject {
			color: #494949;
			font-size: 27rpx;
		}

		.item-foot {
			display: flex;
			margin-top: 22rpx;
			align-items: center;

			.author {
				color: #5A5A5A;
				font-size: 23rpx;
			}

			.label {
				flex-grow: 10;
				margin-left: 10rpx;
			}

			.label-item {
				background-color: #F0F0F0;
				border-radius: 100rpx;
				padding: 8rpx 20rpx;
				color: #8F8F8F;
			}

			.date {
				font-size: 20rpx;
				color: #494949;
			}
		}

		.list-item-one {
			.item-content {
				background-color: #F0F0F0;
				border-radius: 10rpx;
				margin-top: 19rpx;
				display: flex;
				align-items: center;

				.left {
					height: 211rpx;
					width: 211rpx;

					.play {
						position: relative;
						left: 130rpx;
						bottom: 85rpx;
					}
				}

				.con-right {
					margin-left: 32rpx;
				}

				.con-listener {
					font-size: 23rpx;
					margin-top: 22rpx;
				}
			}
		}

		.list-item-two {
			display: flex;
			padding-bottom: 30rpx;

			.left {
				height: 156rpx;
				width: 280rpx;

				.play {
					position: relative;
					top: -113rpx;
					left: 106rpx;
				}
			}

			.right {
				margin-left: 32rpx;
			}
		}

		.list-item-three {
			.mid {
				display: flex;
				justify-content: space-between;
				margin-top: 21rpx;

				.mid-pic {
					width: 100%;
					margin: 0 7rpx;
					border-radius: 10rpx;
				}
			}
		}

		.list-item-four {
			display: flex;

			.left {
				flex: 1;
			}

			.right {
				margin-left: 25rpx;
				background-color: #DCDFE6;
				border-radius: 10rpx;
			}
		}

	}

	.questions-btn {
		position: fixed;
		width: 100%;
		left: 0;
		bottom: 0;
		background-color: #13B3FF;
		color: #FFFFFF;
		line-height: 90rpx;
		justify-content: center;
		display: flex;
	}
</style>
