<template>
	<view>
		<empty v-if="list.length===0" info="暂时没有预约"></empty>
		<view v-for="(item,index) in list" :key="item.id">
			<talkItem v-if="item.attribute==='content'" :item="item"></talkItem>
			<view class="item" v-if="item.attribute==='television'">
				<view class="left">
					<u-image :src="$apiUrl+item.thumb" width="239" height="165" :borderRadius="10"></u-image>
					<u-image class="play" src="/static/img/live-play.png" width="63" height="63"></u-image>
				</view>
				<view class="right">
					<view class="title"> {{item.title}} </view>
					<view class="r-bottom">
						<text class="time">{{item.releasetime|time}}</text>
						<u-image class="status" v-if="item.label" :src="item.label |stateIcon" width="150" height="50"></u-image>
					</view>
				</view>
			</view>
		</view>
				<u-loadmore :status="status" v-if="list.length>pageSize" />
	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue"
	import moment from '@/common/moment';
	import talkItem from "../../components/talk-item/talk-item.vue"
	export default {
		components: {
			empty,
			talkItem
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日 HH:mm');
			},
			stateIcon(label) {
				switch (label) {
					case "直播中":
						return "/static/img/living.png"
					case "未开始":
						return "/static/img/live-soon.png"
					case "回放":
						return "/static/img/replay.png"
					default:
						return ''
				}
			}
		},
		data() {
			return {
				page: 1,
				list: [],
				pageSize: 10,
				status: '',
				nomore: false
			};
		},
		onLoad() {
			this.getsubscribelist()
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';
		
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getsubscribelist()
					this.status = 'loading';
				}
			}, 2000)
		},
		methods: {
			async getsubscribelist() {
				let params = {
					page: this.page,
					num: this.pageSize,
					uid: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.getsubscribelist(params)
				uni.stopPullDownRefresh()
				let list = res.data
				this.list = this.page === 1 ? list : this.list.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				}
			}
		}
	}
</script>

<style lang="scss">
	.item {
		display: flex;
		align-items: center;
		padding: 33rpx 25rpx 33rpx 38rpx;
		border-bottom: 1rpx solid #EEEEEE;

		.left {
			position: relative;
		}

		.play {
			position: absolute;
			top: 50%;
			left: 50%;
			margin-left: -32rpx;
			margin-top: -32rpx;
		}

		.right {
			margin-left: 25rpx;
			flex: 1;

			.title {
				color: #545454;
				font-size: 28rpx;
			}

			.r-bottom {
				display: flex;
				align-items: center;
				margin-top: 24rpx;

				.time {
					color: #A8A8A8;
					flex: 1;
					font-size: 21rpx;
				}

				.status {
					display: inline-block;
				}
			}


		}


	}
</style>
