<template>
	<view>
		<empty v-if="collectlist.length===0" :info="'空空如也~'"></empty>
		<view v-for="(item,index) in collectlist" :key="item.id">
			<parentingItem :item='item'></parentingItem>
		</view>
		<u-loadmore :status="status" v-if="collectlist.length>pageSize" />
	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue"
	import parentingItem from "../../components/parenting-item/parenting-item.vue"
	export default {
		components: {
			empty,
			parentingItem
		},
		data() {
			return {
				collectlist: [],
				page: 1,
				pageSize: 10,
				status: '',
				nomore: false
			}
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';
		
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getTvcontentlist()
					this.status = 'loading';
				}
			}, 2000)
		},
		onPullDownRefresh() {
			this.page = 1
			this.getTvcontentlist()
		},
		onLoad() {
			this.getTvcontentlist()
		},
		methods: {
			async getTvcontentlist() {
				let params = {
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getTvcontentlist(params);
				this.collectlist = res.data
				let list = res.data
				this.collectlist = this.page === 1 ? list : this.collectlist.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				}
				uni.stopPullDownRefresh()
			}
		}
	}
</script>

<style>

</style>
