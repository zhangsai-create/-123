<template>
	<view>
		<empty v-if="collectlist.length===0" info="您还没有收藏哦"></empty>
		<view v-for="(item,index) in collectlist" :key="item.id">
			<talkItem v-if="item.attribute==='content'" :item="item"></talkItem>
			<parentingItem v-if="item.attribute==='television'" :item="item"></parentingItem>

		</view>
		<u-loadmore :status="status" v-if="collectlist.length>pageSize" />

	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue";
	import parentingItem from "../../components/parenting-item/parenting-item.vue"
	import talkItem from "../../components/talk-item/talk-item.vue"
	export default {
		components: {
			empty,
			parentingItem, //优妈育儿
			talkItem, //专家说
		},
		data() {
			return {
				page: 0,
				collectlist: [],
				pageSize: 10,
				status: '',
				nomore: false
			};
		},
		onLoad() {
			this.getcollectlist()
		},
		methods: {
			async getcollectlist() {
				let params = {
					uid: uni.getStorageSync('uid'),
					page: this.page,
					num: this.pageSize,
				}
				let res = await this.$u.api.getCollectlist(params)
				this.page = res.count.page
				let list = res.data
				this.collectlist = this.page === 1 ? list : this.collectlist.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				} else {
					this.nomore = false
				}
				uni.stopPullDownRefresh()
			},
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';

			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getcollectlist()
					this.status = 'loading';
				}
			}, 2000)
		},
	}
</script>

<style lang="scss">
	.item {
		display: flex;
		padding: 28rpx 31rpx;
		border-bottom: 1rpx #EBEBEB solid;

		.left {
			flex: 1;
			margin: auto;

			.content {
				color: #525252;
				font-size: 28rpx;
				padding-bottom: 30rpx;
			}

			.name {
				color: #A6A6A6;
				margin-top: 32rpx;
				font-size: 24rpx;
			}

			.topic {
				padding-left: 20rpx;
			}
		}

		.right {
			width: 239rpx;
			height: 166rpx;
			border-radius: 10rpx;
			position: relative;

			.play {
				position: absolute;
				left: 50%;
				top: 50%;
				margin-left: -32rpx;
				margin-top: -32rpx;
			}

			.status {
				background-color: #999999;
				position: absolute;
				color: #FFFFFF;
				height: 36rpx;
				line-height: 36rpx;
				border-radius: 10rpx;
				padding: 0 10rpx;
				top: 10rpx;
				left: 10rpx;
			}
		}
	}
</style>
