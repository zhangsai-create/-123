<template>
	<view>
		<u-navbar :is-back="false" title="家长圈" :border-bottom="false"></u-navbar>

		<view class="search-wrap">
			<view class="right" @click="goSearch">
				<u-icon name="search" color="#676767" size="26"></u-icon><text class="place">寻找你关心的话题</text>
			</view>
		</view>
		<!-- <view class="tui-wrp">
			<view class="tui-item" v-for="(item,index) in recommendList" :key="item.id" v-if="index<2" @click="goHuaDetail(item.id)">
				<view class="left">
					<view class="title">
						<text>#</text><text v-text="item.name"></text>
					</view>
					<view class="desc">
						{{item.synopsis}}
					</view>
				</view>
				<view class="right">
					<u-image :src="apiUrl+item.thumb" width="80" height="80" :lazy-load="true"></u-image>
				</view>
			</view>
		</view> -->
		<view class="sec-one" v-if="hotList.length>=2">
			<view class="sec-title">
				<view class="label">
					<u-image class="img" src="/static/img/jing1.png" width="48" height="49" :lazy-load="true"></u-image>
					热门话题
				</view>
			</view>
			<view class="re-wrp">
				<view class="re-item" v-for="(item, $index) in hotList"  :key="item.id" @click="goHuaDetail(item.id)">
					<text>#</text>{{item.name}}
				</view>
			</view>
		</view>
		<view class="sec-two">
			<block v-for="item in topicList" :key="item.id">
				<mumSayItem @update="getTopicList()" :item="item"></mumSayItem>
			</block>
			<u-loadmore :status="status" v-if="topicList.length>pageSize" />

		</view>

		<dragball :x=windowWidth-100 :y=windowHeight-100 image="/static/img/fabu.png" @goWhere="goPublic"></dragball>

	</view>
</template>

<script>
	import dragball from "../../components/drag-ball/drag-ball.vue";
	import mumSayItem from "../../components/mum-say-item/mum-say-item.vue";

	export default {
		data() {
			return {
				page: 1,
				pageSize: 10,
				windowWidth: '',
				apiUrl: this.$apiUrl,
				windowHeight: '',
				topicList: [],
				hotList: [],
				status: '',
				nomore: false,
				recommendList: []
			}
		},
		components: {
			dragball,
			mumSayItem
		},
		onShow() {
			const {
				windowWidth,
				windowHeight
			} = uni.getSystemInfoSync();
			this.windowWidth = windowWidth
			this.windowHeight = windowHeight
			this.getTopicList()
		},
		onPullDownRefresh() {
			console.log('refresh');
			this.page = 1
			this.getHotList()
			this.getTopicList()
		},
		onLoad() {
			this.getHotList()
			this.getRecommendList()
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getTopicList()
					this.status = 'loading';
				}
			}, 2000)
		},
		onShareAppMessage(res) {
			console.log(res)
			if (res.from === 'button') { // 来自页面内分享按钮
				console.log(res.target)
				return {
					title: res.target.title,
					path: '/pages/postDetail/postDetail?id=' + res.target.id
				}
			}

		},
		methods: {
			async getRecommendList() {
				let params = {
					num: 2,
					place: 2
				}
				let res = await this.$u.api.getRecommendList(params);
				this.recommendList = res.data
			},
			async getHotList() {
				let params = {
					num: 6,
					page:1
				}
				let res = await this.$u.api.getHotList(params);
				this.hotList = res.data
			},
			goSearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			async getTopicList() {
				let params = {
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getTopicList(params);
					uni.stopPullDownRefresh();
				let list = res.data.map(item => {
					item.photos = typeof item.photos === 'string' ? item.photos.split(',') : item.photos
					return item
				})
				this.topicList = this.page === 1 ? list : this.topicList.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				}
				console.log(this.topicList)
			},
			goHuaDetail(id) {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + id
				})
			},
			goPublic() {
				uni.navigateTo({
					url: '/pages/publicTalk/publicTalk'
				})
			},

		}
	}
</script>

<style lang="scss">
	.search-wrap {
		display: flex;
		padding: 0 $spacing-lg;
		line-height: 61rpx;
		color: $font-color-base;
		font-size: 24rpx;

		.right {
			background-color: $uni-bg-color-grey;
			flex: 1;
			border-radius: 32rpx;
			padding: 0 $spacing-lg;

			icon {
				margin-right: 20rpx;
			}

			.place {
				margin-left: 20rpx;
			}
		}
	}

	.ball {
		width: 70upx;
		height: 70upx;
		background: linear-gradient(to bottom, #F8F8FF, #87CEFA);
		border-radius: 50%;
		box-shadow: 0 0 15upx #87CEFA;
		color: #fff;
		font-size: 30upx;
		display: flex;
		justify-content: center;
		align-items: center;
		position: fixed !important;
		z-index: 1000000;
	}

	.tui-wrp {
		padding: 0 $spacing-lg;
		display: flex;
		justify-content: space-between;
		margin: 27rpx 0;

		.tui-item {
			flex: 1;
			background-color: #ECF2FE;
			padding: 20rpx;
			display: flex;
			align-items: center;
			border-radius: 20rpx;

			.left {
				flex: 1;
			}

			&:first-of-type {
				margin-right: 20rpx;
				background-color: #FDF6EE;

			}

			.title {
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				color: $font-color-dark;
				margin-bottom: 6rpx;
			}

			.desc {
				width: 70%;
				font-size: 20rpx;
				color: $font-color-light;
			}
		}
	}

	.sec-title {
		height: 80rpx;
		padding: 0 $spacing-lg;
		display: flex;
		font-size: 29rpx;
		align-items: center;
		color: #4d4d4d;


		.label {


			.img {
				display: inline-block;
				margin-right: 16rpx;
				vertical-align: middle;

			}
		}
	}

	.sec-one {
		padding: 0 $spacing-lg;

		.re-wrp {
			display: flex;
			flex-wrap: wrap;

			.re-item {
				background-color: $page-color-base;
				min-width: 46%;
				padding: 0 30rpx;
				line-height: 70rpx;
				height: 70rpx;
				margin-bottom: 20rpx;
				border-radius: 35rpx;
				margin-right: 20rpx;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
				font-size: 24rpx;
				color: #4d4d4d;

				text {
					margin-right: 20rpx;
				}

				&:nth-of-type(2n) {
					margin-right: 20rpx;
				}

			}
		}
	}

	.sec-two {
		padding: 0 $spacing-lg 20rpx;

	}
</style>
