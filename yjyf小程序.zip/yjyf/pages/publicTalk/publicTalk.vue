<template>
	<view class="p-wrp">
		<u-input v-model="content" class="text bg" :type="type" :border="border" :height="height" placeholder="这一刻的想法"
		 :auto-height="autoHeight" maxlength="250" />
		<view class="up">
			<u-upload ref="uUpload" @on-success="upSuccess" :action="action" @on-remove="onRmove" :auto-upload="true"
			 @upSuccessVideo="upSuccessVideo"></u-upload>
		</view>
		<view class="choo">
			<text class="text" @click="selectHuaAction"># {{chooseItem.name||'选择一个话题'}}</text>
		</view>
		<view class="p-title">
			推荐话题
		</view>
		<view class="c-wrp">
			<view class="c-item" v-for="item in hotList" :key="item.id" @click="selectItem(item)">
				# {{item.name}}
			</view>
		</view>
		<view class="btn-wrp">
			<view class="c-btn" @click="topicAdd">
				发布
			</view>
		</view>
		<u-popup v-model="selectHuaShow" mode="bottom" border-radius="10">
			<view class="search-box">
				<u-search placeholder="搜索话题" v-model="keyword" :actionStyle="actionStyle" @search="getSearchList"></u-search>
			</view>
			<view class="se-wrp" v-if="searchList.length>0">
				<view class="c-wrp">
					<view class="c-item" v-for="item in searchList" :key="item.id" @click="selectItem(item)">
						# {{item.name}}
					</view>

				</view>
			</view>
			<empty v-if="searchList.length===0" info="没有相关话题,试试其他的吧"></empty>


		</u-popup>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue";

	export default {
		components: {
			empty
		},
		data() {
			return {
				content: '',
				videoUrl: '',
				keyword: '',
				hotList: [],
				type: 'textarea',
				chooseItem: {

				},
				border: true,
				height: 200,
				autoHeight: true,
				selectHuaShow: false,
				photos: [],
				action: this.$askUrl + '/common/upload',
				actionStyle: {
					width: '120rpx',
					background: '#11B5FF',
					padding: '10rpx 30rpx',
					color: '#fff',
					borderRadius: '40rpx'
				},
				searchList: []
			};
		},
		onLoad(val) {
			console.log(val)
			if (val.tid) {
				this.chooseItem = {
					id: val.tid,
					name: val.name

				}
			}
			this.getHotList()
		},
		methods: {
			async topicAdd() {
				console.log(this.photos, !this.content)
				if (this.photos.length === 0 && !this.content && !this.videoUrl) {
					uni.showToast({
						title: "请填写内容",
						icon: 'none'
					})
					return
				}
				if (!this.chooseItem.id) {
					uni.showToast({
						title: "请选择一个话题",
						icon: 'none'
					})
					return
				}
				let params = {
					user_id: uni.getStorageSync('uid'),
					// photos: this.photos.length > 0 ? this.photos.join(',') : '',

					photos: JSON.stringify(this.photos),
					video: this.videoUrl,
					content: this.content,
					tags: this.chooseItem.id
				}
				console.log(this.photos, params)
				let res = await this.$u.api.topicAdd(params);
				if (res.code === 200 || res.code === 1) {
					// uni.showToast({
					// 	title: res.msg,
					// 	icon: 'none',
					// 	duration: 4000
					// })
					// uni.navigateBack({
					// 	delta: 1
					// })
					this.$refs.uToast.show({
						title: res.msg,
						type: 'warning',
						back: true
					})
				}
			},
			async getHotList() {
				let params = {
					famous: 1
				}
				let res = await this.$u.api.getHotList(params);
				this.hotList = res.data
			},
			selectItem(item) {
				this.selectHuaShow = false
				this.chooseItem = item
			},
			async getSearchList() {
				let params = {
					name: this.keyword
				}
				let res = await this.$u.api.getSearchList(params);
				this.searchList = res.data
			},
			selectHuaAction() {
				this.getSearchList()
				this.selectHuaShow = true
			},
			onRmove(index) {
				this.photos.splice(index, 1)
			},
			upSuccessVideo(url) {
				console.log(url)
				this.videoUrl = url
			},
			upSuccess(data, index, lists) {
				console.log(data, index, lists)
				this.photos = lists.map(item => {
					console.log(item.response)
					return item.response
				})
			}
		}
	}
</script>

<style lang="scss">
	page {}

	.p-wrp {
		padding: 0 $spacing-base;
	}

	.up {
		margin-top: 20rpx;
	}

	.bg {
		background-color: #f9f9f9;
		border: none;
	}

	.se-wrp {
		padding: 0 30rpx;
		padding-bottom: 30rpx;
	}

	.no-content {
		.icon {
			margin: 30rpx auto;
		}
	}

	.choo {
		line-height: 90rpx;

		.text {
			background-color: $page-color-base;
			font-size: 24rpx;
			padding: 10rpx 30rpx;
			border-radius: 40rpx;
			color: #7b7b7b;
		}
	}

	.p-title {}

	.c-wrp {
		display: flex;
		flex-wrap: wrap;


		.c-item {
			background-color: $page-color-base;
			font-size: 24rpx;
			padding: 10rpx 30rpx;
			border-radius: 40rpx;
			color: #7b7b7b;
			margin-right: 30rpx;
			margin-top: 20rpx;

		}
	}

	.text {
		margin: 20rpx 0rpx;
	}

	.search-box {
		width: 100%;
		background-color: #FFFFFF;
		padding: 15rpx 2.5%;

	}

	.btn-wrp {
		text-align: center;
		margin-top: 50rpx;

		.c-btn {
			display: inline-block;
			background-color: $base-color;
			padding: 16rpx 30rpx;
			color: #FFFFFF;
			width: 160rpx;
			text-align: center;
			border-radius: 40rpx;
		}
	}
</style>
