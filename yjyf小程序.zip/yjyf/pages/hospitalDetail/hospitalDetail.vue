<template>
	<view>
		<u-navbar :is-back="true" isFixed :title="infoData.name" :border-bottom="false" ></u-navbar>
		<u-image :src="apiUrl+infoData.thumb" height="360" style="z-index: 1;" :lazy-load="true"></u-image>
		<view class="info-wrp">

			<view class="">
				<view>{{infoData.name}}</view>
				<u-read-more :toggle="true" show-height="300" color="#11B5FF">
					<rich-text :nodes="infoData.synopsis"></rich-text>
				</u-read-more>
				<!-- <view class="introduce">{{infoData.synopsis}}</view> -->
			</view>
			<!-- <view class="contact">
				<u-icon name="/static/img/dianhua.png" size="36"></u-icon>
				<view class="c-mobile-title">联系电话</view>
				<view class="c-mobile">{{infoData.phone}}</view>
				<u-icon name="arrow-right" color="#9A9A9A" size="24"></u-icon>
			</view>
			<view class="address">
				<u-icon name="/static/img/dizhi.png" size="36"></u-icon>
				<view class="a-detail">{{infoData.address}}</view>
				<u-icon name="arrow-right" color="#9A9A9A" size="24"></u-icon>
			</view> -->
			<view class="local-doctor">本院专家</view>
			<view v-for="(item,index) in doctorList" :key="index">
				<doctorItem  :itemBean="item"></doctorItem>
			</view>
		</view>
	</view>
</template>

<script>
	import doctorItem from '../../components/doctor-item/doctor-item.vue'
	export default {
		components: {
			doctorItem
		},
		data() {
			return {
				apiUrl: this.$apiUrl,
				infoData: {},
				doctorList: [],
				hospitalId: null

			};
		},
		onLoad(val) {
			this.hospitalId = val.hid || 7
			this.getHospitalDetail()
			this.getdoctorlist()
		},
		methods: {
			async getHospitalDetail() {
				let params = {
					hid: this.hospitalId,
					uid: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getHospitalDetail(params);
				this.infoData = res.data
				this.title = this.infoData.name
			},
			async getdoctorlist() {
				let params = {
					hid: this.hospitalId,
				}
				let res = await this.$u.api.getdoctorlist(params);
				this.doctorList = res.data
				
			}
		}

	}
</script>

<style lang="scss">
	* {
		color: #525252;
		font-size: 27rpx;
	}

	.info-wrp {
		position: absolute;
		width: 100%;
		padding: 48rpx 30rpx 0;
		background-color: #FFFFFF;
		margin-top: -50rpx;
		border-radius: 40rpx 40rpx 0 0;
		z-index: 9999;

		.introduce {
			margin: 30rpx 0;
			line-height: 1.9em;
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 3;
		}
	}

	.contact {
		padding: 30rpx 30rpx;
		border-bottom: #E9E9E9 solid 1rpx;
		display: flex;
		justify-content: space-between;
		margin-top: 35rpx;
		.c-mobile-title {
			margin-left: 24rpx;
			flex-grow: 10;
		}

		.c-mobile {
			margin-right: 66rpx;
		}
	}

	.address {
		padding: 30rpx 30rpx;
		display: flex;
		justify-content: center;

		.a-detail {
			margin-left: 24rpx;
			flex-grow: 10;
		}

	}

	.local-doctor {
		padding: 30rpx 30rpx;
	}
</style>
