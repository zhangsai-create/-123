<template>
	<view >
		<u-navbar :is-back="true" backIconColor="#fff" isFixed title="话题详情" titleColor="#fff" :background="background"
		 :border-bottom="false"></u-navbar>
		<view class="top-wrap">
			<view class="title">
				<text class="fu">#</text>{{huaDetail.name}}
			</view>
			<view class="info">
				<view class="left">
					{{huaDetail.gzCount}}人关注 <text class="mid">
						{{huaDetail.llCount}}人浏览
					</text> {{huaDetail.cyCount}}人参与
				</view>
				<view class="fo-wrp" v-if="huaDetail">
					<view class="btn" v-if="huaDetail.is_focus===0" @click="focusTag">
						<u-icon name="plus" class="icon" size="24"></u-icon>
						关注
					</view>
					<view class="btn" v-if="huaDetail.is_focus!==0" @click="focusTag">
						已关注
					</view>
				</view>
			</view>

		</view>

		<view class="content-box">
			<u-tabs :list="tabList" active-color="#11B5FF" :is-scroll="false" :current="current" @change="tabChange"></u-tabs>

			<view class="" v-if="current===0">
				<view class="sec-zhuan">
					<view class="yu" v-if="noticeList.length>0">
						<u-image class="title" src="/static/img/zbyg.png" height="88" width="750"></u-image>
						<view class="y-item" v-for="item in noticeList" :key="item.id" @click="goContentDetail(item)">
							<view class="left u-skeleton-rect">
								<u-image width="290" :src="apiUrl+item.thumb" :borderRadius="20" height="164"></u-image>
								<u-image class="play" src="/static/img/live-play.png" width="63" height="63"></u-image>
							</view>
							<view class="right " >
								<view class="title">{{item.title}}</view>
								<view class="r-bottom">
									<view class="left">
										<text class="name">{{item.dname}} </text>
										<text class="time">{{item.starttime|time}} </text>
									</view>
									<!-- 预约状态 0：未预约可以预约 1：已预约 2：不可预约 live类型有此字段 -->
									<view class="y-btn" v-if="item.subscribestatus===0&&item.type==='live'" @click.stop="expAddsubscribe(item)">
										预约
									</view>
									<view class="y-btn" v-if="item.subscribestatus===1&&item.type==='live'" @click.stop="expAddsubscribe(item)">
										已预约
									</view>
								</view>
							</view>
						</view>

					</view>
					<view class="z-title">
						<view class="label">
							专家说
						</view>
						<view class="more" @click="goMoreExp">
							查看更多
						</view>
					</view>
					<empty v-if="expertssaidList.length===0" info="暂无数据"></empty>
					<view class="content-wrp">
						<block v-for="item in expertssaidList" :key="item.id">
							<talkItem :item="item" @goWhere="goContentDetail" @goHua="goHua"></talkItem>
						</block>
						<u-loadmore :status="status" v-if="expertssaidList.length>=pageSize" />
						
					</view>
				</view>
			</view>
			<view v-if="current===1" class="mum-wrp">
				<empty v-if="topicList.length===0" info="暂无数据"></empty>
				<block v-for="item in topicList" :key="item.id">
					<mumSayItem @update="gettopiclistfortag()" :item="item"></mumSayItem>
				</block>
				
			</view>
			<view v-if="current===2">
				<empty v-if="doctorList.length===0" info="暂无推荐"></empty>

				<block v-for="(item,index) in doctorList" :key="index">
					<doctorItem :itemBean="item"></doctorItem>
				</block>
			</view>
		</view>

		<!--引用组件-->
		<!-- <u-skeleton :loading="loading" :animation="true" bgColor="#FFF"></u-skeleton> -->
		<dragball :x="windowWidth-100" :y="windowHeight-100" image="/static/img/fabu.png" @goWhere="goPublic"></dragball>
	</view>
</template>

<script>
	import moment from '@/common/moment';
	import mumSayItem from "../../components/mum-say-item/mum-say-item.vue";
	import doctorItem from '../../components/doctor-item/doctor-item.vue'
	import dragball from "../../components/drag-ball/drag-ball.vue";
	import talkItem from '../../components/talk-item/talk-item.vue'
	import empty from "../../components/rf-empty/index.vue";

	export default {
		data() {
			return {
				huaId: null,
				loading: true,
				tabList: [{
						name: '专家说'
					}, {
						name: '家长说'
					},
					{
						name: '推荐专家'
					}
				],
				page: 1,
				pageSize: 10,
				status: '',
				nomore: false,
				topicList: [],
				expertssaidList: [],
				windowWidth: '',
				windowHeight: '',
				current: 0,
				doctorList: [],
				noticeList: [],
				background: {
					'background-image': 'linear-gradient(90deg, #187FFF, #13B3FF)'
				},
				apiUrl: this.$apiUrl,
				huaDetail: {
					"id": 1,
					"name": "",
					"thumb": "",
					"synopsis": "",
					"gzCount": 0,
					"llCount": 0,
					"cyCount": 0,
					"is_focus": 0
				}
			}
		},

		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日 HH:mm');
			}
		},
		components: {
			dragball,
			doctorItem,
			talkItem,
			mumSayItem,
			empty
		},
		onLoad(val) {
			this.huaId = val.tid || 16
			this.tabChange(this.current)
			this.getTagDetail()
		},
		// 触底
		onReachBottom() {
			const that = this
			this.status = 'loading';
			console.log(that.page, this.nomore)
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					that.page += 1;
		
					that.getExpertssaidList()
					that.status = 'loading';
				}
			}, 2000)
		},
		onShareAppMessage(res) {
			console.log(res)
				if (res.from === 'button') {// 来自页面内分享按钮
					console.log(res.target)
					return {
						title: res.target.title,
						path: '/pages/postDetail/postDetail?id='+res.target.id
					}
				}
				
		    },
		onShow() {
			const {
				windowWidth,
				windowHeight
			} = uni.getSystemInfoSync();
			this.windowWidth = windowWidth
			this.windowHeight = windowHeight
			this.tabChange(this.current)

		},
		onPullDownRefresh() {
			console.log('refresh');
			this.page = 1
			this.getTagDetail()
			this.tabChange(this.current)
		},
		methods: {
			async getTagDetail() {
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					tag_id: this.huaId,
					user_id: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.getTagDetail(params);
				uni.stopPullDownRefresh();
				this.huaDetail = res.data
			},
			async focusTag() {
				let params = {
					tag_id: this.huaId,
					user_id: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.focusTag(params);
				this.getTagDetail()
			},
			// 预约
			async expAddsubscribe(item) {
				let params = {
					cid: item.id,
					type: item.subscribestatus === 1 ? 2 : 1,
					uid: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.expAddsubscribe(params);
				uni.showToast({
					title: res.data,
					icon: 'none'
				})
				this.getExpertssaidNoticeList()
				uni.requestSubscribeMessage({
				  tmplIds: ['DEWM6l5G7kIbEmnjTpvPK3-GfB2_d7NmQyoZnxCNe70'],
				  success (res) {
					  console.log(res)
				  },
				  fail(err){
					  console.log(err)
				  }
				})
			},
			async getExpertssaidNoticeList() {
				let params = {
					tid: this.huaId,
					uid: uni.getStorageSync('uid')
				}
				let res = await this.$u.api.getExpertssaidNoticeList(params);
				this.noticeList = res.data
			},
			async getExpertssaidList() {
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					tid: this.huaId,
					page: this.page,
					pageSize: this.pageSize
				}
				let res = await this.$u.api.getExpertssaidList(params);
				let list = res.data
				this.expertssaidList = this.page === 1 ? list : this.expertssaidList.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				} else {
					this.nomore = false
				}
			},
			async gettopiclistfortag() {
				let params = {
					tag_id: this.huaId
				}
				let res = await this.$u.api.gettopiclistfortag(params);
				let list = res.data.map(item => {
					item.photos = typeof item.photos === 'string' ? item.photos.split(',') : item.photos
					return item
				})
				this.topicList = list
			},
			goMoreExp() {
				uni.switchTab({
					url: '/pages/expertSay/expertSay'
				})
			},
			async getdoctorlist() {
				let params = {
					tid: this.huaId
				}
				let res = await this.$u.api.getdoctorlist(params);
				this.doctorList = res.data
			},
			goContentDetail(val) {
				console.log(val)
				if (val.type === 'audio') {
					uni.navigateTo({
						url: '../audioDetail/audioDetail?cid=' + val.id
					})
				} else if (val.type === 'live') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + val.id
					})
				} else if (val.type === 'text') {
					uni.navigateTo({
						url: '../articleDetail/articleDetail?cid=' + val.id
					})
				} else if (val.type === 'video') {
					uni.navigateTo({
						url: '../videoDetail/videoDetail?cid=' + val.id
					})
				}
			},
			
			goPublic() {
				uni.navigateTo({
					url: '/pages/publicTalk/publicTalk?tid=' + this.huaId + "&name=" + this.huaDetail.name
				})
			},
			goPostDetail() {
				uni.navigateTo({
					url: '/pages/postDetail/postDetail'
				})
			},
			tabChange(val) {
				this.current = val
				switch (this.current) {
					case 0:
						this.getExpertssaidList()
						this.getExpertssaidNoticeList()
						break;
					case 1:
						this.gettopiclistfortag()
						break;
					case 2:
						this.getdoctorlist()
						break;
					default:
						break;
				}
			}
		}
	}
</script>

<style lang="scss">
	.top-wrap {
		background: linear-gradient(90deg, #187FFF, #13B3FF);
		background-size: cover;
		background-repeat: no-repeat;
		padding: $spacing-base;
		font-size: 28rpx;
		color: white;
		padding-bottom: 40rpx;

		.info {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 20rpx;
			margin-top: 20rpx;

			.mid {
				margin: 0 40rpx;
			}

			.fo-wrp {
				.btn {
					background-color: #11B5FF;
					width: 170rpx;
					text-align: center;
					line-height: 59rpx;
					border-radius: 50rpx;
					font-size: 28rpx;

					.icon {
						margin-right: 4rpx;
					}

				}

			}
		}
	}

	.content-box {
		margin-top: -20rpx;
		border-radius: 10rpx 10rpx 0 0;
		overflow: hidden;
	}

	.sec-zhuan {
		.y-item {
			display: flex;
			align-items: center;
			padding: 33rpx 25rpx 33rpx 38rpx;
			border-bottom: 1rpx solid #EEEEEE;

			.left {
				position: relative;
			}

			.play {
				position: absolute;
				top: 50%;
				left: 50%;
				margin-left: -32rpx;
				margin-top: -32rpx;
			}

			.right {
				flex: 1;
				margin-left: 25rpx;

				.title {
					color: #272727;
					font-size: 28rpx;
				}

				.r-bottom {
					display: flex;
					align-items: center;
					justify-content: space-between;
					margin-top: 24rpx;
					color: #6c6c6c;

					.left {
						flex: 1;
					}

					.time {
						font-size: 21rpx;
						margin-left: 10rpx;
					}

					.y-btn {
						line-height: 60rpx;
						background-color: $base-color;
						color: #FFFFFF;
						padding: 0 20rpx;
						border-radius: 40rpx 0 0 40rpx;
					}

					.status {
						display: inline-block;
					}
				}


			}


		}

		.z-title {
			display: flex;
			justify-content: space-between;
			padding: 0 $spacing-lg;
			line-height: 80rpx;
			font-size: 24rpx;
			color: #595959;

			.more {
				color: #282828;
			}
		}
	}

	.mum-wrp {
		padding: 0 $spacing-lg 20rpx;
	}
</style>
