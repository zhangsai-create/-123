<template>
	<view>
		<view class="sec-one">
			<empty v-if="growList.length===0" info="还没有发布过哦"></empty>
			<view class="r-item" v-for="item in growList" :key="item.id">
				<u-image class="icon-left" src="/static/img/naozhong.png" mode="aspectFit" width="30" height="30" :lazy-load="true"></u-image>
				<view class="top">
					<text class="time">{{item.created_time| time}}</text>

				</view>
				<view class="content">
					<view class="title">
						{{item.content}}
						
					</view>
					<view class="video-wrp" v-if="item.video" @click.stop="">
						<video v-if="item.video" :src="apiUrl+item.video"  ></video>
						
					</view>
					<view class="img-wrp">
						<u-image v-for="(son,index) in item.photo" :key="index" :src="apiUrl+son" class="img-item" mode="aspectFit" width="204"
						 height="204" :lazy-load="true"></u-image>
					</view>
				</view>
			</view>
			<u-loadmore :status="status" v-if="growList.length>pageSize" />
			
			
		</view>
		<dragball :x=windowWidth-100 :y=windowHeight-100 image="/static/img/fabu.png" @goWhere="goPublic"></dragball>


	</view>
</template>

<script>
	import moment from '@/common/moment';
	import dragball from "../../components/drag-ball/drag-ball.vue";
	import empty from "../../components/rf-empty/index.vue";

	export default {
		components: {
			dragball,
			empty
		},
		data() {
			return {
				growList: [],
				apiUrl: this.$apiUrl,
				windowWidth: '',
				windowHeight: '',
				page: 1,
				pageSize: 10,
				status: '',
				nomore: false

			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			}
		},

		onShow() {
			const {
				windowWidth,
				windowHeight
			} = uni.getSystemInfoSync();
			this.windowWidth = windowWidth
			this.windowHeight = windowHeight
			this.getAllRecord()
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';

			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getAllRecord()
					this.status = 'loading';
				}
			}, 2000)
		},
		methods: {
			async getAllRecord() {
				let params = {
					user_id: uni.getStorageSync('uid'),
					num: this.pageSize,
					page: this.page
				}
				let res = await this.$u.api.getAllRecord(params);
				let list = res.data.map(item => {
					item.photo = typeof item.photo === 'string'&&item.photo.length>0 ? item.photo.split(',') : item.photos
					return item
				})
				this.growList = this.page === 1 ? list : this.growList.concat(list)
				if (list.length < this.pageSize) {
					this.nomore = true
				}
			},
			goPublic() {
				uni.navigateTo({
					url: '/pages/recordGrow/recordGrow'
				})
			}
		}
	}
</script>

<style lang="scss">
	.sec-one {
		padding: 0 $spacing-lg;

		.r-item {
			position: relative;
			padding-left: 40rpx;
			padding-bottom: 20rpx;

			&::before {
				content: '';
				width: 1rpx;
				height: 100%;
				position: absolute;
				top: 10rpx;
				left: 14rpx;
				background-color: $page-color-base;

			}

			.icon-left {
				position: absolute;
				top: 6rpx;
				left: 0;
				background-color: #FFFFFF;
			}

			.top {
				display: flex;
				align-items: center;

				.time {
					color: $font-color-light;
					margin-bottom: 20rpx;
				}
			}

			.content {

				.title {
					font-size: 28rpx;
					color: $font-color-base;
					margin-bottom: 20rpx;
					overflow: hidden;
					display: -webkit-box; //将元素设为盒子伸缩模型显示
					-webkit-box-orient: vertical; //伸缩方向设为垂直方向
					-webkit-line-clamp: 2; //超出3行隐藏，并显示省略号
				}

				.img-wrp {
					display: flex;
					flex-wrap: wrap;
					align-items: flex-start;

					.img-item {
						margin-bottom: 16rpx;
						margin-right: 16rpx;
					}

				}
			}
		}

	}
</style>
