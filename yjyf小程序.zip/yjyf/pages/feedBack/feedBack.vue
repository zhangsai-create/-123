<template>
	<view class="content">
		<u-input v-model="value" class="text bg" :type="type" :border="border" :height="height" :auto-height="autoHeight" />
		<view class="btn-wrp">
			<view class="c-btn">
				提交
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value: '',
				type: 'textarea',
				border: true,
				height: 200,
				autoHeight: true,
			};
		}
	}
</script>

<style lang="scss">
	page {
		background-color: $page-color-base;
		padding: 0 $spacing-lg;

	}
	.bg {
		background-color: #FFFFFF;
		border: none;
	}

	.text {
		margin: 20rpx 0;
	}
	.btn-wrp{
		text-align: center;
		margin-top: 80rpx;
		.c-btn{
			display: inline-block;
			background-color: $base-color;
			padding: 10rpx 30rpx;
			color: #FFFFFF;
			width: 140rpx;
			text-align: center;
			border-radius: 4rpx;
		}
	}
</style>
