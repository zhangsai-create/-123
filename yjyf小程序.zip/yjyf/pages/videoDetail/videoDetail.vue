<template>
	<view>
		<!-- <u-sticky> -->
			<!-- 只能有一个根元素 -->
			<view class="v-top">
				<video id="myVideo" :title="infoData.title" :poster="apiUrl+infoData.thumb" show-mute-btn enable-play-gesture
				 height="422" :src="infoData.video" object-fit="fill" :danmu-btn="false" @error="videoErrorCallback" controls></video>
				<text class="watch-count" v-if="open">{{infoData.pv}}次观看 </text>
			</view>
		<!-- </u-sticky> -->
		<view class="title">
			<!-- <text class="t-status">{{infoData.label}}</text> -->
			<text class="t-text">{{infoData.title}}</text>
		</view>

		<view class="doctor-info" v-if="type!=='tv'">
			<u-image width="87" :src="apiUrl+doctorData.thumb" height="87" shape="circle"></u-image>
			<view class="mid">
				<view class="name">
					{{doctorData.name}} {{doctorData.position}}
				</view>
				<text class="hospital">{{doctorData.hname}}</text>
			</view>
			<view class="focus" @click.stop="followdocter">{{doctorData.followstatus===0? '关注': '不再关注'}}</view>
		</view>
		<view class="doctor-info" v-if="type==='tv'">
			<u-image width="87" height="87" src="/static/img/tvlogo.png" shape="circle"></u-image>
			<view class="mid">
				<view class="name">
					优妈育儿堂
				</view>
				<text class="hospital">山东教育卫视节目</text>
			</view>
			<view class="focus" @click="goMomParenting">进入</view>
		</view>

		<view class="menu-btn">
			<view class="btn" @click="expPushlike">
				<u-image src="/static/img/like.png" width="38" height="35" mode="aspectFit"></u-image>
				<text class="b-text">{{infoData.islikes===0?'喜欢': '已收藏'}}</text>
			</view>
			<!-- <view class="btn">
				<u-image src="/static/img/zengsongliwu.png" width="38" height="35" mode="aspectFit"></u-image>
				<text class="b-text">送礼物</text>
			</view> -->
			<button open-type="share" class="btn">
				<u-image src="/static/img/share.png" width="38" style="margin-top: -10rpx;" height="35" mode="aspectFit"></u-image>
				<text class="b-text">分享</text>
			</button>
		</view>

		<view class="relevant-video">
			<view class="title"> 相关视频 </view>
			<scroll-view class="scroll-view" scroll-x="true" @scroll="scroll" scroll-left="120">
				<view class="item" v-for="item in recomendList" :key="item.id" @click="goDetail(item.id)">
					<view class="img-wrp">
						<u-image class="img" :src="apiUrl+item.thumb" width="282" :borderRadius="20" height="158" :lazy-load="true"></u-image>
						<u-image class="play" src="/static/img/video-play.png" width="24" height="30" mode="aspectFit"></u-image>
						<view class="bot">
							<text class="play-count">{{item.pv}}次观看</text>
							<text class="duration">{{item.releasetime| time}}</text>
						</view>
					</view>
					<view class="item-title u-line-1">{{item.title}} </view>
				</view>

			</scroll-view>

		</view>
		<view style="padding-bottom:90rpx;">
			<RemarkInput ref="remark" :title="infoData.title" :cid="cid" :commentList="commentList" @update="getcommentList" @expPushlike="expPushlike"></RemarkInput>
			<u-loadmore :status="status" v-if="commentList.length>pageSize" />
		
		</view>

	</view>
</template>

<script>
	import RemarkInput from "../../components/RemarkInput/RemarkInput.vue"
	
	import moment from '@/common/moment';
	import empty from "../../components/rf-empty/index.vue";
	export default {
		components: {
			empty
		},
		data() {
			return {
				cid: null,
				type: '',
				customStyle:{
					border:'0',
					color:'red'
				},
				open: false,
				isVisible: false,
				apiUrl: this.$apiUrl,
				infoData: {},
				doctorData: {},
				commentList: [],
				recomendList: [],
				page: 1,
				pageSize: 10,

			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			}
		},
		onLoad(val) {
			this.cid = val.cid || 13
			this.type = val.type
			this.initData()
			this.getcommentList()
			this.getHotExpertssaidList()
		},
		onPullDownRefresh() {

		},
		methods: {
			initData() {
				if (this.type === 'tv') {
					this.getTvcontent()
				} else {
					this.getExpertssaid()
				}
			},
			async getTvcontent() {
				let params = {
					cid: this.cid
				}
				let res = await this.$u.api.getTvcontent(params);
				this.infoData = res.data
			},
			
			async getExpertssaid() {
				let params = {
					cid: this.cid
				}
				let res = await this.$u.api.getExpertssaid(params);
				this.infoData = res.data
				this.getdoctorDetail(res.data.did)
			},


			async getHotExpertssaidList() {
				// 不需要分类可以不传此参数或传0（如热门推荐） text：图文 video：视频 audio：音频
				let params = {
					hot: 1,
					type: 'video',
					page: 1,
					pageSize: 10
				}
				let res = await this.$u.api.getExpertssaidList(params);
				uni.stopPullDownRefresh();
				this.recomendList = res.data
			},
			share() {
				// 该对象已集成到this.$u中，内部属性如下
				this.$u.mpShare = {
					title: this.infoData.title, // 默认为小程序名称，可自定义
					path: '/pages/videoDetail/videoDetail?id=' + this.cid, // 默认为当前页面路径，一般无需修改，QQ小程序不支持
					// 分享图标，路径可以是本地文件路径、代码包文件路径或者网络图片路径。
					// 支持PNG及JPG，默认为当前页面的截图
					imageUrl: ''
				}
			},
			async getdoctorDetail(id) {
				let params = {
					did: id,
					uid: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getdoctorDetail(params);
				this.doctorData = res.data
			},
			async expPushlike() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					type: this.infoData.islikes === 0 ? 1 : 2,
					// 1：收藏 2：取消收藏
				}
				let res = await this.$u.api.expPushlike(params);
				uni.showToast({
					title:res.data,
					icon:'none'
				})
				this.initData()
			},
			async followdocter() {
				let params = {
					did: this.doctorData.id,
					uid: uni.getStorageSync('uid'),
					type: this.doctorData.followstatus === 0 ? '1' : '2'
				}
				let res = await this.$u.api.followdocter(params);
				// if (res.code !== 200&&res.code !== 1) return
				this.getdoctorDetail(this.doctorData.id)
			},
			async getcommentList() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getcommentList(params);
				this.commentList = res.data
			},
			videoErrorCallback() {

			},
			goMomParenting() {
				uni.navigateTo({
					url: '/pages/momParenting/momParenting'
				})
			},
				
			goDetail(id) {
				uni.navigateTo({
					url:'/pages/videoDetail/videoDetail?cid='+id
				})
				
			},
			async addcomment(val) {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					comment: this.comment
				}
				let res = await this.$u.api.addcomment(params);
				if (res.code !== 200&&res.code !== 1) return
				uni.showToast({
					title: '评论成功',
					icon: 'none'
				})
				this.isVisible = false
				this.getcommentList()
			},

			close() {
				this.isVisible = false
			}


		}
	}
</script>

<style lang="scss">
	page {
		color: #272727;
		font-size: 28rpx;
	}
	#myVideo {
		
		width: 100%;
		height: 422rpx;
	}

	.v-top {
		position: relative;
		margin-bottom: 20rpx;

		.play {
			position: absolute;
			top: 50%;
			left: 50%;
			margin-top: -100rpx;
			margin-left: -62rpx;
		}

		.watch-count {
			font-size: 25rpx;
			color: #FFFFFF;
			position: absolute;
			background-color: #F09FA0;
			padding: 13rpx 15rpx;
			border-radius: 100rpx;
			top: 28rpx;
			right: 15rpx;
		}
	}

	.title {
		margin: 0 32rpx;

		.t-status {
			background-color: #F09FA0;
			border-radius: 100rpx;
			color: #FFFFFF;
			margin-right: 10rpx;
			font-size: 25rpx;
			padding: 8rpx 15rpx;
			display: inline-flex;
		}

		.t-text {
			color: #505050;
			font-size: 30rpx;
			font-weight: 800;
		}
	}

	.doctor-info {
		display: flex;
		padding: 56rpx 29rpx;
		align-items: center;

		.mid {
			margin-left: 26rpx;
			flex: 1;

			.name {
				color: #505050;
				font-size: 30rpx;
				font-weight: 800;
			}

			.hospital {
				color: #A6A6A6;
				font-size: 21rpx;
				margin-top: 13rpx;
			}
		}

		.focus {
			font-size: 25rpx;
			color: #FFFFFF;
			padding: 16rpx 30rpx;
			background-color: #F09FA0;
			border-radius: 100rpx;
		}
	}

	.menu-btn {
		display: flex;
		justify-content: space-between;
		padding: 0 23rpx 33rpx;
		border-bottom: 17rpx solid #FAF8F8;
		button{
			line-height: 60rpx;
		}
		.btn {
			flex: 1;
			background-color: #F5F5F5;
			border-radius: 100rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			margin: 0 10rpx;
			height: 60rpx;
			
			.b-text {
				color: #505050;
				font-size: 25rpx;
				margin-left: 21rpx;
			}
		}
	}

	.relevant-video {
		
		.title {
			line-height: 80rpx;
			color: #F09FA0;
			font-size: 25rpx;
			font-weight: 700;
			padding-left: 31rpx;
			
		}

		.scroll-view {
			width: 100%;
			white-space: nowrap;
			display: flex;
			padding-left: 15rpx;
			flex-wrap: nowrap;
			align-items: center;

			.item {
				display: inline-block;
				margin: 0 16rpx;
				padding-left: 10rpx;
				font-size: 28rpx;
				width: 280rpx;
				vertical-align: top;

				.img-wrp {
					position: relative;
					margin-bottom: 20rpx;

					.img {
						border-radius: 10rpx;
					}

					.play {
						position: absolute;
						font-size: 25rpx;
						color: #FF0000;
						top: 50%;
						left: 50%;
						margin-top: -20rpx;
						margin-left: -15rpx;
					}

					.bot {
						position: absolute;
						bottom: 0;
						left: 0;
						width: 100%;
						font-size: 24rpx;
						color: #FFFFFF;
						display: flex;
						justify-content: space-between;
					}
				}
			}
		}
	}

	.comm-head {
		display: flex;
		justify-content: center;
		padding: 35rpx 0;
	}

	.comment {
		position: fixed;
		left: 0;
		width: 100%;
		bottom: 30rpx;
		display: flex;
		padding-left: 47rpx;
		align-items: center;

		.input {
			background-color: #F0F0F0;
			border-radius: 30rpx;
			display: flex;
			padding: 0 20rpx;
			flex: 1;
			align-items: center;
		}

		.like {
			margin-left: 40rpx;
		}

		.share {
			margin: 0 34rpx 0 27rpx;
		}


	}
</style>
