<template>
	<view>
		<!-- <u-sticky> -->
		<!-- 只能有一个根元素 -->
		<view class="v-top">
			<video id="myVideo" :title="infoData.title" :poster="apiUrl+infoData.thumb" show-mute-btn enable-play-gesture height="422"
			 :src="infoData.video" object-fit="fill"  :danmu-btn="false" @error="videoErrorCallback" controls></video>
			<text class="watch-count" v-if="open">{{infoData.pv}}次观看 </text>
		</view>
		<!-- </u-sticky> -->
		<view class="title">
			<!-- <text class="t-status">{{infoData.label}}</text> -->
			<text class="t-text">{{infoData.title}}</text>
		</view>
		<view class="doctor-info">
			<u-image width="87" height="87" src="/static/img/tvlogo.png" shape="circle"></u-image>
			<view class="mid">
				<view class="name">
					优妈育儿堂
				</view>
				<text class="hospital">山东教育卫视节目</text>
			</view>
			<view class="focus" @click="goMomParenting">进入</view>
		</view>

		<view class="menu-btn">
			<view class="btn" @click="tvPushlike">
				<u-image src="/static/img/like.png" width="38" height="35" mode="aspectFit"></u-image>
				<text class="b-text">{{infoData.islikes===0?'喜欢': '已收藏'}}</text>
			</view>
			<!-- <view class="btn">
				<u-image src="/static/img/zengsongliwu.png" width="38" height="35" mode="aspectFit"></u-image>
				<text class="b-text">送礼物</text>
			</view> -->
			<button open-type="share" class="btn">
				<u-image src="/static/img/share.png" width="38" height="35" mode="aspectFit" style="margin-top: -10rpx;"></u-image>
				<text class="b-text">分享</text>
			</button>
		</view>

		<view class="relevant-video">
			<view class="title"> 相关视频 </view>
			<scroll-view class="scroll-view" scroll-x="true" scroll-left="120">
				<view class="item" v-for="item in recomendList" :key="item.id" @click="goMomDetail(item.id)">
					<view class="img-wrp">
						<u-image class="img" :src="apiUrl+item.thumb" width="282" :borderRadius="20" height="158" :lazy-load="true"></u-image>
						<u-image class="play" src="/static/img/video-play.png" width="24" height="30" mode="aspectFit"></u-image>
						<view class="bot">
							<text class="play-count">{{item.pv}}次观看</text>
							<text class="duration">{{item.releasetime| time}}</text>
						</view>
					</view>
					<view class="item-title u-line-1">{{item.title}} </view>
				</view>

			</scroll-view>

		</view>
		<view style="padding-bottom:90rpx;">
			<RemarkInput ref="remark" type="tv" :title="infoData.title" :cid="cid" :commentList="commentList" @update="getcommentList"
			 @tvPushlike="tvPushlike" @share="share"></RemarkInput>
			<u-loadmore :status="status" v-if="commentList.length>pageSize" />

		</view>

	</view>
</template>

<script>
	import RemarkInput from "../../components/RemarkInput/RemarkInput.vue"

	import moment from '@/common/moment';
	import empty from "../../components/rf-empty/index.vue";
	export default {
		components: {
			empty
		},
		data() {
			return {
				cid: null,
				type: '',
				open: false,
				isVisible: false,
				apiUrl: this.$apiUrl,
				infoData: {},
				doctorData: {},
				commentList: [],
				recomendList: [],
				page: 1,
				pageSize: 10,

			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			}
		},
		onLoad(val) {
			this.cid = val.cid || 13
			this.type = val.type
			this.initData()
			this.getcommentList()
			this.getTvcontentlist()
		},
		onPullDownRefresh() {

		},
		methods: {

			initData() {
				this.getTvcontent()
			},
			async getTvcontent() {
				let params = {
					cid: this.cid
				}
				let res = await this.$u.api.getTvcontent(params);
				this.infoData = res.data
			},
			async getTvcontentlist() {
				let params = {
					page: 1,
					num: 10
				}
				let res = await this.$u.api.getTvcontentlist(params);
				this.recomendList = res.data
			},
			async tvPushlike() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					type: this.infoData.islikes === 0 ? 1 : 2,
					// 1：收藏 2：取消收藏
				}
				let res = await this.$u.api.tvPushlike(params);
				uni.showToast({
					title: res.data,
					icon: 'none'
				})
				this.initData()
			},
			async followdocter() {
				let params = {
					did: this.doctorData.id,
					uid: uni.getStorageSync('uid'),
					type: this.doctorData.followstatus === 0 ? '1' : '2'
				}
				let res = await this.$u.api.followdocter(params);
				if (res.code !== 200&&res.code !== 1) return
				this.getdoctorDetail(this.doctorData.id)
			},
			async getcommentList() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getTvcommentlist(params);
				this.commentList = res.data
			},
			videoErrorCallback() {

			},
			goMomParenting() {
				uni.navigateTo({
					url: '/pages/momParenting/momParenting'
				})
			},
			goMomDetail(id) {
				uni.navigateTo({
					url: '/pages/momDetail/momDetail?cid=' + id
				})
			},

			close() {
				this.isVisible = false
			}


		}
	}
</script>

<style lang="scss">
	page {
		color: #272727;
		font-size: 28rpx;
	}

	#myVideo {

		width: 100%;
		height: 422rpx;
	}

	.v-top {
		position: relative;
		margin-bottom: 20rpx;

		.play {
			position: absolute;
			top: 50%;
			left: 50%;
			margin-top: -100rpx;
			margin-left: -62rpx;
		}

		.watch-count {
			font-size: 25rpx;
			color: #FFFFFF;
			position: absolute;
			background-color: #F09FA0;
			padding: 13rpx 15rpx;
			border-radius: 100rpx;
			top: 28rpx;
			right: 15rpx;
		}
	}

	.title {
		margin: 0 32rpx;

		.t-status {
			background-color: #F09FA0;
			border-radius: 100rpx;
			color: #FFFFFF;
			margin-right: 10rpx;
			font-size: 25rpx;
			padding: 8rpx 15rpx;
			display: inline-flex;
		}

		.t-text {
			color: #505050;
			font-size: 30rpx;
			font-weight: 800;
		}
	}

	.doctor-info {
		display: flex;
		padding: 56rpx 29rpx;
		align-items: center;

		.mid {
			margin-left: 26rpx;
			flex: 1;

			.name {
				color: #505050;
				font-size: 30rpx;
				font-weight: 800;
			}

			.hospital {
				color: #A6A6A6;
				font-size: 21rpx;
				margin-top: 13rpx;
			}
		}

		.focus {
			font-size: 25rpx;
			color: #FFFFFF;
			padding: 16rpx 30rpx;
			background-color: #F09FA0;
			border-radius: 100rpx;
		}
	}

	.menu-btn {
		display: flex;
		justify-content: space-between;
		padding: 0 23rpx 33rpx;
		border-bottom: 17rpx solid #FAF8F8;
		button {
			line-height: 60rpx;
			vertical-align: middle;
		}
		.u-image{
			vertical-align: middle;
		}

		.btn {
			flex: 1;
			background-color: #F5F5F5;
			border-radius: 100rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			margin: 0 10rpx;
			height: 60rpx;
			line-height: 60rpx;
			vertical-align: middle;

			.b-text {
				color: #505050;
				font-size: 25rpx;
				margin-left: 21rpx;
			}
		}
	}

	.relevant-video {

		.title {
			line-height: 80rpx;
			color: #F09FA0;
			font-size: 25rpx;
			font-weight: 700;
			padding-left: 31rpx;

		}

		.scroll-view {
			width: 100%;
			white-space: nowrap;
			display: flex;
			padding-left: 15rpx;
			flex-wrap: nowrap;
			align-items: center;

			.item {
				display: inline-block;
				margin: 0 16rpx;
				padding-left: 10rpx;
				font-size: 28rpx;
				width: 280rpx;
				vertical-align: top;

				.img-wrp {
					position: relative;
					margin-bottom: 20rpx;

					.img {
						border-radius: 10rpx;
					}

					.play {
						position: absolute;
						font-size: 25rpx;
						color: #FF0000;
						top: 50%;
						left: 50%;
						margin-top: -20rpx;
						margin-left: -15rpx;
					}

					.bot {
						position: absolute;
						bottom: 0;
						left: 0;
						width: 100%;
						font-size: 24rpx;
						color: #FFFFFF;
						display: flex;
						padding: 0 10rpx;
						justify-content: space-between;
					}
				}
			}
		}
	}
</style>
