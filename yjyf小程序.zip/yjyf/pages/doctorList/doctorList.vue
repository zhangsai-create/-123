<template>
	<view>
		<empty v-if="doctorList.length===0" info="还没有数据哦"></empty>
		
		
		<block v-for="(item,index) in doctorList" :key="index">
			<doctorItem :itemBean="item"></doctorItem>
		</block>
	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue";
	
	import doctorItem from '../../components/doctor-item/doctor-item.vue'
	export default {
		components: {
			doctorItem,
			empty
		},
		data() {
			return {
				title: '',
				doctorList: [],
				deptId: ''
			};
		},
		onLoad(data) {
			console.log(data.type)
			switch (data.type) {
				case 'famousDoctor':
					uni.setNavigationBarTitle({
						title: "名医咨询"
					})
					this.getFamousdoctorlist()
					break
				case 'todayClinic':
					uni.setNavigationBarTitle({
						title: "今日义诊"
					})
					this.getVolunteerDoctorlist()
					break
				case 'dept':
					uni.setNavigationBarTitle({
						title: data.name
					})
					this.deptId = data.deptId
					this.getDeptIdrDoctorlist()
					break
			}
		},
		methods: {
			async getFamousdoctorlist() {
				let params = {
					famous: 1
				}
				let res = await this.$u.api.getdoctorlist(params);
				this.doctorList = res.data
			},
			async getVolunteerDoctorlist() {
				let params = {
					volunteer: 1
				}
				let res = await this.$u.api.getdoctorlist(params);
				this.doctorList = res.data
			},
			async getDeptIdrDoctorlist() {
				let params = {
					did: this.deptId
				}
				let res = await this.$u.api.getdoctorlist(params);
				this.doctorList = res.data
			}
			
		}
	}
</script>

<style lang="scss">

</style>
