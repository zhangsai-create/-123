<template>
	<view>
		<view class="head">
			<u-image class="photo" :src="apiUrl+infoData.thumb" width="472" height="292"></u-image>
		</view>
		<view class="title">{{infoData.title}}</view>
		<view class="item-foot">
			<view class="author">{{infoData.dname}}</view>
			<view class="label">
				<text class="label-item">#{{infoData.tname}}</text>
			</view>
			<view class="date">{{infoData.releasetime|time}}</view>
		</view>

		<view class="control">
			<audio id="audio" style="text-align: left" :src="infoData.audio" :name="infoData.name" :author="infoData.author"
			 :controls="false"></audio>

			<view class="c-mid">
				<u-image src="/static/img/last.png" width="28" height="34"></u-image>
				<view class="play" @click="play()">
					<u-icon :name="playIcon" size="34" color="#F09FA0"></u-icon>
				</view>
				<u-image src="/static/img/next.png" width="28" height="34"></u-image>
			</view>
			<u-image src="/static/img/mlist.png" width="33" height="35"></u-image>
		</view>
		<view>
			<RemarkInput ref="remark" :commentList="commentList" :cid="cid" @addcomment="addcomment" @update="getcommentList"></RemarkInput>
			<u-loadmore :status="status" v-if="commentList.length>pageSize" />

		</view>

	</view>
</template>

<script>
	import moment from '@/common/moment';
	import RemarkInput from "../../components/RemarkInput/RemarkInput.vue"
	export default {
		components: {
			RemarkInput,
		},
		data() {
			return {
				cid: null,
				apiUrl: this.$apiUrl,
				audioUrl: '',
				infoData: {},
				commentList: [],
				page: 1,
				pageSize: 10,
				status: '',
				nomore: false,
				playIcon: "play-right-fill",
				innerAudioContext: null
			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			}
		},
		onLoad(val) {
			this.cid = val.cid || '16'
			this.getExpertssaid()
			this.getcommentList()
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getcommentList()
					this.status = 'loading';
				}
			}, 2000)
		},
		onPullDownRefresh() {
			this.page = 1
			this.getExpertssaid()
			this.getcommentList()
		},
		onHide() {
			if (this.innerAudioContext != null && !this.innerAudioContext.paused) {
				this.playIcon = 'play-right-fill';
				this.innerAudioContext.pause();
			}
		},
		onUnload() {
			if (this.innerAudioContext != null) {
				this.innerAudioContext.destroy();
			}
		},
		methods: {
			async getExpertssaid() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getExpertssaid(params);
				this.infoData = res.data
				this.audioUrl = this.apiUrl + res.data.audio
			},

			async getcommentList() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getcommentList(params);

				this.commentList = this.page === 1 ? res.data : this.commentList.concat(res.data)
				if (res.data.length < this.pageSize) {
					this.nomore = true
				}
			},
			async addcomment(val) {
				console.log('hj', val)
				if (!val) {
					uni.showToast({
						title: '请输入评论内容'
					})
				}
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					comment: val,
					comment_type: 0
				}
				let res = await this.$u.api.addcomment(params);
				if (res.code !== 200 && res.code !== 1) return
				uni.showToast({
					title: '评论成功',
					icon: 'none'
				})
				this.$refs.remark.isVisible = false
				this.getcommentList()
			},
			play() {
				console.log(this.audioUrl)
				if (this.innerAudioContext == null) {
					this.innerAudioContext = uni.createInnerAudioContext();
					this.innerAudioContext.autoplay = true;
					this.innerAudioContext.src = this.audioUrl;
					this.innerAudioContext.onPlay(() => {
						console.log('开始播放', this.audioUrl);
						this.playIcon = 'pause';
					});
					this.innerAudioContext.onError((res) => {
						console.log(res);
					});
				} else {
					if (this.innerAudioContext.paused) {
						this.innerAudioContext.play();
						this.playIcon = 'pause';
					} else {
						this.innerAudioContext.pause();
						this.playIcon = 'play-right-fill';
					}
				}
			},
		}
	}
</script>

<style lang="scss">
	.head {
		padding: 35rpx 0;
		text-align: center;

		.photo {
			display: inline-block;
		}
	}

	page {
		color: #272727;
		font-size: 28rpx;
		padding-bottom: 100rpx;
	}

	.img {
		margin: 39rpx auto;
	}

	.title {
		margin: 0 32rpx;
	}

	.item-foot {
		display: flex;
		margin: 0 32rpx;
		margin-top: 22rpx;
		align-items: center;

		.author {
			color: #5A5A5A;
			font-size: 23rpx;
		}

		.label {
			flex-grow: 10;
			margin-left: 10rpx;
		}

		.label-item {
			background-color: #F0F0F0;
			border-radius: 100rpx;
			padding: 8rpx 20rpx;
			color: #8F8F8F;
		}

		.date {
			font-size: 20rpx;
			color: #494949;
		}
	}

	.control {
		display: flex;
		align-items: center;
		margin-top: 30rpx;
		padding-bottom: 55rpx;
		padding-right: 44rpx;
		border-bottom: 12rpx solid #FAF8F8;

		.c-mid {
			flex: 1;
			display: flex;
			align-items: center;
			justify-content: center;

			.play {
				width: 90rpx;
				height: 90rpx;
				margin: 0 60rpx;
				border: 7rpx #F09FA0 solid;
				border-radius: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
			}
		}
	}
</style>
