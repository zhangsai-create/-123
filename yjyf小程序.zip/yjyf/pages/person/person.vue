<template>
	<view>
		<u-navbar :is-back="false" backIconColor="#fff" isFixed title="个人中心" titleColor="#fff" :background="background"
		 :border-bottom="false"></u-navbar>
		<view class="account-info">
			<view class="top">
				<u-image :src="apiUrl+userInfo.avatar" class="avatar" width="125" height="125" shape="circle" :lazy-load="true"></u-image>
				<text class='name'>{{userInfo.openname}}</text>
				<u-icon class="icon" @click="goUserInfo" name="/static/img/info_edit_white.png" color="#fff" size="26"></u-icon>
			</view>
			<view class="bottom">
				<view class="b-item">
					<view class='num' v-text="userInfo.topicCount"> </view>
					<text>帖子</text>
				</view>
				<view class="b-item">
					<view class='num' v-text="userInfo.topicCount"></view>
					<text>赞</text>
				</view>
				<view class="b-item">
					<view class='num' v-text="userInfo.commentCount"> </view>
					<text> 消息</text>
				</view>
			</view>
		</view>

		<!-- <view class="baby-info"> -->
			<!-- <view class="info">
				<u-image :src="apiUrl+userInfo.avatar" class="avatar" width="110" height="110" shape="circle" :lazy-load="true"></u-image>
				<view class='mid'>
					<view class="birth" v-if="userInfo.pregnancy_status==='2'" @click="editBaoInfo">
						<view class="name-age">{{userInfo.child_name}} {{userInfo.pregnancy_cycle}} </view>
						<u-icon class="icon" name="/static/img/info_edit_gray.png" color="#fff" size="22"></u-icon>
					</view>
					<view class="birth" v-if="userInfo.pregnancy_status==='1'" @click="editYuInfo">
						预产期：{{userInfo.birth_time | time}}
						<u-icon class="icon" name="/static/img/info_edit_gray.png" color="#fff" size="22"></u-icon>
					</view>
					<view class="birth" v-if="userInfo.pregnancy_status==='0'">
						正在备孕中</view>
				</view>

				<text class="record-btn" @click="goRecordGrow()">记录成长轨迹</text>
			</view> -->

			<!-- 	<view class='menu' >
				<view class='item' @click="goMini">
					<view>
						<view class='title no1'>优妈推荐</view>
						<view class='content'>母婴精品任你选还有分享把钱赚</view>
					</view>
					<u-image class="img" src="/static/img/girl_clothes.png" width="100" height="100" mode="aspectFit" :lazy-load="true"></u-image>
				</view>

				<view class='item' @click="goAskDoctor">
					<view>
						<view class='title'>问专家</view>
						<view class='content'>链接互联网单位在线提问与专家沟通</view>
					</view>
					<u-image class="img" src="/static/img/tissue.png" width="100" height="100" mode="aspectFit" :lazy-load="true"></u-image>
				</view> -->

			<!-- <view class='item'>
					<view>
						<view class='title'>同城孕妈群</view>
						<view class='content'>推荐身边的孕妈群方便沟通交流</view>
					</view>
					<u-image class="img" src="/static/img/sleeping_basket.png" width="100" height="100" mode="aspectFit" :lazy-load="true"></u-image>
				</view>

				<view class='item'>
					<view>
						<view class='title'>优惠券</view>
						<view class='content'>链接互联网单位在线提问与专家沟通</view>
					</view>
					<u-image class="img" src="/static/img/yellow_duck.png" width="100" height="100" mode="aspectFit" :lazy-load="true"></u-image>
				</view> 
		</view>-->
		<!-- </view> -->
		<view class="div-line"></view>
		<view>
			<u-cell-group>
				<u-cell-item icon="/static/img/perfect_info.png" :iconStyle="{'marginRight': '30rpx'}" title="完善资料" @click="goUserInfo"
				 :center="true"></u-cell-item>
				<!-- <u-cell-item icon="/static/img/sys_notice.png" :iconStyle="{'marginRight': '30rpx'}" title="系统消息" :center="true"></u-cell-item> -->
				<u-cell-item icon="/static/img/focus_topic.png" :iconStyle="{'marginRight': '30rpx'}" title="我的关注" @click="goMyFocus"
				 :center="true"></u-cell-item>
				<u-cell-item icon="/static/img/my_collect.png" :iconStyle="{'marginRight': '30rpx'}" @click="goCollection()" title="我的收藏"
				 :center="true"></u-cell-item>
				<!-- <u-cell-item icon="/static/img/subscribe_live.png" :iconStyle="{'marginRight': '30rpx'}" @click="goAppointment()"
				 title="预约直播" :center="true"></u-cell-item> -->
				<button open-type="contact">
					<u-cell-item icon="/static/img/call_service.png" :iconStyle="{'marginRight': '30rpx'}" title="咨询客服" :center="true"></u-cell-item>
				</button>
				<u-cell-item icon="/static/img/setup.png" :iconStyle="{'marginRight': '30rpx'}" title="设置" :center="true" @click="openSet"></u-cell-item>
				<u-cell-item icon="/static/img/disclaimer.png" :iconStyle="{'marginRight': '30rpx'}" @click="goExemption" title="免责声明"
				 :center="true"></u-cell-item>

				<!-- <u-cell-item icon="/static/img/complaints_suggestions.png" :iconStyle="{'marginRight': '30rpx'}" @click="goFeedback"
				 title="投诉建议" center></u-cell-item> -->
			</u-cell-group>
		</view>
		<u-mask :show="showYuMod" :zoom="false" @click="showYuMod = false">
			<view class="mo-warp">
				<view class="content" @tap.stop>
					<view class="item">
						<view class="label">
							请输入预产期
						</view>
						<view class="tip">
							请输入产检时专家告知的预产期

						</view>
						<view class="input-wrp" @click="yuDateShow=true">
							<text v-if="!editInfo.yuDate">请选择日期</text>
							<view v-else>
								{{editInfo.yuDate}}
							</view>
							<u-icon name="calendar" size="30rpx"></u-icon>
						</view>
						<u-picker mode="time" confirm-color="#11B5FF" v-model="yuDateShow" @confirm="changeYuDate" :params="params"></u-picker>

					</view>
					<view class="btn-wrp">
						<button class="btn" @click="goYuSatus">
							进入
						</button>
					</view>
				</view>
			</view>
		</u-mask>
		<!-- 状态切换宝宝-->
		<u-mask :show="showChildren" :zoom="false" @click="showChildren = false">
			<view class="mo-warp">
				<view class="content" @tap.stop>
					<view class="item">
						<view class="label">
							宝宝昵称
						</view>
						<view class="input-wrp">
							<input class="input-text" v-model="editInfo.child_name" placeholder="请输入" />
							<u-image class="img" src="/static/img/nicheng.png" mode="aspectFit" width="24" height="24"></u-image>
						</view>
					</view>
					<view class="item">
						<view class="label">
							宝宝生日
						</view>
						<view class="input-wrp" @click="birthDateShow=true">
							<text v-if="!editInfo.child_age">请选择出生日期</text>
							<view v-else>
								{{editInfo.child_age_info}}
							</view>
							<u-icon name="calendar" size="30rpx"></u-icon>
						</view>
						<u-picker mode="time" confirm-color="#11B5FF" v-model="birthDateShow" @confirm="changeBirthDate" :params="params"></u-picker>

					</view>
					<view class="item">
						<view class="label">
							宝宝性别
						</view>
						<view class="input-wrp" @click="sexShow=true">
							<text v-if="!editInfo.child_sex">请选择性别</text>
							<view v-else>
								{{editInfo.child_sex}}
							</view>
							<u-image class="img" src="/static/img/xingbie.png" mode="aspectFit" width="24" height="24"></u-image>

						</view>
						<u-action-sheet :list="sexList" v-model="sexShow" @click="sexClick" :cancel-btn="true"></u-action-sheet>

					</view>
					<view class="btn-wrp">
						<button class="btn" @click="goChildrenSatus">
							进入
						</button>
					</view>
				</view>
			</view>
		</u-mask>
	</view>
</template>

<script>
	import moment from '@/common/moment';
	export default {
		data() {
			return {
				apiUrl: this.$apiUrl,
				pic: 'https://uviewui.com/common/logo.png',
				show: true,
				background: {
					'background-image': 'linear-gradient(90deg, #187FFF, #13B3FF)'
				},
				params: {
					year: true,
					month: true,
					day: true,
					hour: false,
					minute: false,
					second: false,
					timestamp: true
				},
				userInfo: {},
				editInfo: {},
				showYuMod: false,
				yuDateShow: false,
				birthDateShow: false,
				showChildren: false,
				sexShow: false,
				sexList: [{
					text: '男',
					fontSize: 28
				}, {
					text: '女',
					fontSize: 28
				}],
			}
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('YYYY年MM月DD日');
			}
		},
		onShow() {
			// console.log(uni.getStorageSync('info'))
			const that = this
			// uni.setStorageSync('uid', '123')
			console.log(uni.getStorageSync('uid'),'99888')
			if (!parseInt(uni.getStorageSync('uid')) >= 0) {
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						console.log(loginRes);
						that.getuserstatus(loginRes.code)
					}
				});
			} else {
				this.getUser()
			}
			// this.getUser()

		},
		onPullDownRefresh() {
			console.log("onPullDownRefresh")
			this.getUser()
		},
		methods: {
			async getUser(status) {
				let params = {
					user_id: uni.getStorageSync('uid'),
					status:0
				}
				console.log(params,789654)
				let res = await this.$u.api.getPersonalUser(params);
				this.userInfo = res.data
				this.userInfo.yuDate = moment(parseInt(res.data.birth_time) * 1000).format("YYYY年MM月DD日")
				this.userInfo.child_age_info = moment(parseInt(res.data.child_age) * 1000).format("YYYY年MM月DD日")
				console.log(this.userInfo)

				uni.stopPullDownRefresh()

			},
			
			async getuserstatus(code) {
				const that = this
				let params = {
					code: code
				}
				let res = await that.$u.api.getuserstatus(params);
				if (res.code !== 200) return
				uni.setStorageSync('uid', res.data.user_id)
				this.getUser()
			},
			editYuInfo() {
				this.editInfo = this.userInfo
				this.showYuMod = true
			},
			editBaoInfo() {
				this.editInfo = this.userInfo
				this.showChildren = true
			},
			goMyFocus() {
				uni.navigateTo({
					url: '/pages/myFocus/myFocus'
				})
			},
			changeYuDate(e) {
				console.log(e)
				this.editInfo.birth_time = e.timestamp
				this.editInfo.yuDate = e.year + "-" + e.month + "-" + e.day
			},
			changeBirthDate(e) {
				console.log(e)
				this.editInfo.child_age = e.timestamp
				this.editInfo.child_age_info = e.year + "-" + e.month + "-" + e.day
			},
			openSet() {
				uni.openSetting()
			},
			//进入预产状态
			async goYuSatus() {
				if (!this.editInfo.yuDate) {
					uni.showToast({
						title: "请选择预产期",
						icon: 'none'
					})
					return
				}
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: '1',
					birth_time: this.editInfo.birth_time
				}
				let res = await this.$u.api.updateUserStatus(params);
				if (res.code !== 200 && res.code !== 1) return
				this.showYuMod = false
				this.getUser()

			},
			goMini() {
				uni.navigateToMiniProgram({
					appId: 'wx62718bd5b17f9b14',
					path: 'pages/common/blank-page/index?weappSharePath=pages%2Fhome%2Fdashboard%2Findex%3Fkdt_id%3D44355301',
					extraData: {},
					success(res) {
						// 打开成功
					}
				})
			},
			async goChildrenSatus() {
				if (!this.editInfo.child_name) {
					uni.showToast({
						title: "请输入宝宝昵称",
						icon: 'none'
					})
					return
				}
				if (!this.editInfo.child_age) {
					uni.showToast({
						title: "请选择出生日期",
						icon: 'none'
					})
					return
				}
				if (!this.editInfo.child_sex) {
					uni.showToast({
						title: "请选择性别",
						icon: 'none'
					})
					return
				}
				let params = {
					user_id: uni.getStorageSync('uid'),
					status: '2',
					child_name: this.editInfo.child_name,
					child_age: this.editInfo.child_age,
					child_sex: this.editInfo.child_sex

				}
				let res = await this.$u.api.updateUserStatus(params);
				if (res.code !== 200 && res.code !== 1) return
				this.showChildren = false
				this.getUser()
			},
			sexClick(index) {
				this.editInfo.child_sex = this.sexList[index].text
			},
			goAskDoctor() {
				uni.navigateTo({
					url: '/pages/askDoctor/askDoctor'
				})
			},
			goCollection() {
				uni.navigateTo({
					url: '../myCollection/myCollection'
				})
			},
			goAppointment() {
				uni.navigateTo({
					url: '../myAppointment/myAppointment'
				})
			},
			goExemption() {
				uni.navigateTo({
					url: '../exemption/exemption'
				})
			},
			goUserInfo() {
				uni.navigateTo({
					url: '../userInfo/userInfo'
				})
			},
			goRecordGrow() {
				uni.navigateTo({
					url: "/pages/growList/growList"
				})
			},
			goFeedback() {
				uni.navigateTo({
					url: "/pages/feedBack/feedBack"
				})
			}

		}
	}
</script>

<style lang="scss">
	page {
		button {
			background-color: #fff;
			line-height: 60rpx;
			padding: 0;
		}

		.mo-warp {
			display: flex;
			align-items: center;
			justify-content: center;
			height: 100%;

			.content {
				width: 80%;
				min-height: 260rpx;
				background-color: #FFFFFF;
				border-radius: 30rpx;
				padding: 20rpx 30rpx;
				color: #474747;
				font-size: 24rpx;

				.btn-wrp {
					font-size: 24rpx;
					text-align: center;
					margin-top: 70rpx;

					.btn {
						display: inline-block;
						width: 250rpx;
						font-size: 26rpx;
						background-color: $base-color;
						color: #FFFFFF;
						line-height: 80rpx;
						border-radius: 40rpx;
					}
				}

				.label {
					line-height: 80rpx;

				}

				.tip {
					color: #a7a7a7;
					line-height: 40rpx;
					margin-bottom: 20rpx;

				}

				.input-wrp {
					// width: 60%;
					height: 70rpx;
					border: 1rpx solid #a9a9a9;
					padding: 0 30rpx;
					font-size: 28rpx;
					display: flex;
					justify-content: space-between;
					align-items: center;
					border-radius: 6rpx;

					.input-text {
						font-size: 28rpx;
						flex: 1;
					}
				}
			}

		}

		.account-info {
			// background-image: url('/static/img/person_info_bg.png');
			background: linear-gradient(90deg, #187FFF, #13B3FF);
			background-size: cover;
			background-repeat: no-repeat;
			padding: $spacing-base;
			font-size: 27rpx;
			color: white;

			.top {
				display: flex;
				align-items: center;

				.name {
					margin-left: 17rpx;
				}

				.icon {
					margin-left: 10rpx;
				}
			}

			.bottom {
				margin-top: 30rpx;
				display: flex;
				justify-content: space-around;
				margin-bottom: 30rpx;
				font-size: 30rpx;

				.b-item {
					text-align: center;

					.num {
						margin-bottom: 20rpx;
					}
				}

				.count {
					margin-bottom: 20rpx;
				}

			}
		}

		.baby-info {
			background-color: white;
			border-radius: 20rpx 20rpx 0 0;
			margin-top: -20rpx;
			padding: 20rpx;

			.info {
				display: flex;
				align-items: center;

				.mid {
					margin-left: 10rpx;
					flex-grow: 4;
				}

				.birth {
					display: flex;
					align-items: center;
					margin-top: 17rpx;
					font-size: 20rpx;
					color: $font-color-disabled;

					.icon {
						margin-left: 20rpx;
					}
				}

				.record-btn {
					color: #ffffff;
					padding: 12rpx 30rpx;
					font-weight: 300;
					font-size: 24rpx;
					border-radius: 100rpx;
					background-color: #F09FA0;
				}
			}

			.menu {
				display: flex;
				flex-wrap: wrap;
				margin-top: 20rpx;

				.item {
					display: flex;
					min-width: 48%;
					flex: 1;
					margin-bottom: 20rpx;
					justify-content: space-between;
					padding: 30rpx 20rpx;
					border-radius: 8rpx;
					align-items: center;
					background-color: #dbeafb;

					.img {
						margin-left: 25rpx;
					}

					.title {
						font-size: 24rpx;
						font-weight: 600;
						color: #1A1A1A;
					}

					.content {
						font-size: 17rpx;
						color: #666666;
						margin-top: 20rpx;
					}

					&:nth-of-type(2) {
						background-color: #FDF3F8;
						margin-left: 20rpx;
					}

					&:nth-of-type(3) {
						background-color: #FCEFED;
					}

					&:nth-of-type(4) {
						background-color: #F7FFFC;
						margin-left: 20rpx;
					}
				}
			}
		}

		.div-line {
			height: 11px;
			background-color: #e5e5e5;
		}

	}
</style>
