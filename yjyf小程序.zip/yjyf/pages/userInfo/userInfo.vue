<template>
	<view class="userinfo">
		<view class="i-item">
			<view class="label">
				头像
			</view>
			<view class="content">
				<u-avatar :src="apiUrl+userInfo.avatar" class="avatar" @click="chooseImg"></u-avatar>
				<u-icon name="arrow-right" size="30rpx"></u-icon>
			</view>
		</view>
		<view class="i-item">
			<view class="label">
				昵称
			</view>
			<view class="content">
				<input v-model="userInfo.openname">
				<!-- {{userInfo.openname}} -->
				<u-icon name="arrow-right" size="30rpx"></u-icon>
			</view>
		</view>
		<view class="i-item">
			<view class="label">
				绑定手机号
			</view>
			<view class="content">
				<button open-type="getPhoneNumber" @getphonenumber="decryptPhoneNumber"> {{userInfo.phone|| '未绑定'}}</button>
				<u-icon name="arrow-right" size="30rpx"></u-icon>
			</view>
		</view>
		<!-- <view class="i-item">
			<view class="label">
				我的收获地址
			</view>
			<view class="content">
				<u-icon name="arrow-right" size="30rpx"></u-icon>
			</view>
		</view> -->
		<view class="btn-wrp">
			<view class="c-btn" @click="updateUser">
				提交
			</view>
		</view>
	</view>

</template>

<script>
	import moment from '@/common/moment';

	export default {
		data() {
			return {
				userInfo: {},
				apiUrl: this.$apiUrl,
				statuss:''
			};
		},
		onLoad() {
			this.getUser()
		},
		onShow() {
			const that = this
			console.log(uni.getStorageSync('uid'),'99888')
			if (!uni.getStorageSync('uid') >= 0) {
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						console.log(loginRes);
						that.getuserstatus(loginRes.code)
					}
				});
			} 
		
		},
		methods: {
			async getuserstatus(){
				let params = {
					code: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getStatuss(params);
				console.log(res,'status')
				this.statuss = res.data.status
				// this.getUser()
			},
			async getUser(status) {
				let params = {
					user_id: uni.getStorageSync('uid'),
					pregnancy_status: 0
				}
				let res = await this.$u.api.getUser(params);
				this.userInfo = res.data
				uni.stopPullDownRefresh()

			},
			async updateUser(status) {
				let params = {
					user_id: uni.getStorageSync('uid'),
					openname: this.userInfo.openname,
					avatar: this.userInfo.avatar,
					phone: this.userInfo.phone
				}
				let res = await this.$u.api.updateUser(params);
				uni.showToast({
					title: res.msg
				})
				this.getUser()
			},
			decryptPhoneNumber(val) {
				console.log(val)
			},

			chooseImg() {
				const that = this
				uni.chooseImage({
					success: (chooseImageRes) => {
						const tempFilePaths = chooseImageRes.tempFilePaths;
						uni.uploadFile({
							url: that.$askUrl + '/common/upload', //仅为示例，非真实的接口地址
							filePath: tempFilePaths[0],
							name: 'file',
							formData: {},
							success: (res) => {
								console.log(JSON.parse(res.data).data.file);
								this.userInfo.avatar = JSON.parse(res.data).data.file
							}
						});
					}
				});
			}
		}
	};
</script>

<style lang="scss" scoped>
	.userinfo {
		padding: 0 $spacing-lg;

		button {
			background-color: rgba(0, 0, 0, 0);
			padding: 0;
			line-height: 102rpx;
			color: inherit;
			font-size: 28rpx;
		}

		.i-item {
			border-bottom: 1rpx solid #cccccc;
			display: flex;
			justify-content: space-between;
			line-height: 102rpx;
			font-size: 28rpx;
			color: #525252;

			.content {
				display: flex;
				color: #b9b9b9;

				input {
					font-size: 28rpx;
					line-height: 60rpx;
					margin-top: 30rpx;
					text-align: right;
					padding-right: 20rpx;
				}
			}
		}

		.avatar {
			vertical-align: middle;
			margin-right: 20rpx;
			margin-bottom: 10rpx;
		}
	}

	.btn-wrp {
		text-align: center;
		margin-top: 80rpx;

		.c-btn {
			display: inline-block;
			background-color: $base-color;
			padding: 10rpx 30rpx;
			color: #FFFFFF;
			width: 140rpx;
			text-align: center;
			border-radius: 4rpx;
		}
	}
</style>
