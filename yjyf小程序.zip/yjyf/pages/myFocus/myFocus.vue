<template>
	<view class="content">
		<view class="wrp">
			<u-tabs :list="tabList" active-color="#11B5FF" :is-scroll="false" :current="current" @change="tabChange"></u-tabs>
			<view class="hua-wrp" v-if="current===0">
				<empty v-if="huaList.length===0" info="您还没有关注哦"></empty>

				<u-swipe-action btn-width="60" :index="index" v-for="(item, index) in huaList" :key="item.id" @click="cancalHuaFocus"
				 :show="item.show" @open="open" :options="options">
					<view class="item u-border-bottom">
						<view class="img-wrp">
							<u-image :src="apiUrl+item.tag.thumb" mode="aspectFit" width="180" height="120" :lazy-load="true"></u-image>
						</view>

						<!-- 此层wrap在此为必写的，否则可能会出现标题定位错误 -->
						<view class="con-wrap">
							<view class="title">
								<text class="fu">#</text>{{ item.tag.name }}
							</view>
							<view class="info">
								{{item.zjcount}}条专家说 <text>{{item.cyCount}}参与 </text>{{item.gzCount}}关注
							</view>

						</view>
					</view>
				</u-swipe-action>
			</view>
			<view class="doc-wrp" v-if="current===1">
				<empty v-if="doctorList.length===0" info="您还没有关注哦"></empty>
				<u-swipe-action v-if="doctorList.length!==0" btn-width="60" :index="index" v-for="(item, index) in doctorList" :key="item.id"
				 @click="cancalHuaFocus" :show="item.show" @open="open" :options="options">
					<view class="doc-item u-border-bottom">
						<view class="img-wrp">
							<u-image :src="apiUrl+item.thumb" shape="circle" width="98" height="98" :lazy-load="true"></u-image>
						</view>

						<!-- 此层wrap在此为必写的，否则可能会出现标题定位错误 -->
						<view class="con-wrap">
							<view class="title">
								<text class="name">{{item.name}}</text>{{ item.position }}
							</view>
							<view class="info">
								{{item.dname}}<text>{{item.hname}}</text>
							</view>
							<view class="good-at">
								擅长：{{item.expert||'未填写'}}
							</view>

						</view>
					</view>
				</u-swipe-action>
			</view>
		</view>
	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue";
	export default {
		components: {
			empty
		},
		data() {
			return {
				apiUrl: this.$apiUrl,
				doctorList: [],
				tabList: [{
					name: '我关注的话题'
				}, {
					name: '我关注的专家'
				}],
				current: 0,
				focusList: [],
				status: '',
				nomore: false,
				options: [{
					text: '取消关注',
					style: {
						backgroundColor: '#E5E5E5',
						width: '20rpx'
					}
				}],
				huaList: []
			};
		},
		onLoad(val) {
			if (this.current === 0) {
				this.getuserfocuslist()
			} else {
				this.getfollowDoclist();
			}
		},
		onReachBottom() {
			this.status = 'loading';
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getData()
					this.status = 'loading';
				}
			}, 2000)
		},
		methods: {

			async getfollowDoclist() {
				let params = {
					uid: uni.getStorageSync('uid')
				};
				let res = await this.$u.api.getfollowlist(params);
				console.log(res.data)
				this.doctorList = res.code === 1 ? res.data : []

			},
			async getuserfocuslist() {
				let params = {
					user_id: uni.getStorageSync('uid')
				};
				let res = await this.$u.api.getuserfocuslist(params);
				console.log(res.data)
				this.huaList = res.code === 1 ? res.data : []

			},

			async followdocter(id) {
				let params = {
					did: id,
					uid: uni.getStorageSync('uid'),
					type: '2'
				}
				let res = await this.$u.api.followdocter(params);
				if (res.code !== 200 && res.code !== 1) return
				uni.showToast({
					title: "操作成功",
					icon: 'none'
				})
				this.getfollowDoclist();
			},
			tabChange(val) {
				this.current = val
				if (this.current === 0) {
					this.getuserfocuslist()
				} else {
					this.getfollowDoclist();
				}
			},
			cancalHuaFocus(index) {
				console.log(index)
				if (this.current == 0) {
					this.huaList.splice(index, 1)
				} else {
					this.followdocter(this.doctorList[index].id)
				}
			},
			// 如果打开一个的时候，不需要关闭其他，则无需实现本方法
			open(index) {
				// 先将正在被操作的swipeAction标记为打开状态，否则由于props的特性限制，
				// 原本为'false'，再次设置为'false'会无效
				this.focusList[index].show = true;
				this.focusList.map((val, idx) => {
					if (index != idx) this.focusList[idx].show = false;
				})
			}
		}
	};
</script>

<style lang="scss" scoped>
	.hua-wrp {
		padding: 0 $spacing-lg;
		box-sizing: border-box;
		margin-top: 20rpx;

		.item {
			display: flex;
			color: $font-color-base;
			padding: 20rpx 0;

			.img-wrp {
				width: 180rpx;
				margin-right: 20rpx;
			}

			.con-wrap {
				flex: 1;

				.title {
					font-size: 28rpx;
					overflow: hidden;
					white-space: nowrap;
					text-overflow: hidden;
					margin-bottom: 20rpx;

					text {
						margin-right: 10rpx;
					}
				}

				.info {
					font-size: 24rpx;

					text {
						margin: 0 20rpx;
					}
				}
			}
		}
	}

	.doc-wrp {
		padding: 0 $spacing-lg;
		box-sizing: border-box;
		margin-top: 20rpx;
	}

	.doc-item {
		display: flex;
		padding: 30rpx 0 48rpx 0;
		font-size: 24rpx;

		.img-wrp {
			margin-right: 20rpx;
		}

		.con-wrap {
			flex: 1;

			.title {
				overflow: hidden;
				white-space: nowrap;
				text-overflow: hidden;
				margin-bottom: 20rpx;
			}

			.info {
				font-size: 24rpx;

				text {
					margin: 0 20rpx;
				}
			}

			.good-at {
				color: $font-color-light;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: hidden;
			}
		}
	}
</style>
