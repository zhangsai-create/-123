<template>
	<view>
		<view class="type">
			<view class="t-item" @click="goDoctorList('famousDoctor')">
				<u-image src="/static/img/mingyizixun.png" width="55" height="55"></u-image>
				<view class="t-right">
					<view class="title">教育专家</view>
					<!-- <view class="slogan">更准确更放心</view> -->
				</view>
			</view>
			<view class="t-item" @click="goDoctorList('todayClinic')">
				<u-image src="/static/img/jinriyizhen.png" width="55" height="55"></u-image>
				<view class="t-right">
					<view class="title">儿童保健专家</view>
					<!-- <view class="slogan">好口碑超实惠</view> -->
				</view>
			</view>
		</view>

		<view style="padding: 14rpx; background-color: #F9F8F8; margin-top: 18rpx;"></view>

		<u-dropdown active-color="#11B5FF" ref="uDropdown">
			<u-dropdown-item :title="dept" :options="departmentlist" @change="changeDept"></u-dropdown-item>
			<u-dropdown-item :title="cityName" :options="cityList" >
				<view class="slot-content" style="background-color: #FFFFFF;">
					<scroll-view scroll-y="true" style="height: 400rpx;">
						<view class="u-text-center u-content-color u-m-t-20 u-m-b-20" v-for="item in cityList" :key="item.id" @click="changeCity(item)">{{item.name}}</view>
					</scroll-view>
				</view>
			</u-dropdown-item>
			<u-dropdown-item :title="hos" :options="hospitalList" @change="changeHos"></u-dropdown-item>
		</u-dropdown>
		<view style="padding: 30rpx; background-color:#F9F8F8; color: #484848; font-size: 23rpx;">为您推荐{{doctorList.length}}位专家</view>
		<view v-for="(item,index) in doctorList" :key="index">
			<doctorItem :itemBean="item"></doctorItem>
		</view>
		<empty v-if="doctorList.length===0" info="还没有数据哦"></empty>
		

	</view>
</template>

<script>
	import empty from "../../components/rf-empty/index.vue";
	
	import doctorItem from '../../components/doctor-item/doctor-item.vue'
	export default {
		components: {
			doctorItem,
			empty
		},
		data() {
			return {
				cityName: '全部城市',
				city: '',
				hos: '全部高校',
				dept: '全部方向',
				hid: '',
				did: '',
				doctorList: [],
				departmentlist: [],
				hospitalList: [],
				cityList: []
			};
		},
		onLoad() {
			this.getdoctorlist()
			this.getdepartmentlist()
			this.getHospitalList()
			this.getaddress()
		},
		methods: {
			async getdoctorlist() {
				let params = {
					did: this.did,
					hid: this.hid,
					city: this.city
				}
				let res = await this.$u.api.getdoctorlist(params);
				console.log(res)
				this.doctorList = res.data
			},

			async getaddress() {
				let params = {
					type: 0
				}
				let res = await this.$u.api.getaddress(params);
				this.cityList = [{
					label: '全部城市',
					value: ''
				}].concat(
					res.data.map(item => {
						item.label = item.name
						item.value = item.id
						return item
					}))
			},
			async getdepartmentlist() {
				let params = {
					type: 0
				}
				let res = await this.$u.api.getdepartmentlist(params);
				this.departmentlist = [{
					label: '全部方向',
					value: ''
				}].concat(
					res.data.map(item => {
						item.label = item.name
						item.value = item.id
						return item
					}))
			},
			async getHospitalList() {
				let res = await this.$u.api.getHospitalList({});
				this.hospitalList = [{
					label: '全部单位',
					value: ''
				}].concat(
					res.data.map(item => {
						item.label = item.name
						item.value = item.id
						return item
					}))
			},
			goDoctorList(type) {
				uni.navigateTo({
					url: '../doctorList/doctorList?type=' + type
				})
			},
			changeDept(val) {
				console.log("点击${val}", val)
				this.did = val.id
				this.dept = val.label
				this.getdoctorlist()
			},
			changeHos(val) {
				console.log("点击${val}", val)
				this.hid = val.id
				this.hos = val.label
				this.getdoctorlist()
			},
			changeCity(val) {
				console.log("点击${val}", val)
				this.city = val.id
				this.cityName = val.label
				this.$refs.uDropdown.close();
				this.getdoctorlist()
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #FFFFFF;
	}

	.type {
		padding: 18rpx 32rpx;
		display: flex;
		justify-content: space-around;

		.t-item {
			display: flex;
			border-radius: 5rpx;
			width: 49%;
			height: 122rpx;
			border-bottom: 1rpx solid #187FFF;
			box-shadow: 0px 0px 10px 5px #F8F8F8;
			align-items: center;
			justify-content: center;

			&:nth-of-type(2) {
				margin-left: 17rpx;
				border-bottom: 1rpx solid #13B3FF;
			}
		}

		.t-right {
			margin-left: 45rpx;
		}

		.title {
			font-size: 30rpx;
			color: #383838;
			font-weight: 400;
		}

		.slogan {
			font-size: 20rpx;
			font-weight: 400;
			color: #8B8B8B;
			margin-top: 23rpx;
		}
	}
</style>
