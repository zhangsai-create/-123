<template>
	<view class="page-bot">
		<view class="title">{{infoData.title}}</view>
		<view class="item-foot">
			<view class="author">{{infoData.dname}}</view>
			<view class="label">
				<text class="label-item">#{{infoData.tname}}</text>
			</view>
			<view class="date">{{infoData.releasetime|time}}</view>
		</view>
		<view class="wen-wrp">
			<u-parse :html="infoData.content"></u-parse>
		</view>

		<view>
			<RemarkInput :title="infoData.title" ref="remark" :cid="cid" :commentList="commentList" @update="getcommentList"
			 @expPushlike="expPushlike"></RemarkInput>
			<u-loadmore :status="status" v-if="commentList.length>pageSize" />

		</view>

	</view>
</template>

<script>
	import moment from '@/common/moment';
	import RemarkInput from "../../components/RemarkInput/RemarkInput.vue"
	export default {
		components: {
			RemarkInput,
		},
		data() {
			return {
				cid: null,
				apiUrl: this.$apiUrl,
				infoData: {},
				commentList: [],
				page: 1,
				pageSize: 10,
				status: '',
				nomore: false
			};
		},
		filters: {
			// 时间格式化
			time(val) {
				return moment(val * 1000).format('MM月DD日HH:mm');
			}
		},
		onLoad(val) {
			this.cid = val.cid || '10'
			this.getExpertssaid()
			this.getcommentList()
		},
		// 触底
		onReachBottom() {
			this.status = 'loading';
			setTimeout(() => {
				if (this.nomore) this.status = 'nomore';
				else {
					this.page = ++this.page;
					this.getcommentList()
					this.status = 'loading';
				}
			}, 2000)
		},
		onPullDownRefresh() {
			this.page = 1
			this.getExpertssaid()
			this.getcommentList()
		},
		methods: {
			async getExpertssaid() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
				}
				let res = await this.$u.api.getExpertssaidZx(params);
				this.infoData = res.data
			},
			async expPushlike() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					type: this.infoData.islikes === 0 ? 1 : 2,
					// 1：收藏 2：取消收藏
				}
				let res = await this.$u.api.expPushlikeZx(params);
				uni.showToast({
					title: res.data,
					icon: 'none'
				})
				this.getExpertssaid()
			},
			async getcommentList() {
				let params = {
					cid: this.cid,
					uid: uni.getStorageSync('uid'),
					page: this.page,
					num: this.pageSize
				}
				let res = await this.$u.api.getcommentListZx(params);

				this.commentList = this.page === 1 ? res.data : this.commentList.concat(res.data)
				if (res.data.length < this.pageSize) {
					this.nomore = true
				}
			}
		}
	}
</script>

<style lang="scss">
	.head {
		padding: 35rpx 0;
		text-align: center;

		.photo {
			display: inline-block;
		}
	}

	page {
		color: #272727;
		font-size: 28rpx;
		padding-bottom: 100rpx;
	}

	.title {
		margin: $spacing-lg;
		color: #272727;
	}

	.item-foot {
		display: flex;
		margin: $spacing-lg;
		margin-top: 22rpx;
		align-items: center;
		color: #6b6b6b;

		.author {
			font-size: 23rpx;
		}

		.label {
			flex-grow: 10;
			margin-left: 10rpx;
		}

		.label-item {
			background-color: #F0F0F0;
			border-radius: 100rpx;
			padding: 8rpx 20rpx;
		}

		.date {
			font-size: 20rpx;
		}
	}

	.wen-wrp {
		padding: 0 $spacing-lg;
		color: #575757;

	}
</style>
