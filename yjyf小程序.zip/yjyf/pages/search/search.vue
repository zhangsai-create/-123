<template>
	<view class="rf-search">
		<view class="search-box">
			<u-search placeholder="搜索话题" :value="keyword" @change="inputChange" @search="getSearchList" @clear="clearKey"
			 :actionStyle="actionStyle"></u-search>
		</view>
		<view class="serch-wrp" v-if="searchShow">
			<empty v-if="searchList.length===0" info="没有相关搜索话题,您可以换个话题"></empty>

			<view class="keyword">
				<view v-for="(item, index) in searchList" :key="index" @tap="goDeatil(item)" class="o-item">{{ item.name}}</view>
			</view>
		</view>
		<view class="search-keyword" @tap="blur" v-if="!searchShow">
			<scroll-view class="keyword-list-box" v-if="isShowKeywordList" scroll-y>
				<view class="keyword-entry" hover-class="keyword-entry-tap" v-for="row in keywordList" :key="row.keyword">
					<view class="keyword-text" @tap="doSearch(row.keyword)">
						<rf-parser lazy-load :html="row.htmlStr"></rf-parser>
					</view>
					<view class="keyword-img" @tap="setkeyword(row)">
					</view>
				</view>
			</scroll-view>
			<scroll-view class="keyword-box" v-if="!isShowKeywordList" scroll-y>
				<view class="keyword-block">
					<view class="keyword-list-header">
						<view>历史搜索</view>
						<view>
							<u-image src="/static/img/delete.png" @tap="oldDelete" width="30" mode="aspectFit" height="30" :lazy-load="true"></u-image>
						</view>
					</view>
					<view class="keyword">
						<view v-for="(keyword, index) in oldKeywordList" @tap="doSearch(keyword)" class="o-item" :key="index">{{ keyword}}</view>
					</view>
					<view class="hide-hot-tis" v-if="oldKeywordList.length === 0">
						<view>暂无记录</view>
					</view>
				</view>
				<view class="keyword-block" v-if="hotKeywordList">
					<view class="keyword-list-header">
						<view>热门搜索</view>
					</view>
					<view class="keyword">
						<view class="s-item" v-for="(item, index) in hotKeywordList" @tap.stop="goDeatil(item)" :key="index">
							<view class="title">
								{{item.name}}
							</view>
						</view>
					</view>
				</view>
			</scroll-view>
		</view>
	</view>
</template>
<script>
	import empty from "../../components/rf-empty/index.vue";

	export default {
		components: {
			empty
		},
		data() {
			return {
				keyword: '',
				searchList: [],
				searchShow: false,
				actionStyle: {
					width: '120rpx',
					background: '#11B5FF',
					padding: '10rpx 30rpx',
					color: '#fff',
					borderRadius: '40rpx'
				},
				oldKeywordList: [],
				hotKeywordList: [],
				keywordList: [],
				isShowKeywordList: false,
				hotSearchDefault: '',
				type: null, // 搜索类型
			};
		},
		onLoad(options) {
			this.initData(options);
		},
		methods: {
			async initData(options) {
				this.type = options.type;
				const search = JSON.parse(options.data || '{}');
				this.hotSearchDefault = search.hot_search_default || options.keyword;
				this.getHotList()
				this.loadOldKeyword();
			},
			async getSearchList() {
				this.searchShow = true
				let params = {
					name: this.keyword
				}
				let res = await this.$u.api.getSearchList(params);

				this.searchList = res.data
			},
			async getHotList() {
				let params = {
					num: 10
				}
				let res = await this.$u.api.getHotList(params);
				this.hotKeywordList = res.data
				console.log(res.data)
			},
			clearKey() {
				this.searchShow = false
				this.keyword = ''
			},
			blur() {
				uni.hideKeyboard();
			},
			// 加载历史搜索,自动读取本地Storage
			loadOldKeyword() {
				uni.getStorage({
					key: 'OldKeys',
					success: res => {
						let OldKeys = JSON.parse(res.data);
						this.oldKeywordList = OldKeys;
					}
				});
			},
			inputChange(val) {
				console.log(val)
				this.keyword = val
				if (val === '') {
					this.searchShow = false
				}
			},
			// 顶置关键字
			setkeyword(data) {
				this.keyword = data.keyword;
			},
			goDeatil(item) {
				uni.navigateTo({
					url: '/pages/huaDetail/huaDetail?tid=' + item.id
				})
			},
			// 清除历史搜索
			oldDelete() {
				uni.showModal({
					content: '确定清除历史搜索记录？',
					confirmColor: '#11B5FF',
					success: res => {
						if (res.confirm) {
							this.oldKeywordList = [];
							uni.removeStorage({
								key: 'OldKeys'
							});
						}
					}
				});
			},
			// 执行搜索
			doSearch(key) {
				key = key || this.keyword || this.defaultKeyword;
				this.keyword = key;
				this.saveKeyword(key); // 保存为历史
				// if (this.type === 'order') {
				// 	this.$mRouter.push({
				// 		route: `/pages/order/search?keyword=${key}`
				// 	});
				// } else {
				// 	this.$mRouter.push({
				// 		route: `/pages/product/list?keyword=${key}`
				// 	});
				// }
			},
			// 保存关键字到历史记录
			saveKeyword(keyword) {
				uni.getStorage({
					key: 'OldKeys',
					success: res => {
						let OldKeys = JSON.parse(res.data);
						console.log(OldKeys, keyword)
						let findIndex = OldKeys.indexOf(keyword);
						if (findIndex === -1) {
							OldKeys.unshift(keyword);
						} else {
							OldKeys.splice(findIndex, 1);
							OldKeys.unshift(keyword);
						}
						// 最多10个纪录
						OldKeys.length > 10 && OldKeys.pop();
						uni.setStorage({
							key: 'OldKeys',
							data: JSON.stringify(OldKeys)
						});
						this.oldKeywordList = OldKeys; // 更新历史搜索
					},
					fail: () => {
						let OldKeys = [keyword];
						uni.setStorage({
							key: 'OldKeys',
							data: JSON.stringify(OldKeys)
						});
						this.oldKeywordList = OldKeys; // 更新历史搜索
					}
				});
			}
		}
	};
</script>
<style lang="scss">
	.rf-search {
		.search-box {
			width: 100%;
			background-color: #FFFFFF;
			padding: 15rpx 2.5%;

		}

		.o-item {
			display: inline-block;
			padding: 6rpx 20rpx;
			background-color: #F8F8F8;
			margin-right: 20rpx;
			border-radius: 30rpx;
			min-width: 160rpx;
			text-align: center;
			margin-bottom: 20rpx;
		}

		.search-keyword {
			width: 100%;
			background-color: rgb(242, 242, 242);

			.keyword-list-box {
				height: calc(100vh - 110rpx);
				padding-top: 10rpx;
				border-radius: 20rpx 20rpx 0 0;
				background-color: #fff;
			}

			.keyword-entry {
				width: 94%;
				height: 80rpx;
				margin: 0 3%;
				font-size: 30rpx;
				color: #333;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-bottom: solid 1rpx #e7e7e7;

				image {
					width: 60rpx;
					height: 60rpx;
				}

				.keyword-text {
					width: 90%;
				}

				.keyword-img {
					width: 10%;
					justify-content: center;
				}
			}

			.keyword-box {
				border-radius: 20rpx 20rpx 0 0;
				background-color: #fff;

				.keyword-block {
					padding: 10rpx 0;

					.keyword-list-header {
						width: 100vw;
						padding: 10rpx 3%;
						font-size: 27rpx;
						color: #333;
						display: flex;
						justify-content: space-between;

						image {
							width: 40rpx;
							height: 40rpx;
						}
					}

					.keyword {
						width: 100vw;
						padding: 3px 3%;
						display: flex;
						flex-flow: wrap;
						justify-content: flex-start;
					}

					.hide-hot-tis {
						display: flex;
						justify-content: center;
						font-size: 28rpx;
						color: #6b6b6b;
					}

					.keyword {
						display: block;
						font-size: 28rpx;
						color: #6b6b6b;
						counter-reset: step;
						counter-increment: step 0;

						.s-item {
							display: block;
							position: relative;
							padding: 20rpx 20rpx 20rpx 60rpx;
							border-bottom: 1rpx solid $border-color-base;

							&:first-of-type::before {
								background-color: #12B6FE;
							}

							&:nth-of-type(2)::before {
								background-color: #82D5FF;
							}

							&:nth-of-type(3)::before {
								background-color: #CFE9FA;
							}

							&::before {
								content: counter(step);
								counter-increment: step;
								position: absolute;
								left: 0;
								top: 20rpx;
								line-height: 40rpx;
								display: block;
								width: 40rpx;
								height: 40rpx;
								text-align: center;
								color: #FFFFFF;
								background-color: #808080;

							}

						}

						.title {
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
						}

					}
				}
			}
		}
	}
</style>
